<?php
// ============================================================
// Verde Natural — Panel de Administración
// admin.php — Login + Dashboard + Productos + Categorías + Banners
// ============================================================

session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'verde_natural');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
            );
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:40px;text-align:center">
                <h2 style="color:#00291e">Error de conexión</h2>
                <code>'.$e->getMessage().'</code></div>');
        }
    }
    return $pdo;
}
function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function formatPrice($p) { return '$ '.number_format($p,0,',','.').' COP'; }

// ── AUTENTICACIÓN ─────────────────────────────────────────────
$error   = '';
$success = '';
$page    = $_GET['page'] ?? 'dashboard';
$loginView = $_GET['view'] ?? 'login'; // login | forgot | reset

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Proceso de login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if ($email && $pass) {
        $db = getDB();
        $st = $db->prepare("SELECT * FROM administradores WHERE email=? AND activo=1");
        $st->execute([$email]);
        $admin = $st->fetch();
        if ($admin && password_verify($pass, $admin['password'])) {
            $_SESSION['admin_id']     = $admin['id'];
            $_SESSION['admin_nombre'] = $admin['nombre'];
            $_SESSION['admin_email']  = $admin['email'];
            $db->prepare("UPDATE administradores SET ultimo_acceso=NOW() WHERE id=?")->execute([$admin['id']]);
            header('Location: admin.php');
            exit;
        } else {
            $error = 'Correo o contraseña incorrectos.';
        }
    } else {
        $error = 'Completa todos los campos.';
    }
}

// Proceso de recuperar contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['forgot'])) {
    $email = trim($_POST['email'] ?? '');
    if ($email) {
        $db = getDB();
        $st = $db->prepare("SELECT * FROM administradores WHERE email=? AND activo=1");
        $st->execute([$email]);
        $admin = $st->fetch();
        if ($admin) {
            // Crear tabla de tokens si no existe
            $db->exec("CREATE TABLE IF NOT EXISTS admin_reset_tokens (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id INT NOT NULL,
                token VARCHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                usado TINYINT DEFAULT 0,
                created_at DATETIME DEFAULT NOW()
            )");
            $token = bin2hex(random_bytes(32));
            $db->prepare("INSERT INTO admin_reset_tokens (admin_id, token, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))")
               ->execute([$admin['id'], $token]);
            $resetLink = "http://localhost/verde_natural/admin.php?view=reset&token=".$token;
            // Enviar correo con mail() de PHP
            $to      = $admin['email'];
            $subject = "=?UTF-8?B?".base64_encode("Verde Natural - Recuperar contraseña")."?=";
            $body    = "Hola {$admin['nombre']},\n\nRecibiste este correo porque solicitaste restablecer tu contraseña del Panel de Administración de Verde Natural.\n\nHaz clic en el siguiente enlace para crear una nueva contraseña (válido por 1 hora):\n\n{$resetLink}\n\nSi no solicitaste esto, ignora este correo.\n\nVerde Natural\nPanel de Administración";
            $headers = "From: noreply@verdenatural.co\r\nContent-Type: text/plain; charset=UTF-8";
            mail($to, $subject, $body, $headers);
            $success = "Te enviamos un enlace a <strong>{$email}</strong> para restablecer tu contraseña. Revisa tu bandeja de entrada.";
        } else {
            // Mismo mensaje por seguridad
            $success = "Si ese correo está registrado, recibirás un enlace en breve.";
        }
        $loginView = 'forgot';
    } else {
        $error = 'Ingresa tu correo electrónico.';
        $loginView = 'forgot';
    }
}

// Proceso de resetear contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    $token = $_POST['token'] ?? '';
    $pass1 = $_POST['pass1'] ?? '';
    $pass2 = $_POST['pass2'] ?? '';
    if ($pass1 && $pass2 && $pass1 === $pass2 && strlen($pass1) >= 6) {
        $db = getDB();
        $st = $db->prepare("SELECT * FROM admin_reset_tokens WHERE token=? AND usado=0 AND expires_at > NOW()");
        $st->execute([$token]);
        $tok = $st->fetch();
        if ($tok) {
            $hash = password_hash($pass1, PASSWORD_DEFAULT);
            $db->prepare("UPDATE administradores SET password=? WHERE id=?")->execute([$hash, $tok['admin_id']]);
            $db->prepare("UPDATE admin_reset_tokens SET usado=1 WHERE token=?")->execute([$token]);
            $success = 'Contraseña actualizada correctamente. Ya puedes iniciar sesión.';
            $loginView = 'login';
        } else {
            $error = 'El enlace no es válido o ya expiró. Solicita uno nuevo.';
            $loginView = 'reset';
        }
    } else {
        $error = strlen($pass1) < 6 ? 'La contraseña debe tener al menos 6 caracteres.' : 'Las contraseñas no coinciden.';
        $loginView = 'reset';
    }
}

// Ver reset desde enlace de correo
if (isset($_GET['view']) && $_GET['view'] === 'reset' && isset($_GET['token'])) {
    $loginView = 'reset';
}

// Si no está autenticado, mostrar login
if (empty($_SESSION['admin_id'])) {
    $resetToken = $_GET['token'] ?? $_POST['token'] ?? '';
    ?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verde Natural — Admin</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='32' fill='%23176b4b'/%3E%3Cpath d='M32 12 C20 20 16 30 20 44 C24 36 28 32 32 30 C36 32 40 36 44 44 C48 30 44 20 32 12Z' fill='%23a4f3ca'/%3E%3Cline x1='32' y1='30' x2='32' y2='50' stroke='%23a4f3ca' stroke-width='2.5' stroke-linecap='round'/%3E%3C/svg%3E">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Plus Jakarta Sans',sans-serif;}
.material-symbols-outlined{font-family:'Material Symbols Outlined';font-style:normal;line-height:1;text-transform:none;white-space:nowrap;direction:ltr;-webkit-font-feature-settings:'liga';font-feature-settings:'liga';-webkit-font-smoothing:antialiased;}
body{min-height:100vh;background:linear-gradient(135deg,#001a10 0%,#003320 50%,#005a38 100%);display:flex;align-items:center;justify-content:center;padding:16px;}
.card{background:#fff;border-radius:24px;width:100%;max-width:420px;overflow:hidden;box-shadow:0 32px 80px rgba(0,0,0,.35);}
.card-top{background:linear-gradient(135deg,#0d3326,#176b4b);padding:36px 32px 28px;text-align:center;}
.logo-circle{width:68px;height:68px;border-radius:50%;background:rgba(255,255,255,.12);border:2px solid rgba(164,243,202,.3);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
.card-top h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:4px;}
.card-top p{font-size:13px;color:rgba(164,243,202,.8);}
.card-body{padding:28px 32px 32px;}
.field{margin-bottom:16px;}
.field label{display:block;font-size:11px;font-weight:700;color:#414845;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px;}
.field input{width:100%;background:#f4f7f4;border:1.5px solid #dde3dc;border-radius:12px;padding:12px 16px;font-size:14px;color:#181d1a;outline:none;transition:border .2s;}
.field input:focus{border-color:#176b4b;background:#fff;}
.btn-primary{width:100%;background:#176b4b;color:#fff;border:none;padding:14px;border-radius:999px;font-size:15px;font-weight:700;cursor:pointer;transition:background .2s;display:flex;align-items:center;justify-content:center;gap:8px;margin-top:8px;}
.btn-primary:hover{background:#0d3326;}
.btn-link{background:none;border:none;color:#176b4b;font-size:13px;font-weight:600;cursor:pointer;text-decoration:underline;padding:0;}
.alert-error{background:#ffdad6;color:#93000a;padding:12px 16px;border-radius:12px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px;}
.alert-success{background:#d6f5e3;color:#00291e;padding:12px 16px;border-radius:12px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px;}
.divider{text-align:center;margin:20px 0 16px;color:#999;font-size:12px;position:relative;}
.divider::before,.divider::after{content:'';position:absolute;top:50%;width:42%;height:1px;background:#e8e8e8;}
.divider::before{left:0;}.divider::after{right:0;}
.back-link{text-align:center;margin-top:20px;}
.back-link a{color:rgba(255,255,255,.6);font-size:12px;text-decoration:none;display:inline-flex;align-items:center;gap:4px;transition:color .2s;}
.back-link a:hover{color:#a4f3ca;}
.show-pass{position:relative;}
.show-pass input{padding-right:44px;}
.show-pass button{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#888;display:flex;}
</style>
</head>
<body>
  <div style="width:100%;max-width:420px;">
    <div class="card">
      <!-- Top verde -->
      <div class="card-top">
        <div class="logo-circle">
          <svg width="32" height="32" viewBox="0 0 64 64" fill="none">
            <path d="M32 8 C18 18 14 30 18 46 C22 36 27 30 32 28 C37 30 42 36 46 46 C50 30 46 18 32 8Z" fill="#a4f3ca"/>
            <line x1="32" y1="28" x2="32" y2="54" stroke="#a4f3ca" stroke-width="3" stroke-linecap="round"/>
          </svg>
        </div>
        <h1>Verde Natural</h1>
        <p>Panel de Administración</p>
      </div>

      <!-- Body -->
      <div class="card-body">

        <?php if ($success): ?>
        <div class="alert-success">
          <span class="material-symbols-outlined" style="font-size:18px;">check_circle</span>
          <span><?= $success ?></span>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert-error">
          <span class="material-symbols-outlined" style="font-size:18px;">error</span>
          <span><?= h($error) ?></span>
        </div>
        <?php endif; ?>

        <?php if ($loginView === 'forgot'): ?>
        <!-- ── OLVIDÉ MI CONTRASEÑA ── -->
        <h2 style="font-size:18px;font-weight:700;color:#00291e;margin-bottom:6px;">¿Olvidaste tu contraseña?</h2>
        <p style="font-size:13px;color:#666;margin-bottom:20px;">Ingresa tu correo y te enviamos un enlace para restablecerla.</p>
        <?php if (!$success): ?>
        <form method="POST">
          <input type="hidden" name="forgot" value="1">
          <div class="field">
            <label>Correo electrónico</label>
            <input type="email" name="email" required placeholder="admin@verdenatural.co" value="<?= h($_POST['email'] ?? '') ?>">
          </div>
          <button type="submit" class="btn-primary">
            <span class="material-symbols-outlined" style="font-size:18px;">mail</span>
            Enviar enlace
          </button>
        </form>
        <?php endif; ?>
        <div class="divider">o</div>
        <div style="text-align:center;">
          <a href="admin.php" style="color:#176b4b;font-size:13px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:4px;">
            <span class="material-symbols-outlined" style="font-size:16px;">arrow_back</span> Volver al inicio de sesión
          </a>
        </div>

        <?php elseif ($loginView === 'reset'): ?>
        <!-- ── NUEVA CONTRASEÑA ── -->
        <h2 style="font-size:18px;font-weight:700;color:#00291e;margin-bottom:6px;">Nueva contraseña</h2>
        <p style="font-size:13px;color:#666;margin-bottom:20px;">Elige una contraseña segura de al menos 6 caracteres.</p>
        <form method="POST">
          <input type="hidden" name="reset" value="1">
          <input type="hidden" name="token" value="<?= h($resetToken) ?>">
          <div class="field">
            <label>Nueva contraseña</label>
            <div class="show-pass">
              <input type="password" name="pass1" id="p1" required placeholder="••••••••" minlength="6">
              <button type="button" onclick="var i=document.getElementById('p1');i.type=i.type==='password'?'text':'password'">
                <span class="material-symbols-outlined" style="font-size:18px;">visibility</span>
              </button>
            </div>
          </div>
          <div class="field">
            <label>Confirmar contraseña</label>
            <div class="show-pass">
              <input type="password" name="pass2" id="p2" required placeholder="••••••••" minlength="6">
              <button type="button" onclick="var i=document.getElementById('p2');i.type=i.type==='password'?'text':'password'">
                <span class="material-symbols-outlined" style="font-size:18px;">visibility</span>
              </button>
            </div>
          </div>
          <button type="submit" class="btn-primary">
            <span class="material-symbols-outlined" style="font-size:18px;">lock_reset</span>
            Guardar contraseña
          </button>
        </form>

        <?php else: ?>
        <!-- ── LOGIN NORMAL ── -->
        <h2 style="font-size:18px;font-weight:700;color:#00291e;margin-bottom:20px;">Iniciar sesión</h2>
        <form method="POST">
          <input type="hidden" name="login" value="1">
          <div class="field">
            <label>Correo electrónico</label>
            <input type="email" name="email" required placeholder="admin@verdenatural.co" value="<?= h($_POST['email'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Contraseña</label>
            <div class="show-pass">
              <input type="password" name="password" id="passInput" required placeholder="••••••••">
              <button type="button" onclick="var i=document.getElementById('passInput');i.type=i.type==='password'?'text':'password'">
                <span class="material-symbols-outlined" style="font-size:18px;">visibility</span>
              </button>
            </div>
          </div>
          <div style="text-align:right;margin-top:-8px;margin-bottom:16px;">
            <a href="admin.php?view=forgot" style="font-size:12px;color:#176b4b;text-decoration:none;font-weight:600;">¿Olvidaste tu contraseña?</a>
          </div>
          <button type="submit" class="btn-primary">
            <span class="material-symbols-outlined" style="font-size:18px;">login</span>
            Ingresar
          </button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <div class="back-link">
      <a href="index.php">
        <span class="material-symbols-outlined" style="font-size:14px;">arrow_back</span>
        Volver a la tienda
      </a>
    </div>
  </div>
</body>
</html>
<?php exit; }

// ═══════════════════════════════════════════════════════════
// PANEL ADMIN — Usuario autenticado
// ═══════════════════════════════════════════════════════════
$db = getDB();
$adminNombre = $_SESSION['admin_nombre'] ?? 'Admin';

// ── HELPER: SUBIR IMAGEN (base64 — sin dependencia de carpetas) ──
function subirImagen($fileKey, $carpeta = 'img') {
    if (empty($_FILES[$fileKey]['tmp_name'])) return null;
    $file = $_FILES[$fileKey];
    if ($file['error'] !== UPLOAD_ERR_OK) return null;
    $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
    $mime = mime_content_type($file['tmp_name']);
    if (!in_array($mime, $allowed)) return null;
    if ($file['size'] > 3 * 1024 * 1024) return null; // máx 3 MB
    $data = file_get_contents($file['tmp_name']);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ── PROCESAMIENTO DE FORMULARIOS ─────────────────────────────

// Guardar producto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_producto'])) {
    $id = (int)($_POST['prod_id'] ?? 0);

    // Manejar imagen subida
    $imgPrincipal = trim($_POST['imagen_principal'] ?? '');
    $imgSubida = subirImagen('imagen_file', 'img');
    if ($imgSubida) $imgPrincipal = $imgSubida;

    $data = [
        'categoria_id'     => (int)$_POST['categoria_id'],
        'nombre'           => trim($_POST['nombre']),
        'slug'             => trim($_POST['slug']) ?: strtolower(preg_replace('/[^a-z0-9]+/','-',trim($_POST['nombre']))),
        'descripcion_corta'=> trim($_POST['descripcion_corta']),
        'descripcion'      => trim($_POST['descripcion']),
        'ingredientes'     => trim($_POST['ingredientes']),
        'modo_uso'         => trim($_POST['modo_uso']),
        'precio'           => (float)str_replace(['.','$',' ','COP'],'',$_POST['precio']),
        'precio_antes'     => $_POST['precio_antes'] ? (float)str_replace(['.','$',' ','COP'],'',$_POST['precio_antes']) : null,
        'presentacion'     => trim($_POST['presentacion']),
        'stock'            => (int)$_POST['stock'],
        'invima'           => trim($_POST['invima']),
        'destacado'        => isset($_POST['destacado']) ? 1 : 0,
        'activo'           => isset($_POST['activo']) ? 1 : 0,
        'imagen_principal' => $imgPrincipal,
    ];
    if ($id > 0) {
        $set = implode(', ', array_map(fn($k) => "`$k`=:$k", array_keys($data)));
        $st  = $db->prepare("UPDATE productos SET $set WHERE id=:_id");
        $data['_id'] = $id;
        $st->execute($data);
        $msg = 'Producto actualizado correctamente.';
    } else {
        $cols = implode(', ', array_map(fn($k) => "`$k`", array_keys($data)));
        $phs  = implode(', ', array_map(fn($k) => ":$k", array_keys($data)));
        $st   = $db->prepare("INSERT INTO productos ($cols) VALUES ($phs)");
        $st->execute($data);
        $msg = 'Producto creado correctamente.';
    }
    header('Location: admin.php?page=productos&ok='.urlencode($msg));
    exit;
}

// Eliminar producto
if (isset($_GET['del_prod'])) {
    $db->prepare("DELETE FROM productos WHERE id=?")->execute([(int)$_GET['del_prod']]);
    header('Location: admin.php?page=productos&ok=Producto+eliminado.');
    exit;
}

// Guardar banner
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_banner'])) {
    $id = (int)($_POST['banner_id'] ?? 0);

    // Imagen del banner
    $imgBanner = trim($_POST['imagen_url'] ?? '');
    $imgBannerSubida = subirImagen('banner_file', 'img');
    if ($imgBannerSubida) $imgBanner = $imgBannerSubida;

    $data = [
        'titulo'    => trim($_POST['titulo']),
        'subtitulo' => trim($_POST['subtitulo']),
        'descripcion'=>trim($_POST['descripcion']),
        'imagen_url'=> $imgBanner,
        'boton_texto'=>trim($_POST['boton_texto']),
        'boton_url' => trim($_POST['boton_url']),
        'activo'    => isset($_POST['activo']) ? 1 : 0,
        'orden'     => (int)$_POST['orden'],
    ];
    if ($id > 0) {
        $set = implode(', ', array_map(fn($k) => "`$k`=:$k", array_keys($data)));
        $st  = $db->prepare("UPDATE banners SET $set WHERE id=:_id");
        $data['_id'] = $id;
        $st->execute($data);
    } else {
        $cols = implode(', ', array_map(fn($k) => "`$k`", array_keys($data)));
        $phs  = implode(', ', array_map(fn($k) => ":$k", array_keys($data)));
        $st   = $db->prepare("INSERT INTO banners ($cols) VALUES ($phs)");
        $st->execute($data);
    }
    header('Location: admin.php?page=banners&ok=Banner+guardado.');
    exit;
}

// Guardar Sobre Nosotros
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_nosotros'])) {
    $titulo = trim($_POST['nosotros_titulo'] ?? '');
    $texto  = trim($_POST['nosotros_texto']  ?? '');
    $db->prepare("INSERT INTO configuracion (clave, valor) VALUES ('nosotros_titulo', ?)
                  ON DUPLICATE KEY UPDATE valor=VALUES(valor)")->execute([$titulo]);
    $db->prepare("INSERT INTO configuracion (clave, valor) VALUES ('nosotros_texto', ?)
                  ON DUPLICATE KEY UPDATE valor=VALUES(valor)")->execute([$texto]);
    header('Location: admin.php?page=nosotros&ok=Contenido+guardado.');
    exit;
}

// Guardar categoría
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_categoria'])) {
    $id = (int)($_POST['cat_id'] ?? 0);
    // Imagen banner de categoría
    $imgBannerCat = trim($_POST['imagen_banner'] ?? '');
    $imgBannerCatSubida = subirImagen('cat_banner_file', 'img');
    if ($imgBannerCatSubida) $imgBannerCat = $imgBannerCatSubida;
    $data = [
        'nombre'        => trim($_POST['nombre']),
        'slug'          => trim($_POST['slug']) ?: strtolower(preg_replace('/[^a-z0-9]+/','-',trim($_POST['nombre']))),
        'descripcion'   => trim($_POST['descripcion']),
        'icono'         => trim($_POST['icono']) ?: 'eco',
        'orden'         => (int)$_POST['orden'],
        'activa'        => isset($_POST['activa']) ? 1 : 0,
        'imagen_banner' => $imgBannerCat,
    ];
    if ($id > 0) {
        // Si no se subió nueva imagen, conservar la actual
        if (!$imgBannerCat) unset($data['imagen_banner']);
        $set = implode(', ', array_map(fn($k) => "`$k`=:$k", array_keys($data)));
        $st  = $db->prepare("UPDATE categorias SET $set WHERE id=:_id");
        $data['_id'] = $id;
        $st->execute($data);
    } else {
        $cols = implode(', ', array_map(fn($k) => "`$k`", array_keys($data)));
        $phs  = implode(', ', array_map(fn($k) => ":$k", array_keys($data)));
        $st   = $db->prepare("INSERT INTO categorias ($cols) VALUES ($phs)");
        $st->execute($data);
    }
    header('Location: admin.php?page=categorias&ok=Categoría+guardada.');
    exit;
}

// ── Cargar datos para las páginas ─────────────────────────────
$ok  = isset($_GET['ok']) ? urldecode($_GET['ok']) : '';

// Config Sobre Nosotros
function getConfigAdmin($db, $clave, $default = '') {
    $st = $db->prepare("SELECT valor FROM configuracion WHERE clave=?");
    $st->execute([$clave]);
    $v = $st->fetchColumn();
    return $v !== false ? $v : $default;
}

// Cambiar estado de pedido
if (isset($_GET['pedido_estado']) && isset($_GET['pedido_id'])) {
    $estados = ['nuevo','confirmado','despachado','entregado','cancelado'];
    $nuevoEstado = $_GET['pedido_estado'];
    if (in_array($nuevoEstado, $estados)) {
        $db->prepare("UPDATE pedidos SET estado=? WHERE id=?")->execute([$nuevoEstado,(int)$_GET['pedido_id']]);
    }
    header('Location: admin.php?page=pedidos&ok=Estado+actualizado.');
    exit;
}

// Stats para dashboard
$totalProductos  = $db->query("SELECT COUNT(*) FROM productos WHERE activo=1")->fetchColumn();
$totalCategorias = $db->query("SELECT COUNT(*) FROM categorias WHERE activa=1")->fetchColumn();
$totalBanners    = $db->query("SELECT COUNT(*) FROM banners WHERE activo=1")->fetchColumn();
$stockCritico    = $db->query("SELECT COUNT(*) FROM productos WHERE activo=1 AND stock < 10")->fetchColumn();
$totalPedidos    = $db->query("SELECT COUNT(*) FROM pedidos")->fetchColumn();
$pedidosNuevos   = $db->query("SELECT COUNT(*) FROM pedidos WHERE estado='nuevo'")->fetchColumn();
$productosLista  = $db->query("SELECT p.*, c.nombre as cat_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id ORDER BY p.id DESC")->fetchAll();
$categoriasLista = $db->query("SELECT * FROM categorias ORDER BY orden ASC")->fetchAll();
$bannersLista    = $db->query("SELECT * FROM banners ORDER BY orden ASC")->fetchAll();
$pedidosLista    = $db->query("SELECT * FROM pedidos ORDER BY created_at DESC LIMIT 50")->fetchAll();

// Producto para editar
$editProd = null;
if (isset($_GET['edit_prod'])) {
    $st = $db->prepare("SELECT * FROM productos WHERE id=?");
    $st->execute([(int)$_GET['edit_prod']]);
    $editProd = $st->fetch();
}
$editBanner = null;
if (isset($_GET['edit_banner'])) {
    $st = $db->prepare("SELECT * FROM banners WHERE id=?");
    $st->execute([(int)$_GET['edit_banner']]);
    $editBanner = $st->fetch();
}
$editCat = null;
if (isset($_GET['edit_cat'])) {
    $st = $db->prepare("SELECT * FROM categorias WHERE id=?");
    $st->execute([(int)$_GET['edit_cat']]);
    $editCat = $st->fetch();
}

?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verde Natural</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='32' fill='%23176b4b'/%3E%3Cpath d='M32 12 C20 20 16 30 20 44 C24 36 28 32 32 30 C36 32 40 36 44 44 C48 30 44 20 32 12Z' fill='%23a4f3ca'/%3E%3Cline x1='32' y1='30' x2='32' y2='50' stroke='%23a4f3ca' stroke-width='2.5' stroke-linecap='round'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style>
* { font-family:'Plus Jakarta Sans',sans-serif; }
.material-symbols-outlined { font-family:'Material Symbols Outlined';font-style:normal;font-weight:normal;display:inline-block;line-height:1;text-transform:none;white-space:nowrap;direction:ltr;-webkit-font-feature-settings:'liga';font-feature-settings:'liga';-webkit-font-smoothing:antialiased; }
::-webkit-scrollbar { width:4px; height:4px; }
::-webkit-scrollbar-track { background:#f1f5f0; }
::-webkit-scrollbar-thumb { background:#88d6af; border-radius:4px; }
.nav-link { display:flex; align-items:center; gap:10px; padding:8px 16px; border-radius:999px; font-size:13px; font-weight:500; color:#414845; transition:all .2s; }
.nav-link:hover { background:#e5e9e4; color:#181d1a; }
.nav-link.active { background:#173f33; color:#81aa9b; font-weight:600; box-shadow:0 2px 8px rgba(23,63,51,.15); }
.stat-card { background:#fff; border-radius:16px; padding:20px; box-shadow:0 4px 16px -2px rgba(23,63,51,.05); transition:box-shadow .2s; }
.stat-card:hover { box-shadow:0 8px 24px -4px rgba(23,63,51,.1); }
.form-input { width:100%; background:#f1f5f0; border:1.5px solid #c1c8c3; border-radius:12px; padding:10px 14px; font-size:14px; color:#181d1a; outline:none; transition:border-color .2s; }
.form-input:focus { border-color:#176b4b; background:#fff; }
.form-label { font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.05em; color:#414845; display:block; margin-bottom:6px; }
.btn-primary { background:#176b4b; color:#fff; padding:10px 20px; border-radius:999px; font-size:14px; font-weight:600; cursor:pointer; transition:all .2s; border:none; display:inline-flex; align-items:center; gap:6px; }
.btn-primary:hover { background:#00291e; }
.btn-ghost { background:#f1f5f0; color:#414845; padding:8px 16px; border-radius:999px; font-size:13px; font-weight:500; cursor:pointer; transition:all .2s; border:none; display:inline-flex; align-items:center; gap:6px; }
.btn-ghost:hover { background:#e5e9e4; color:#181d1a; }
.btn-danger { background:#ffdad6; color:#93000a; padding:8px 16px; border-radius:999px; font-size:13px; font-weight:500; cursor:pointer; transition:all .2s; border:none; display:inline-flex; align-items:center; gap:6px; }
.btn-danger:hover { background:#ba1a1a; color:#fff; }
.modal { display:none; position:fixed; inset:0; z-index:100; }
.modal.active { display:flex; }
</style>
</head>
<body style="background:#f6faf5; color:#181d1a; min-height:100vh;">

<!-- ═══════════════════════════════════════════════════════════
     SIDEBAR
     ═══════════════════════════════════════════════════════════ -->
<aside style="position:fixed;left:0;top:0;width:256px;height:100%;background:#f1f5f0;z-index:50;display:flex;flex-direction:column;padding:20px 0;box-shadow:1px 0 12px rgba(23,63,51,.03);">
  <!-- Logo -->
  <div style="padding:0 20px 20px;display:flex;align-items:center;gap:10px;">
    <svg width="38" height="38" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">
      <ellipse cx="60" cy="62" rx="42" ry="52" fill="#176b4b"/>
      <path d="M60 100 C60 100 60 50 60 25" stroke="white" stroke-width="5" stroke-linecap="round"/>
      <path d="M60 60 C45 50 30 42 28 28" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
      <path d="M60 75 C45 65 32 60 30 46" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
      <path d="M60 60 C75 50 90 42 92 28" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
      <path d="M60 75 C75 65 88 60 90 46" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
    </svg>
    <div>
      <span style="font-size:15px;font-weight:800;color:#00291e;display:block;letter-spacing:-.01em;">Verde Natural</span>
      <span style="font-size:10px;color:#717975;text-transform:uppercase;letter-spacing:.06em;">Admin</span>
    </div>
  </div>

  <!-- Sección operación -->
  <div style="padding:0 20px 8px;">
    <span style="font-size:10px;color:#717975;font-weight:600;text-transform:uppercase;letter-spacing:.08em;">Operación</span>
  </div>
  <nav style="flex:1;padding:0 12px;display:flex;flex-direction:column;gap:4px;">
    <a href="admin.php?page=dashboard"     class="nav-link <?= $page==='dashboard' ? 'active':'' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">dashboard</span>Panel de Control</a>
    <a href="admin.php?page=productos"     class="nav-link <?= $page==='productos' ? 'active':'' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">potted_plant</span>Productos</a>
    <a href="admin.php?page=categorias"    class="nav-link <?= $page==='categorias' ? 'active':'' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">category</span>Categorías</a>
    <a href="admin.php?page=banners"       class="nav-link <?= $page==='banners' ? 'active':'' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">campaign</span>Banners</a>
    <a href="admin.php?page=pedidos"      class="nav-link <?= $page==='pedidos' ? 'active':'' ?>" style="<?= $pedidosNuevos > 0 ? 'position:relative;' : '' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">receipt_long</span>Pedidos
      <?php if ($pedidosNuevos > 0): ?>
      <span style="margin-left:auto;background:#93000a;color:#fff;border-radius:999px;font-size:11px;font-weight:700;padding:1px 7px;"><?= $pedidosNuevos ?></span>
      <?php endif; ?>
    </a>
    <a href="admin.php?page=clientes"     class="nav-link <?= $page==='clientes' ? 'active':'' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">group</span>Clientes</a>
    <a href="admin.php?page=nosotros"     class="nav-link <?= $page==='nosotros' ? 'active':'' ?>">
      <span class="material-symbols-outlined" style="font-size:20px;">info</span>Sobre Nosotros</a>
    <div style="height:1px;background:#c1c8c3;margin:8px 4px;"></div>
    <a href="index.php" target="_blank" class="nav-link">
      <span class="material-symbols-outlined" style="font-size:20px;">storefront</span>Ver tienda</a>
    <a href="admin.php?logout=1" class="nav-link" style="color:#93000a;" onclick="return confirm('¿Cerrar sesión?')">
      <span class="material-symbols-outlined" style="font-size:20px;">logout</span>Cerrar sesión</a>
  </nav>

  <!-- Estado -->
  <div style="padding:12px 16px;">
    <div style="background:#fff;padding:10px 14px;border-radius:12px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 8px rgba(23,63,51,.04);">
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="width:8px;height:8px;border-radius:50%;background:#176b4b;display:inline-block;"></span>
        <span style="font-size:13px;font-weight:500;">Verde Natural</span>
      </div>
      <span style="font-size:12px;font-weight:600;color:#176b4b;">COP $</span>
    </div>
  </div>
</aside>

<!-- Contenido principal (con margen izquierdo) -->
<div style="margin-left:256px;min-height:100vh;">

<!-- Header top -->
<header style="position:sticky;top:0;background:rgba(246,250,245,.92);backdrop-filter:blur(16px);z-index:40;height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 24px;box-shadow:0 1px 8px rgba(23,63,51,.03);">
  <div style="display:flex;align-items:center;gap:12px;">
    <span style="font-size:18px;font-weight:700;color:#00291e;">
      <?= [
        'dashboard'  => 'Panel de Control',
        'productos'  => 'Productos',
        'categorias' => 'Categorías',
        'banners'    => 'Banners',
        'pedidos'    => 'Pedidos',
        'nosotros'   => 'Sobre Nosotros',
      ][$page] ?? 'Admin' ?>
    </span>
  </div>
  <div style="display:flex;align-items:center;gap:12px;">
    <div style="display:flex;align-items:center;gap:8px;background:#ebefea;padding:6px 14px;border-radius:999px;">
      <span class="material-symbols-outlined" style="font-size:18px;color:#717975;">person</span>
      <span style="font-size:13px;font-weight:600;color:#181d1a;"><?= h($adminNombre) ?></span>
    </div>
    <a href="admin.php?logout=1" onclick="return confirm('¿Cerrar sesión?')"
       style="display:flex;align-items:center;gap:6px;padding:6px 14px;background:#ffdad6;color:#93000a;border-radius:999px;font-size:13px;font-weight:600;text-decoration:none;">
      <span class="material-symbols-outlined" style="font-size:18px;">logout</span>Salir
    </a>
  </div>
</header>

<main style="padding:24px;">

<?php if ($ok): ?>
<div style="background:#a4f3ca;color:#005236;padding:12px 20px;border-radius:12px;margin-bottom:20px;display:flex;align-items:center;gap:8px;font-size:14px;font-weight:500;">
  <span class="material-symbols-outlined" style="font-size:18px;">check_circle</span>
  <?= h($ok) ?>
</div>
<?php endif; ?>

<?php
// ── ACCIONES CLIENTES ─────────────────────────────────────────
if (isset($_GET['toggle_cliente'])) {
    $db = getDB();
    $id = (int)$_GET['toggle_cliente'];
    $db->prepare("UPDATE clientes SET activo = NOT activo WHERE id=?")->execute([$id]);
    header('Location: admin.php?page=clientes'); exit;
}
if (isset($_GET['del_cliente']) && isset($_GET['_confirm'])) {
    $db = getDB();
    $db->prepare("DELETE FROM clientes WHERE id=?")->execute([(int)$_GET['del_cliente']]);
    header('Location: admin.php?page=clientes&ok=Cliente+eliminado.'); exit;
}
?>
<?php if ($page === 'dashboard'): ?>
<!-- ═══════════════════════════════════════════════════════════
     DASHBOARD
     ═══════════════════════════════════════════════════════════ -->

<!-- Header resumen -->
<div style="background:#fff;border-radius:16px;padding:24px;margin-bottom:24px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px;">
  <div>
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
      <span style="display:inline-flex;align-items:center;gap:6px;background:#a4f3ca;color:#005236;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;">
        <span style="width:6px;height:6px;border-radius:50%;background:#176b4b;animation:pulse 2s infinite;display:inline-block;"></span>
        Activo
      </span>
    </div>
    <h1 style="font-size:22px;font-weight:700;color:#00291e;">Resumen General — Verde Natural</h1>
    <p style="font-size:14px;color:#414845;margin-top:4px;">Supervisión del catálogo, inventario y banners de la tienda.</p>
  </div>
  <a href="index.php" target="_blank"
     style="display:inline-flex;align-items:center;gap:8px;background:#ebefea;color:#00291e;padding:10px 18px;border-radius:999px;font-size:13px;font-weight:600;text-decoration:none;transition:all .2s;">
    <span class="material-symbols-outlined" style="font-size:18px;">storefront</span>
    Ver tienda online
    <span class="material-symbols-outlined" style="font-size:16px;">open_in_new</span>
  </a>
</div>

<!-- Stats cards -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-bottom:24px;">
  <div class="stat-card">
    <div style="display:flex;align-items:start;justify-content:space-between;">
      <div style="width:40px;height:40px;border-radius:50%;background:#a4f3ca;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="color:#176b4b;font-size:20px;">potted_plant</span>
      </div>
      <span style="background:#a4f3ca;color:#005236;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">Activos</span>
    </div>
    <div style="margin-top:16px;">
      <span style="font-size:11px;color:#717975;text-transform:uppercase;letter-spacing:.06em;display:block;">Productos en Catálogo</span>
      <span style="font-size:36px;font-weight:700;color:#00291e;line-height:1.1;"><?= $totalProductos ?></span>
      <span style="font-size:12px;color:#414845;">referencias disponibles</span>
    </div>
    <a href="admin.php?page=productos" style="display:flex;align-items:center;justify-content:space-between;background:#f1f5f0;padding:6px 12px;border-radius:999px;margin-top:12px;font-size:12px;font-weight:500;color:#414845;text-decoration:none;">
      <span>Gestionar productos</span>
      <span class="material-symbols-outlined" style="font-size:16px;">arrow_forward</span>
    </a>
  </div>

  <div class="stat-card">
    <div style="display:flex;align-items:start;justify-content:space-between;">
      <div style="width:40px;height:40px;border-radius:50%;background:#173f33;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="color:#a5d0bf;font-size:20px;">category</span>
      </div>
      <span style="background:#ebefea;color:#414845;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">Catálogo</span>
    </div>
    <div style="margin-top:16px;">
      <span style="font-size:11px;color:#717975;text-transform:uppercase;letter-spacing:.06em;display:block;">Categorías Activas</span>
      <span style="font-size:36px;font-weight:700;color:#00291e;line-height:1.1;"><?= $totalCategorias ?></span>
      <span style="font-size:12px;color:#414845;">grupos de productos</span>
    </div>
    <a href="admin.php?page=categorias" style="display:flex;align-items:center;justify-content:space-between;background:#f1f5f0;padding:6px 12px;border-radius:999px;margin-top:12px;font-size:12px;font-weight:500;color:#414845;text-decoration:none;">
      <span>Gestionar categorías</span>
      <span class="material-symbols-outlined" style="font-size:16px;">arrow_forward</span>
    </a>
  </div>

  <div class="stat-card">
    <div style="display:flex;align-items:start;justify-content:space-between;">
      <div style="width:40px;height:40px;border-radius:50%;background:#ffddaf;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="color:#321f00;font-size:20px;">campaign</span>
      </div>
      <span style="background:#a4f3ca;color:#005236;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">En rotación</span>
    </div>
    <div style="margin-top:16px;">
      <span style="font-size:11px;color:#717975;text-transform:uppercase;letter-spacing:.06em;display:block;">Banners &amp; Campañas</span>
      <span style="font-size:36px;font-weight:700;color:#00291e;line-height:1.1;"><?= $totalBanners ?></span>
      <span style="font-size:12px;color:#414845;">banners activos</span>
    </div>
    <a href="admin.php?page=banners" style="display:flex;align-items:center;justify-content:space-between;background:#f1f5f0;padding:6px 12px;border-radius:999px;margin-top:12px;font-size:12px;font-weight:500;color:#414845;text-decoration:none;">
      <span>Gestionar banners</span>
      <span class="material-symbols-outlined" style="font-size:16px;">arrow_forward</span>
    </a>
  </div>

  <div class="stat-card" style="<?= $stockCritico > 0 ? 'border:1.5px solid #ffdad6;' : '' ?>">
    <div style="display:flex;align-items:start;justify-content:space-between;">
      <div style="width:40px;height:40px;border-radius:50%;background:#ffdad6;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="color:#93000a;font-size:20px;">inventory_2</span>
      </div>
      <span style="background:<?= $stockCritico > 0 ? '#ffdad6' : '#a4f3ca' ?>;color:<?= $stockCritico > 0 ? '#93000a' : '#005236' ?>;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
        <?= $stockCritico > 0 ? '¡Alerta!' : 'OK' ?>
      </span>
    </div>
    <div style="margin-top:16px;">
      <span style="font-size:11px;color:#717975;text-transform:uppercase;letter-spacing:.06em;display:block;">Stock Crítico</span>
      <span style="font-size:36px;font-weight:700;color:<?= $stockCritico > 0 ? '#93000a' : '#00291e' ?>;line-height:1.1;"><?= $stockCritico ?></span>
      <span style="font-size:12px;color:#414845;">productos con menos de 10 un.</span>
    </div>
    <a href="admin.php?page=productos&filter=critico" style="display:flex;align-items:center;justify-content:space-between;background:#f1f5f0;padding:6px 12px;border-radius:999px;margin-top:12px;font-size:12px;font-weight:500;color:#414845;text-decoration:none;">
      <span>Ver alertas</span>
      <span class="material-symbols-outlined" style="font-size:16px;">arrow_forward</span>
    </a>
  </div>

  <div class="stat-card">
    <div style="display:flex;align-items:start;justify-content:space-between;">
      <div style="width:40px;height:40px;border-radius:50%;background:#c8e6ff;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="color:#003a6b;font-size:20px;">receipt_long</span>
      </div>
      <span style="background:#c8e6ff;color:#003a6b;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">Total</span>
    </div>
    <div style="margin-top:16px;">
      <span style="font-size:11px;color:#717975;text-transform:uppercase;letter-spacing:.06em;display:block;">Pedidos Recibidos</span>
      <span style="font-size:36px;font-weight:700;color:#00291e;line-height:1.1;"><?= $totalPedidos ?></span>
      <span style="font-size:12px;color:#414845;">pedidos en total</span>
    </div>
    <a href="admin.php?page=pedidos" style="display:flex;align-items:center;justify-content:space-between;background:#f1f5f0;padding:6px 12px;border-radius:999px;margin-top:12px;font-size:12px;font-weight:500;color:#414845;text-decoration:none;">
      <span>Ver pedidos</span>
      <span class="material-symbols-outlined" style="font-size:16px;">arrow_forward</span>
    </a>
  </div>

  <?php if ($pedidosNuevos > 0): ?>
  <div class="stat-card" style="border:1.5px solid #ffdad6;">
    <div style="display:flex;align-items:start;justify-content:space-between;">
      <div style="width:40px;height:40px;border-radius:50%;background:#ffdad6;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="color:#93000a;font-size:20px;">notification_important</span>
      </div>
      <span style="background:#ffdad6;color:#93000a;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">Sin confirmar</span>
    </div>
    <div style="margin-top:16px;">
      <span style="font-size:11px;color:#717975;text-transform:uppercase;letter-spacing:.06em;display:block;">Pedidos Nuevos</span>
      <span style="font-size:36px;font-weight:700;color:#93000a;line-height:1.1;"><?= $pedidosNuevos ?></span>
      <span style="font-size:12px;color:#414845;">esperan confirmación</span>
    </div>
    <a href="admin.php?page=pedidos" style="display:flex;align-items:center;justify-content:space-between;background:#ffdad6;padding:6px 12px;border-radius:999px;margin-top:12px;font-size:12px;font-weight:600;color:#93000a;text-decoration:none;">
      <span>Revisar ahora</span>
      <span class="material-symbols-outlined" style="font-size:16px;">arrow_forward</span>
    </a>
  </div>
  <?php endif; ?>
</div>

<!-- Tabla rápida de productos con stock bajo -->
<?php
$criticos = $db->query("SELECT p.*, c.nombre as cat_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id WHERE p.activo=1 AND p.stock < 10 ORDER BY p.stock ASC LIMIT 5")->fetchAll();
if (!empty($criticos)): ?>
<div style="background:#fff;border-radius:16px;padding:24px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
    <div>
      <h2 style="font-size:16px;font-weight:700;color:#00291e;">⚠️ Alertas de Inventario Crítico</h2>
      <p style="font-size:12px;color:#717975;margin-top:2px;">Productos con stock por debajo de 10 unidades</p>
    </div>
    <a href="admin.php?page=productos" style="display:inline-flex;align-items:center;gap:4px;background:#a4f3ca;color:#005236;padding:6px 12px;border-radius:999px;font-size:12px;font-weight:600;text-decoration:none;">
      Ver todos <span class="material-symbols-outlined" style="font-size:14px;">arrow_forward</span>
    </a>
  </div>
  <div style="display:flex;flex-direction:column;gap:10px;">
    <?php foreach ($criticos as $p): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;background:#f6faf5;padding:12px 16px;border-radius:12px;">
      <div>
        <span style="font-size:14px;font-weight:600;color:#00291e;"><?= h($p['nombre']) ?></span>
        <span style="font-size:12px;color:#717975;display:block;"><?= h($p['cat_nombre'].' — '.$p['presentacion']) ?></span>
      </div>
      <div style="text-align:right;">
        <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;<?= $p['stock']<=4 ? 'background:#ffdad6;color:#93000a;' : 'background:#ffddaf;color:#321f00;' ?>">
          <?= (int)$p['stock'] ?> u.
        </span>
        <span style="display:block;font-size:11px;color:#717975;margin-top:2px;"><?= $p['stock']<=4 ? 'URGENTE' : 'Bajo' ?></span>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- Pedidos recientes en dashboard -->
<?php
$pedidosRecientes = $db->query("SELECT * FROM pedidos ORDER BY created_at DESC LIMIT 5")->fetchAll();
if (!empty($pedidosRecientes)):
$estadoColors = [
  'nuevo'      => 'background:#c8e6ff;color:#003a6b;',
  'confirmado' => 'background:#a4f3ca;color:#005236;',
  'despachado' => 'background:#ffddaf;color:#321f00;',
  'entregado'  => 'background:#173f33;color:#a5d0bf;',
  'cancelado'  => 'background:#ffdad6;color:#93000a;',
];
$estadoLabel = [
  'nuevo'=>'Nuevo','confirmado'=>'Confirmado','despachado'=>'Despachado','entregado'=>'Entregado','cancelado'=>'Cancelado'
];
?>
<div style="background:#fff;border-radius:16px;padding:24px;margin-top:24px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
    <div>
      <h2 style="font-size:16px;font-weight:700;color:#00291e;">📦 Pedidos Recientes</h2>
      <p style="font-size:12px;color:#717975;margin-top:2px;">Últimas 5 órdenes recibidas</p>
    </div>
    <a href="admin.php?page=pedidos" style="display:inline-flex;align-items:center;gap:4px;background:#a4f3ca;color:#005236;padding:6px 12px;border-radius:999px;font-size:12px;font-weight:600;text-decoration:none;">
      Ver todos <span class="material-symbols-outlined" style="font-size:14px;">arrow_forward</span>
    </a>
  </div>
  <div style="display:flex;flex-direction:column;gap:10px;">
    <?php foreach ($pedidosRecientes as $ped):
      $items = json_decode($ped['items'] ?? '[]', true);
      $numItems = array_sum(array_column($items, 'qty'));
    ?>
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;background:#f6faf5;padding:12px 16px;border-radius:12px;">
      <div style="display:flex;align-items:center;gap:12px;">
        <div style="width:36px;height:36px;border-radius:50%;background:#ebefea;display:flex;align-items:center;justify-content:center;">
          <span class="material-symbols-outlined" style="font-size:18px;color:#176b4b;">package_2</span>
        </div>
        <div>
          <span style="font-size:13px;font-weight:700;color:#00291e;display:block;"><?= h($ped['numero_pedido']) ?></span>
          <span style="font-size:12px;color:#717975;"><?= h($ped['nombre_cliente'] ?: 'Cliente') ?> · <?= $numItems ?> producto<?= $numItems!=1?'s':'' ?></span>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:14px;font-weight:600;color:#00291e;"><?= formatPrice($ped['total']) ?></span>
        <span style="padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;<?= $estadoColors[$ped['estado']] ?? '' ?>">
          <?= $estadoLabel[$ped['estado']] ?? $ped['estado'] ?>
        </span>
        <span style="font-size:11px;color:#717975;"><?= date('d/m', strtotime($ped['created_at'])) ?></span>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>


<?php elseif ($page === 'productos'): ?>
<!-- ═══════════════════════════════════════════════════════════
     PRODUCTOS
     ═══════════════════════════════════════════════════════════ -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:18px;font-weight:700;color:#00291e;">Catálogo de Productos</h2>
    <p style="font-size:13px;color:#717975;"><?= count($productosLista) ?> productos en total</p>
  </div>
  <button onclick="showModal('modalProducto')" class="btn-primary">
    <span class="material-symbols-outlined" style="font-size:18px;">add</span>
    Nuevo Producto
  </button>
</div>

<!-- Tabla de productos -->
<div style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);">
  <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;min-width:700px;">
      <thead>
        <tr style="background:#f1f5f0;">
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#717975;">Producto</th>
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#717975;">Categoría</th>
          <th style="padding:12px 16px;text-align:right;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#717975;">Precio</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#717975;">Stock</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#717975;">Estado</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#717975;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($productosLista as $p): ?>
        <tr style="border-top:1px solid #f1f5f0;transition:background .15s;" onmouseover="this.style.background='#f6faf5'" onmouseout="this.style.background=''">
          <td style="padding:12px 16px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <?php if ($p['imagen_principal']): ?>
              <img src="<?= h($p['imagen_principal']) ?>" alt="" style="width:40px;height:40px;border-radius:8px;object-fit:cover;background:#ebefea;">
              <?php else: ?>
              <div style="width:40px;height:40px;border-radius:8px;background:#a1f0c7;display:flex;align-items:center;justify-content:center;">
                <span class="material-symbols-outlined" style="color:#176b4b;font-size:20px;">eco</span>
              </div>
              <?php endif; ?>
              <div>
                <span style="font-size:14px;font-weight:600;color:#00291e;display:block;"><?= h($p['nombre']) ?></span>
                <span style="font-size:11px;color:#717975;"><?= h($p['presentacion']) ?></span>
              </div>
            </div>
          </td>
          <td style="padding:12px 16px;font-size:13px;color:#414845;"><?= h($p['cat_nombre'] ?? '—') ?></td>
          <td style="padding:12px 16px;font-size:14px;font-weight:600;color:#00291e;text-align:right;"><?= formatPrice($p['precio']) ?></td>
          <td style="padding:12px 16px;text-align:center;">
            <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;<?= $p['stock']<=0 ? 'background:#ffdad6;color:#93000a;' : ($p['stock']<10 ? 'background:#ffddaf;color:#321f00;' : 'background:#a4f3ca;color:#005236;') ?>">
              <?= (int)$p['stock'] ?>
            </span>
          </td>
          <td style="padding:12px 16px;text-align:center;">
            <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;<?= $p['activo'] ? 'background:#a4f3ca;color:#005236;' : 'background:#dfe4df;color:#717975;' ?>">
              <?= $p['activo'] ? 'Activo' : 'Pausado' ?>
            </span>
            <?php if ($p['destacado']): ?>
            <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;background:#ffddaf;color:#321f00;margin-left:4px;">⭐</span>
            <?php endif; ?>
          </td>
          <td style="padding:12px 16px;text-align:center;">
            <div style="display:flex;align-items:center;justify-content:center;gap:6px;">
              <a href="admin.php?page=productos&edit_prod=<?= $p['id'] ?>" class="btn-ghost" style="padding:6px 10px;" title="Editar">
                <span class="material-symbols-outlined" style="font-size:16px;">edit</span>
              </a>
              <button type="button" class="btn-danger" style="padding:6px 10px;border:none;cursor:pointer;" title="Eliminar"
                onclick="confirmarEliminar(<?= $p['id'] ?>, '<?= h(addslashes($p['nombre'])) ?>')">
                <span class="material-symbols-outlined" style="font-size:16px;">delete</span>
              </button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($productosLista)): ?>
        <tr><td colspan="6" style="padding:40px;text-align:center;color:#717975;">No hay productos. <a href="#" onclick="showModal('modalProducto')" style="color:#176b4b;">Crear el primero</a></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: confirmar eliminación -->
<div id="modalEliminar" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:20px;padding:32px 28px;width:100%;max-width:380px;margin:16px;box-shadow:0 24px 64px rgba(0,0,0,.18);text-align:center;">
    <div style="width:56px;height:56px;border-radius:50%;background:#ffdad6;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
      <span class="material-symbols-outlined" style="color:#93000a;font-size:28px;">delete_forever</span>
    </div>
    <h3 style="font-size:17px;font-weight:700;color:#00291e;margin-bottom:8px;">¿Eliminar producto?</h3>
    <p style="font-size:14px;color:#717975;margin-bottom:24px;">
      Se eliminará <strong id="eliminarNombre" style="color:#00291e;"></strong> permanentemente. Esta acción no se puede deshacer.
    </p>
    <div style="display:flex;gap:10px;">
      <button onclick="cerrarEliminar()" style="flex:1;padding:12px;border-radius:999px;border:1.5px solid #c1c8c3;background:#fff;font-size:14px;font-weight:600;color:#414845;cursor:pointer;">
        Cancelar
      </button>
      <a id="eliminarLink" href="#" style="flex:1;padding:12px;border-radius:999px;background:#ba1a1a;color:#fff;font-size:14px;font-weight:700;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:6px;">
        <span class="material-symbols-outlined" style="font-size:16px;">delete</span>
        Eliminar
      </a>
    </div>
  </div>
</div>
<script>
function confirmarEliminar(id, nombre) {
  document.getElementById('eliminarNombre').textContent = nombre;
  document.getElementById('eliminarLink').href = 'admin.php?del_prod=' + id;
  var m = document.getElementById('modalEliminar');
  m.style.display = 'flex';
}
function cerrarEliminar() {
  document.getElementById('modalEliminar').style.display = 'none';
}
document.getElementById('modalEliminar').addEventListener('click', function(e) {
  if (e.target === this) cerrarEliminar();
});
</script>

<!-- Modal: formulario de producto -->
<div id="modalProducto" class="modal" style="align-items:flex-start;justify-content:center;background:rgba(0,0,0,.4);overflow-y:auto;padding:24px 16px;">
  <div style="background:#fff;border-radius:20px;padding:28px;width:100%;max-width:680px;box-shadow:0 24px 48px rgba(0,0,0,.12);margin:auto;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
      <h3 style="font-size:18px;font-weight:700;color:#00291e;"><?= $editProd ? 'Editar Producto' : 'Nuevo Producto' ?></h3>
      <button onclick="hideModal('modalProducto')" style="width:36px;height:36px;border-radius:50%;background:#f1f5f0;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:20px;color:#717975;">close</span>
      </button>
    </div>
    <form method="POST" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:14px;">
      <input type="hidden" name="save_producto" value="1">
      <input type="hidden" name="prod_id" value="<?= (int)($editProd['id'] ?? 0) ?>">

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Nombre del producto *</label>
          <input name="nombre" class="form-input" required value="<?= h($editProd['nombre'] ?? '') ?>" placeholder="Jarabe de Totumo...">
        </div>
        <div>
          <label class="form-label">Slug (URL)</label>
          <input name="slug" class="form-input" value="<?= h($editProd['slug'] ?? '') ?>" placeholder="jarabe-totumo">
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Categoría</label>
          <select name="categoria_id" class="form-input">
            <option value="">— Sin categoría —</option>
            <?php foreach ($categoriasLista as $c): ?>
            <option value="<?= $c['id'] ?>" <?= (($editProd['categoria_id'] ?? 0) == $c['id']) ? 'selected' : '' ?>><?= h($c['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="form-label">Presentación</label>
          <input name="presentacion" class="form-input" value="<?= h($editProd['presentacion'] ?? '') ?>" placeholder="Frasco 360ml">
        </div>
      </div>

      <div>
        <label class="form-label">Descripción corta</label>
        <input name="descripcion_corta" class="form-input" value="<?= h($editProd['descripcion_corta'] ?? '') ?>" placeholder="Breve descripción del producto (máx 150 chars)">
      </div>

      <div>
        <label class="form-label">Descripción completa</label>
        <textarea name="descripcion" class="form-input" rows="3" placeholder="Descripción detallada del producto..."><?= h($editProd['descripcion'] ?? '') ?></textarea>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Precio (COP) *</label>
          <input name="precio" class="form-input" required value="<?= h($editProd['precio'] ?? '') ?>" placeholder="28000">
        </div>
        <div>
          <label class="form-label">Precio antes (tachado)</label>
          <input name="precio_antes" class="form-input" value="<?= h($editProd['precio_antes'] ?? '') ?>" placeholder="34000">
        </div>
        <div>
          <label class="form-label">Stock (unidades)</label>
          <input name="stock" type="number" min="0" class="form-input" value="<?= h($editProd['stock'] ?? 0) ?>">
        </div>
      </div>

      <div>
        <label class="form-label">Registro INVIMA</label>
        <input name="invima" class="form-input" value="<?= h($editProd['invima'] ?? '') ?>" placeholder="PFM2021-000214-R1">
      </div>

      <div>
        <label class="form-label">Imagen del producto</label>
        <?php if (!empty($editProd['imagen_principal'])): ?>
        <div style="margin-bottom:8px;display:flex;align-items:center;gap:10px;">
          <img src="<?= h($editProd['imagen_principal']) ?>" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:10px;border:2px solid #c1c8c3;">
          <span style="font-size:12px;color:#717975;">Imagen actual</span>
        </div>
        <?php endif; ?>
        <input type="file" name="imagen_file" accept="image/jpeg,image/png,image/webp,image/gif"
               class="form-input" style="padding:6px;">
        <p style="font-size:11px;color:#717975;margin-top:4px;">JPG, PNG, WebP — máx. 5 MB. Deja vacío para conservar la imagen actual.</p>
        <label class="form-label" style="margin-top:8px;">O pega una URL de imagen</label>
        <input name="imagen_principal" class="form-input" value="<?= h($editProd['imagen_principal'] ?? '') ?>" placeholder="https://...imagen.jpg">
      </div>

      <div>
        <label class="form-label">Ingredientes</label>
        <textarea name="ingredientes" class="form-input" rows="2"><?= h($editProd['ingredientes'] ?? '') ?></textarea>
      </div>

      <div>
        <label class="form-label">Modo de uso</label>
        <textarea name="modo_uso" class="form-input" rows="2"><?= h($editProd['modo_uso'] ?? '') ?></textarea>
      </div>

      <div style="display:flex;gap:20px;">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;color:#181d1a;">
          <input type="checkbox" name="destacado" <?= !empty($editProd['destacado']) ? 'checked' : '' ?> style="width:16px;height:16px;accent-color:#176b4b;">
          Producto destacado ⭐
        </label>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;color:#181d1a;">
          <input type="checkbox" name="activo" <?= (!isset($editProd) || !empty($editProd['activo'])) ? 'checked' : '' ?> style="width:16px;height:16px;accent-color:#176b4b;">
          Visible en tienda
        </label>
      </div>

      <div style="display:flex;gap:10px;margin-top:4px;">
        <button type="submit" class="btn-primary">
          <span class="material-symbols-outlined" style="font-size:18px;">save</span>
          <?= $editProd ? 'Actualizar Producto' : 'Crear Producto' ?>
        </button>
        <button type="button" onclick="hideModal('modalProducto')" class="btn-ghost">Cancelar</button>
      </div>
    </form>
  </div>
</div>


<?php elseif ($page === 'categorias'): ?>
<!-- ═══════════════════════════════════════════════════════════
     CATEGORÍAS
     ═══════════════════════════════════════════════════════════ -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
  <h2 style="font-size:18px;font-weight:700;color:#00291e;">Categorías</h2>
  <button onclick="showModal('modalCategoria')" class="btn-primary">
    <span class="material-symbols-outlined" style="font-size:18px;">add</span>
    Nueva Categoría
  </button>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;">
  <?php foreach ($categoriasLista as $cat):
    $cnt = $db->prepare("SELECT COUNT(*) FROM productos WHERE categoria_id=? AND activo=1");
    $cnt->execute([$cat['id']]);
    $nProd = $cnt->fetchColumn();
  ?>
  <div style="background:#fff;border-radius:16px;padding:20px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
      <div style="width:48px;height:48px;border-radius:50%;background:#a1f0c7;display:flex;align-items:center;justify-content:center;shrink:0;">
        <span class="material-symbols-outlined" style="color:#176b4b;font-size:24px;"><?= h($cat['icono'] ?? 'eco') ?></span>
      </div>
      <div style="flex:1;min-width:0;">
        <h3 style="font-size:15px;font-weight:700;color:#00291e;"><?= h($cat['nombre']) ?></h3>
        <span style="font-size:12px;color:#717975;"><?= $nProd ?> productos · slug: <?= h($cat['slug']) ?></span>
      </div>
      <span style="padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;<?= $cat['activa'] ? 'background:#a4f3ca;color:#005236;' : 'background:#dfe4df;color:#717975;' ?>">
        <?= $cat['activa'] ? 'Activa' : 'Oculta' ?>
      </span>
    </div>
    <p style="font-size:13px;color:#414845;line-height:1.5;margin-bottom:14px;"><?= h($cat['descripcion']) ?></p>
    <div style="display:flex;gap:8px;">
      <a href="admin.php?page=categorias&edit_cat=<?= $cat['id'] ?>" class="btn-ghost" style="font-size:13px;padding:6px 12px;">
        <span class="material-symbols-outlined" style="font-size:16px;">edit</span> Editar
      </a>
      <a href="index.php?page=categoria&cat=<?= h($cat['slug']) ?>" target="_blank" class="btn-ghost" style="font-size:13px;padding:6px 12px;">
        <span class="material-symbols-outlined" style="font-size:16px;">open_in_new</span> Ver
      </a>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Modal categoría -->
<div id="modalCategoria" class="modal" style="align-items:center;justify-content:center;background:rgba(0,0,0,.4);padding:24px 16px;">
  <div style="background:#fff;border-radius:20px;padding:28px;width:100%;max-width:520px;box-shadow:0 24px 48px rgba(0,0,0,.12);">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
      <h3 style="font-size:18px;font-weight:700;color:#00291e;"><?= $editCat ? 'Editar Categoría' : 'Nueva Categoría' ?></h3>
      <button onclick="hideModal('modalCategoria')" style="width:36px;height:36px;border-radius:50%;background:#f1f5f0;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:20px;color:#717975;">close</span>
      </button>
    </div>
    <form method="POST" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:14px;">
      <input type="hidden" name="save_categoria" value="1">
      <input type="hidden" name="cat_id" value="<?= (int)($editCat['id'] ?? 0) ?>">
      <div>
        <label class="form-label">Nombre *</label>
        <input name="nombre" class="form-input" required value="<?= h($editCat['nombre'] ?? '') ?>">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Slug (URL)</label>
          <input name="slug" class="form-input" value="<?= h($editCat['slug'] ?? '') ?>" placeholder="jarabes">
        </div>
        <div>
          <label class="form-label">Icono (Material Symbol)</label>
          <input name="icono" class="form-input" value="<?= h($editCat['icono'] ?? 'eco') ?>" placeholder="water_drop">
        </div>
      </div>
      <div>
        <label class="form-label">Descripción</label>
        <textarea name="descripcion" class="form-input" rows="2"><?= h($editCat['descripcion'] ?? '') ?></textarea>
      </div>
      <!-- Imagen del banner -->
      <div>
        <label class="form-label">Imagen del banner</label>
        <div id="catBannerDropZone" onclick="document.getElementById('catBannerFileInput').click()"
          ondragover="event.preventDefault();this.style.borderColor='#176b4b';this.style.background='#f0faf5'"
          ondragleave="this.style.borderColor='#c1c8c3';this.style.background='#fafcfa'"
          ondrop="event.preventDefault();this.style.borderColor='#c1c8c3';this.style.background='#fafcfa';handleCatBannerDrop(event)"
          style="border:2px dashed #c1c8c3;border-radius:12px;background:#fafcfa;cursor:pointer;
                 overflow:hidden;transition:border-color .2s,background .2s;min-height:120px;
                 display:flex;align-items:center;justify-content:center;position:relative;">
          <!-- Preview de imagen existente o nueva -->
          <div id="catBannerPreviewWrap" style="<?= !empty($editCat['imagen_banner']) ? 'display:block' : 'display:none' ?>;position:absolute;inset:0;">
            <img id="catBannerPreviewImg" src="<?= h($editCat['imagen_banner'] ?? '') ?>"
              style="width:100%;height:100%;object-fit:cover;border-radius:10px;">
            <div style="position:absolute;inset:0;background:rgba(0,0,0,.35);border-radius:10px;display:flex;align-items:center;justify-content:center;">
              <span style="color:#fff;font-size:12px;font-weight:600;background:rgba(0,0,0,.5);padding:4px 12px;border-radius:999px;">Cambiar imagen</span>
            </div>
          </div>
          <!-- Placeholder vacío -->
          <div id="catBannerPlaceholder" style="<?= !empty($editCat['imagen_banner']) ? 'display:none' : 'display:flex' ?>;flex-direction:column;align-items:center;gap:6px;padding:20px;">
            <span class="material-symbols-outlined" style="font-size:32px;color:#8aab9a;">add_photo_alternate</span>
            <span style="font-size:12px;color:#8aab9a;text-align:center;">Arrastra una imagen o haz clic para seleccionar<br><span style="font-size:11px;">JPG, PNG, WEBP — máx. 5 MB</span></span>
          </div>
        </div>
        <input type="file" id="catBannerFileInput" name="cat_banner_file" accept="image/jpeg,image/png,image/webp,image/gif"
               style="display:none;" onchange="previewCatBannerFile(this)">
        <!-- URL alternativa -->
        <details style="margin-top:8px;">
          <summary style="font-size:12px;color:#717975;cursor:pointer;user-select:none;">O pegar una URL de imagen</summary>
          <input name="imagen_banner" class="form-input" style="margin-top:6px;font-size:13px;"
            value="<?= h($editCat['imagen_banner'] ?? '') ?>"
            placeholder="https://…"
            oninput="if(this.value){document.getElementById('catBannerPreviewImg').src=this.value;document.getElementById('catBannerPreviewWrap').style.display='block';document.getElementById('catBannerPlaceholder').style.display='none';}">
        </details>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Orden</label>
          <input name="orden" type="number" class="form-input" value="<?= h($editCat['orden'] ?? 0) ?>">
        </div>
        <div style="display:flex;align-items:flex-end;padding-bottom:4px;">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;">
            <input type="checkbox" name="activa" <?= (!isset($editCat) || !empty($editCat['activa'])) ? 'checked' : '' ?> style="accent-color:#176b4b;width:16px;height:16px;">
            Visible en tienda
          </label>
        </div>
      </div>
      <div style="display:flex;gap:10px;margin-top:4px;">
        <button type="submit" class="btn-primary">
          <span class="material-symbols-outlined" style="font-size:18px;">save</span>
          Guardar
        </button>
        <button type="button" onclick="hideModal('modalCategoria')" class="btn-ghost">Cancelar</button>
      </div>
    </form>
  </div>
</div>


<?php elseif ($page === 'banners'): ?>
<!-- ═══════════════════════════════════════════════════════════
     BANNERS
     ═══════════════════════════════════════════════════════════ -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
  <h2 style="font-size:18px;font-weight:700;color:#00291e;">Banners del Hero</h2>
  <button onclick="showModal('modalBanner')" class="btn-primary">
    <span class="material-symbols-outlined" style="font-size:18px;">add</span>
    Nuevo Banner
  </button>
</div>

<div style="display:flex;flex-direction:column;gap:14px;">
  <?php foreach ($bannersLista as $b): ?>
  <div style="background:#fff;border-radius:16px;padding:20px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
    <div style="width:48px;height:48px;border-radius:12px;background:<?= $b['activo'] ? '#173f33' : '#dfe4df' ?>;display:flex;align-items:center;justify-content:center;shrink:0;">
      <span class="material-symbols-outlined" style="color:<?= $b['activo'] ? '#a1f0c7' : '#717975' ?>;font-size:22px;">campaign</span>
    </div>
    <div style="flex:1;min-width:200px;">
      <h3 style="font-size:15px;font-weight:700;color:#00291e;"><?= h($b['titulo']) ?></h3>
      <p style="font-size:13px;color:#717975;"><?= h($b['subtitulo']) ?></p>
      <p style="font-size:12px;color:#a1f0c7;background:#173f33;display:inline-block;padding:2px 8px;border-radius:6px;margin-top:4px;"><?= h($b['boton_texto']) ?> → <?= h($b['boton_url']) ?></p>
    </div>
    <div style="display:flex;align-items:center;gap:10px;">
      <span style="padding:4px 10px;border-radius:999px;font-size:12px;font-weight:600;<?= $b['activo'] ? 'background:#a4f3ca;color:#005236;' : 'background:#dfe4df;color:#717975;' ?>">
        <?= $b['activo'] ? 'Activo' : 'Oculto' ?>
      </span>
      <a href="admin.php?page=banners&edit_banner=<?= $b['id'] ?>" class="btn-ghost" style="padding:6px 12px;font-size:13px;">
        <span class="material-symbols-outlined" style="font-size:16px;">edit</span> Editar
      </a>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (empty($bannersLista)): ?>
  <div style="text-align:center;padding:40px;color:#717975;">
    No hay banners. <button onclick="showModal('modalBanner')" style="color:#176b4b;border:none;background:none;cursor:pointer;font-size:14px;">Crear el primero</button>
  </div>
  <?php endif; ?>
</div>

<!-- Modal banner -->
<div id="modalBanner" class="modal" style="align-items:center;justify-content:center;background:rgba(0,0,0,.4);padding:24px 16px;">
  <div style="background:#fff;border-radius:20px;padding:28px;width:100%;max-width:560px;box-shadow:0 24px 48px rgba(0,0,0,.12);">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
      <h3 style="font-size:18px;font-weight:700;color:#00291e;"><?= $editBanner ? 'Editar Banner' : 'Nuevo Banner' ?></h3>
      <button onclick="hideModal('modalBanner')" style="width:36px;height:36px;border-radius:50%;background:#f1f5f0;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:20px;color:#717975;">close</span>
      </button>
    </div>
    <form method="POST" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:14px;">
      <input type="hidden" name="save_banner" value="1">
      <input type="hidden" name="banner_id" value="<?= (int)($editBanner['id'] ?? 0) ?>">
      <div>
        <label class="form-label">Título *</label>
        <input name="titulo" class="form-input" required value="<?= h($editBanner['titulo'] ?? '') ?>" placeholder="Herbolaria Colombiana Certificada">
      </div>
      <div>
        <label class="form-label">Subtítulo</label>
        <input name="subtitulo" class="form-input" value="<?= h($editBanner['subtitulo'] ?? '') ?>" placeholder="La naturaleza en su estado más puro">
      </div>
      <div>
        <label class="form-label">Descripción</label>
        <textarea name="descripcion" class="form-input" rows="2"><?= h($editBanner['descripcion'] ?? '') ?></textarea>
      </div>
      <!-- ── Zona imagen banner ── -->
      <div>
        <label class="form-label">Imagen del banner</label>
        <!-- Zona drag & drop -->
        <div id="bannerDropZone" onclick="document.getElementById('bannerFileInput').click()"
          ondragover="event.preventDefault();this.style.borderColor='#176b4b';this.style.background='#f0faf5'"
          ondragleave="this.style.borderColor='#c1c8c3';this.style.background='#fafcfa'"
          ondrop="event.preventDefault();this.style.borderColor='#c1c8c3';this.style.background='#fafcfa';handleBannerDrop(event)"
          style="border:2px dashed #c1c8c3;border-radius:16px;background:#fafcfa;cursor:pointer;
                 overflow:hidden;transition:border-color .2s,background .2s;min-height:160px;
                 display:flex;align-items:center;justify-content:center;position:relative;">
          <!-- Preview de imagen (oculto inicialmente si no hay imagen) -->
          <div id="bannerPreviewWrap" style="<?= !empty($editBanner['imagen_url']) ? 'display:block' : 'display:none' ?>;position:absolute;inset:0;">
            <img id="bannerPreviewImg" src="<?= h($editBanner['imagen_url'] ?? '') ?>"
              style="width:100%;height:100%;object-fit:cover;border-radius:14px;">
            <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,.55) 0%,transparent 50%);border-radius:14px;"></div>
            <div style="position:absolute;bottom:10px;left:50%;transform:translateX(-50%);
              display:flex;align-items:center;gap:6px;background:rgba(0,0,0,.55);backdrop-filter:blur(6px);
              border-radius:999px;padding:5px 14px;">
              <span class="material-symbols-outlined" style="font-size:14px;color:#fff;">photo_camera</span>
              <span style="font-size:12px;color:#fff;font-weight:600;white-space:nowrap;">Cambiar imagen</span>
            </div>
          </div>
          <!-- Placeholder sin imagen -->
          <div id="bannerPlaceholder" style="<?= !empty($editBanner['imagen_url']) ? 'display:none' : 'display:flex' ?>;flex-direction:column;align-items:center;gap:10px;padding:32px 20px;text-align:center;">
            <div style="width:52px;height:52px;border-radius:16px;background:#e8f5ee;display:flex;align-items:center;justify-content:center;">
              <span class="material-symbols-outlined" style="font-size:28px;color:#176b4b;">image</span>
            </div>
            <div>
              <p style="font-size:14px;font-weight:600;color:#00291e;margin:0 0 4px;">Haz clic o arrastra tu imagen aquí</p>
              <p style="font-size:12px;color:#717975;margin:0;">JPG, PNG, WebP · Recomendado: 1400×600 px · Máx. 5 MB</p>
            </div>
            <div style="display:inline-flex;align-items:center;gap:6px;background:#176b4b;color:#fff;border-radius:999px;padding:7px 18px;font-size:13px;font-weight:600;">
              <span class="material-symbols-outlined" style="font-size:16px;">upload</span>
              Seleccionar archivo
            </div>
          </div>
        </div>
        <input type="file" id="bannerFileInput" name="banner_file" accept="image/jpeg,image/png,image/webp,image/gif"
               style="display:none;" onchange="previewBannerFile(this)">
        <!-- URL alternativa colapsable -->
        <details style="margin-top:10px;">
          <summary style="font-size:12px;color:#717975;cursor:pointer;user-select:none;list-style:none;display:flex;align-items:center;gap:4px;">
            <span class="material-symbols-outlined" style="font-size:14px;">link</span>
            O pegar una URL de imagen
          </summary>
          <input name="imagen_url" class="form-input" style="margin-top:8px;"
            value="<?= h($editBanner['imagen_url'] ?? '') ?>"
            placeholder="https://…imagen.jpg"
            oninput="if(this.value){document.getElementById('bannerPreviewImg').src=this.value;document.getElementById('bannerPreviewWrap').style.display='block';document.getElementById('bannerPlaceholder').style.display='none';}">
        </details>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Texto del botón</label>
          <input name="boton_texto" class="form-input" value="<?= h($editBanner['boton_texto'] ?? 'Ver Catálogo') ?>">
        </div>
        <div>
          <label class="form-label">URL del botón</label>
          <input name="boton_url" class="form-input" value="<?= h($editBanner['boton_url'] ?? '#catalogo') ?>" placeholder="#catalogo">
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Orden</label>
          <input name="orden" type="number" class="form-input" value="<?= h($editBanner['orden'] ?? 0) ?>">
        </div>
        <div style="display:flex;align-items:flex-end;padding-bottom:4px;">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;">
            <input type="checkbox" name="activo" <?= (!isset($editBanner) || !empty($editBanner['activo'])) ? 'checked' : '' ?> style="accent-color:#176b4b;width:16px;height:16px;">
            Visible en tienda
          </label>
        </div>
      </div>
      <div style="display:flex;gap:10px;margin-top:4px;">
        <button type="submit" class="btn-primary">
          <span class="material-symbols-outlined" style="font-size:18px;">save</span>
          Guardar Banner
        </button>
        <button type="button" onclick="hideModal('modalBanner')" class="btn-ghost">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<?php elseif ($page === 'pedidos'): ?>
<!-- ═══════════════════════════════════════════════════════════
     PEDIDOS
     ═══════════════════════════════════════════════════════════ -->
<?php
$estadoColors = [
  'nuevo'      => 'background:#c8e6ff;color:#003a6b;',
  'confirmado' => 'background:#a4f3ca;color:#005236;',
  'despachado' => 'background:#ffddaf;color:#321f00;',
  'entregado'  => 'background:#173f33;color:#a5d0bf;',
  'cancelado'  => 'background:#ffdad6;color:#93000a;',
];
$estadoLabel = [
  'nuevo'=>'Nuevo','confirmado'=>'Confirmado','despachado'=>'Despachado','entregado'=>'Entregado','cancelado'=>'Cancelado'
];
$estadoNext = [
  'nuevo'     => ['confirmado'=>'Confirmar','cancelado'=>'Cancelar'],
  'confirmado'=> ['despachado'=>'Despachar','cancelado'=>'Cancelar'],
  'despachado'=> ['entregado'=>'Marcar entregado'],
  'entregado' => [],
  'cancelado' => [],
];
$filtroEstado = $_GET['estado'] ?? '';
$pedidosFilt = $filtroEstado
  ? $db->prepare("SELECT * FROM pedidos WHERE estado=? ORDER BY created_at DESC")->execute([$filtroEstado]) || []
  : [];
if ($filtroEstado) {
  $st = $db->prepare("SELECT * FROM pedidos WHERE estado=? ORDER BY created_at DESC");
  $st->execute([$filtroEstado]);
  $pedidosFilt = $st->fetchAll();
} else {
  $pedidosFilt = $pedidosLista;
}
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:18px;font-weight:700;color:#00291e;">Gestión de Pedidos</h2>
    <p style="font-size:13px;color:#717975;"><?= count($pedidosFilt) ?> pedido<?= count($pedidosFilt)!=1?'s':'' ?><?= $filtroEstado ? ' — filtro: '.($estadoLabel[$filtroEstado]??$filtroEstado) : '' ?></p>
  </div>
</div>

<!-- Filtros rápidos por estado -->
<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px;">
  <a href="admin.php?page=pedidos" style="padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;text-decoration:none;<?= !$filtroEstado ? 'background:#00291e;color:#fff;' : 'background:#ebefea;color:#414845;' ?>">Todos (<?= $totalPedidos ?>)</a>
  <?php foreach ($estadoLabel as $key => $label):
    $cnt = $db->query("SELECT COUNT(*) FROM pedidos WHERE estado='$key'")->fetchColumn();
  ?>
  <a href="admin.php?page=pedidos&estado=<?= $key ?>" style="padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;text-decoration:none;<?= $filtroEstado===$key ? 'background:#00291e;color:#fff;' : $estadoColors[$key] ?>">
    <?= $label ?> (<?= $cnt ?>)
  </a>
  <?php endforeach; ?>
</div>

<?php if (empty($pedidosFilt)): ?>
<div style="background:#fff;border-radius:16px;padding:60px 24px;text-align:center;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);">
  <span class="material-symbols-outlined" style="font-size:48px;color:#c1c8c3;">receipt_long</span>
  <p style="font-size:16px;font-weight:600;color:#414845;margin-top:12px;">No hay pedidos<?= $filtroEstado ? ' con estado "'.$estadoLabel[$filtroEstado].'"' : '' ?> aún</p>
  <p style="font-size:13px;color:#717975;margin-top:4px;">Los pedidos aparecerán aquí cuando los clientes completen el checkout.</p>
</div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:14px;">
  <?php foreach ($pedidosFilt as $ped):
    $items = json_decode($ped['items'] ?? '[]', true);
    $numItems = array_sum(array_column($items, 'qty'));
  ?>
  <div style="background:#fff;border-radius:16px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);overflow:hidden;">
    <!-- Cabecera del pedido -->
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;padding:16px 20px;border-bottom:1px solid #f1f5f0;cursor:pointer;" onclick="togglePedido(<?= $ped['id'] ?>)">
      <div style="display:flex;align-items:center;gap:14px;">
        <div style="width:42px;height:42px;border-radius:50%;background:#ebefea;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
          <span class="material-symbols-outlined" style="font-size:22px;color:#176b4b;">package_2</span>
        </div>
        <div>
          <span style="font-size:14px;font-weight:700;color:#00291e;display:block;"><?= h($ped['numero_pedido']) ?></span>
          <span style="font-size:12px;color:#717975;">
            <?= h($ped['nombre_cliente'] ?: '—') ?>
            <?php if ($ped['ciudad']): ?> · <?= h($ped['ciudad']) ?><?php endif; ?>
            · <?= $numItems ?> producto<?= $numItems!=1?'s':'' ?>
            · <?= date('d/m/Y H:i', strtotime($ped['created_at'])) ?>
          </span>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:16px;font-weight:700;color:#00291e;"><?= formatPrice($ped['total']) ?></span>
        <span style="padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;<?= $estadoColors[$ped['estado']] ?? '' ?>">
          <?= $estadoLabel[$ped['estado']] ?? $ped['estado'] ?>
        </span>
        <span class="material-symbols-outlined" style="font-size:20px;color:#717975;transition:transform .2s;" id="arrow-<?= $ped['id'] ?>">expand_more</span>
      </div>
    </div>

    <!-- Detalle expandible -->
    <div id="detalle-<?= $ped['id'] ?>" style="display:none;padding:20px;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:16px;">
        <!-- Info cliente -->
        <div>
          <h4 style="font-size:12px;font-weight:600;color:#717975;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px;">Cliente</h4>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <?php if ($ped['nombre_cliente']): ?>
            <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:#414845;">
              <span class="material-symbols-outlined" style="font-size:16px;color:#717975;">person</span>
              <?= h($ped['nombre_cliente']) ?>
            </div>
            <?php endif; ?>
            <?php if ($ped['telefono']): ?>
            <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:#414845;">
              <span class="material-symbols-outlined" style="font-size:16px;color:#717975;">phone</span>
              <a href="https://wa.me/<?= preg_replace('/\D/','',$ped['telefono']) ?>" target="_blank" style="color:#176b4b;font-weight:500;"><?= h($ped['telefono']) ?></a>
            </div>
            <?php endif; ?>
            <?php if ($ped['ciudad']): ?>
            <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:#414845;">
              <span class="material-symbols-outlined" style="font-size:16px;color:#717975;">location_on</span>
              <?= h($ped['ciudad']) ?>
            </div>
            <?php endif; ?>
            <?php if ($ped['direccion']): ?>
            <div style="display:flex;align-items:start;gap:8px;font-size:13px;color:#414845;">
              <span class="material-symbols-outlined" style="font-size:16px;color:#717975;margin-top:1px;">home</span>
              <?= h($ped['direccion']) ?>
            </div>
            <?php endif; ?>
            <?php if ($ped['notas']): ?>
            <div style="margin-top:4px;background:#fffbf0;border-left:3px solid #ffddaf;padding:8px 12px;border-radius:0 8px 8px 0;font-size:12px;color:#414845;">
              <strong>Nota:</strong> <?= h($ped['notas']) ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
        <!-- Items del pedido -->
        <div>
          <h4 style="font-size:12px;font-weight:600;color:#717975;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px;">Productos Pedidos</h4>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <?php foreach ($items as $item): ?>
            <div style="display:flex;align-items:center;justify-content:space-between;background:#f6faf5;padding:8px 12px;border-radius:10px;">
              <div>
                <span style="font-size:13px;font-weight:600;color:#00291e;display:block;"><?= h($item['name'] ?? $item['nombre'] ?? '—') ?></span>
                <span style="font-size:11px;color:#717975;">x<?= (int)($item['qty'] ?? 1) ?></span>
              </div>
              <span style="font-size:13px;font-weight:600;color:#00291e;"><?= formatPrice(($item['price'] ?? 0) * ($item['qty'] ?? 1)) ?></span>
            </div>
            <?php endforeach; ?>
            <div style="display:flex;justify-content:space-between;padding:8px 12px;font-size:14px;font-weight:700;color:#00291e;border-top:1px solid #ebefea;margin-top:4px;">
              <span>Total</span>
              <span><?= formatPrice($ped['total']) ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- Acciones de estado -->
      <?php if (!empty($estadoNext[$ped['estado']])): ?>
      <div style="display:flex;flex-wrap:wrap;align-items:center;gap:10px;padding-top:16px;border-top:1px solid #f1f5f0;">
        <span style="font-size:12px;font-weight:600;color:#717975;">Cambiar estado:</span>
        <?php foreach ($estadoNext[$ped['estado']] as $nuevoEst => $accion): ?>
        <a href="admin.php?pedido_id=<?= $ped['id'] ?>&pedido_estado=<?= $nuevoEst ?>"
           onclick="return confirm('¿<?= $accion ?> este pedido?')"
           style="display:inline-flex;align-items:center;gap:6px;padding:7px 16px;border-radius:999px;font-size:13px;font-weight:600;text-decoration:none;cursor:pointer;<?= $nuevoEst==='cancelado' ? 'background:#ffdad6;color:#93000a;' : 'background:#a4f3ca;color:#005236;' ?>">
          <span class="material-symbols-outlined" style="font-size:16px;"><?= $nuevoEst==='cancelado' ? 'cancel' : 'check_circle' ?></span>
          <?= $accion ?>
        </a>
        <?php endforeach; ?>
        <?php if ($ped['telefono']): ?>
        <a href="https://wa.me/<?= preg_replace('/\D/','',$ped['telefono']) ?>?text=<?= urlencode('Hola '.$ped['nombre_cliente'].', su pedido '.$ped['numero_pedido'].' de Verde Natural está listo. 🌿') ?>"
           target="_blank"
           style="display:inline-flex;align-items:center;gap:6px;padding:7px 16px;border-radius:999px;font-size:13px;font-weight:600;text-decoration:none;background:#25D366;color:#fff;">
          <span class="material-symbols-outlined" style="font-size:16px;">chat</span>
          WhatsApp
        </a>
        <?php endif; ?>
      </div>
      <?php elseif ($ped['estado']==='entregado'): ?>
      <div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:#a4f3ca;border-radius:12px;margin-top:4px;">
        <span class="material-symbols-outlined" style="color:#005236;">verified</span>
        <span style="font-size:13px;font-weight:600;color:#005236;">Pedido entregado ✓</span>
      </div>
      <?php elseif ($ped['estado']==='cancelado'): ?>
      <div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:#ffdad6;border-radius:12px;margin-top:4px;">
        <span class="material-symbols-outlined" style="color:#93000a;">cancel</span>
        <span style="font-size:13px;font-weight:600;color:#93000a;">Pedido cancelado</span>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<script>
function togglePedido(id) {
  var d = document.getElementById('detalle-'+id);
  var a = document.getElementById('arrow-'+id);
  if (d.style.display==='none') {
    d.style.display='block';
    a.style.transform='rotate(180deg)';
  } else {
    d.style.display='none';
    a.style.transform='';
  }
}
</script>


<?php elseif ($page === 'clientes'): ?>
<!-- ═══════════════════════════════════════════════════════════
     CLIENTES
     ═══════════════════════════════════════════════════════════ -->
<?php
$db = getDB();
// Detectar columna de fecha disponible
$colsFecha = $db->query("SHOW COLUMNS FROM clientes")->fetchAll(PDO::FETCH_COLUMN);
$ordenCol = in_array('fecha_registro', $colsFecha) ? 'fecha_registro' : (in_array('created_at', $colsFecha) ? 'created_at' : 'id');
$clientes = $db->query("SELECT * FROM clientes ORDER BY $ordenCol DESC")->fetchAll();
$totalC   = count($clientes);
$activosC = count(array_filter($clientes, fn($c) => $c['activo']));
$okMsg    = $_GET['ok'] ?? '';
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:18px;font-weight:700;color:#00291e;">Clientes registrados</h2>
    <p style="font-size:13px;color:#717975;margin-top:2px;"><?= $totalC ?> en total · <?= $activosC ?> activos</p>
  </div>
</div>

<?php if ($okMsg): ?>
<div style="background:#a4f3ca;color:#005236;padding:10px 16px;border-radius:10px;font-size:13px;margin-bottom:16px;"><?= h($okMsg) ?></div>
<?php endif; ?>

<!-- Resumen rápido -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:24px;">
  <div style="background:#fff;border-radius:14px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center;">
    <div style="font-size:28px;font-weight:800;color:#00291e;"><?= $totalC ?></div>
    <div style="font-size:12px;color:#717975;margin-top:4px;">Total registrados</div>
  </div>
  <div style="background:#fff;border-radius:14px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center;">
    <div style="font-size:28px;font-weight:800;color:#176b4b;"><?= $activosC ?></div>
    <div style="font-size:12px;color:#717975;margin-top:4px;">Activos</div>
  </div>
  <div style="background:#fff;border-radius:14px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center;">
    <div style="font-size:28px;font-weight:800;color:#93000a;"><?= $totalC - $activosC ?></div>
    <div style="font-size:12px;color:#717975;margin-top:4px;">Inactivos</div>
  </div>
</div>

<!-- Tabla de clientes -->
<div style="background:#fff;border-radius:16px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);overflow:hidden;">
  <?php if (empty($clientes)): ?>
  <div style="padding:60px;text-align:center;color:#717975;">
    <span class="material-symbols-outlined" style="font-size:48px;opacity:.3;display:block;margin-bottom:12px;">group</span>
    Aún no hay clientes registrados.
  </div>
  <?php else: ?>
  <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
      <thead>
        <tr style="background:#f1f5f0;border-bottom:1px solid #e0e8e3;">
          <th style="padding:12px 16px;text-align:left;font-weight:600;color:#414845;">#</th>
          <th style="padding:12px 16px;text-align:left;font-weight:600;color:#414845;">Nombre</th>
          <th style="padding:12px 16px;text-align:left;font-weight:600;color:#414845;">Correo</th>
          <th style="padding:12px 16px;text-align:left;font-weight:600;color:#414845;">Teléfono</th>
          <th style="padding:12px 16px;text-align:left;font-weight:600;color:#414845;">Registrado</th>
          <th style="padding:12px 16px;text-align:left;font-weight:600;color:#414845;">Último acceso</th>
          <th style="padding:12px 16px;text-align:center;font-weight:600;color:#414845;">Estado</th>
          <th style="padding:12px 16px;text-align:center;font-weight:600;color:#414845;">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($clientes as $i => $cli): ?>
        <tr style="border-bottom:1px solid #f1f5f0;<?= !$cli['activo'] ? 'opacity:.55;' : '' ?>">
          <td style="padding:12px 16px;color:#717975;"><?= $i+1 ?></td>
          <td style="padding:12px 16px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#a4f3ca,#176b4b);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;font-weight:700;flex-shrink:0;">
                <?= mb_strtoupper(mb_substr($cli['nombre'],0,1)) ?>
              </div>
              <span style="font-weight:600;color:#00291e;"><?= h($cli['nombre']) ?></span>
            </div>
          </td>
          <td style="padding:12px 16px;color:#414845;"><?= h($cli['email']) ?></td>
          <td style="padding:12px 16px;color:#414845;">
            <?php if ($cli['telefono']): ?>
              <a href="https://wa.me/57<?= preg_replace('/\D/','',$cli['telefono']) ?>" target="_blank"
                 style="color:#176b4b;text-decoration:none;display:flex;align-items:center;gap:4px;">
                <span class="material-symbols-outlined" style="font-size:14px;">chat</span>
                <?= h($cli['telefono']) ?>
              </a>
            <?php else: ?>
              <span style="color:#bbb;">—</span>
            <?php endif; ?>
          </td>
          <td style="padding:12px 16px;color:#717975;white-space:nowrap;">
            <?php $fr = $cli['fecha_registro'] ?? $cli['created_at'] ?? null; ?>
            <?= $fr ? date('d/m/Y', strtotime($fr)) : '—' ?>
          </td>
          <td style="padding:12px 16px;color:#717975;white-space:nowrap;">
            <?php $ua = $cli['ultimo_acceso'] ?? $cli['last_login'] ?? null; ?>
            <?= $ua ? date('d/m/Y H:i', strtotime($ua)) : 'Nunca' ?>
          </td>
          <td style="padding:12px 16px;text-align:center;">
            <a href="admin.php?page=clientes&toggle_cliente=<?= $cli['id'] ?>"
               style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:700;text-decoration:none;
                      background:<?= $cli['activo'] ? '#dcfce7' : '#ffdad6' ?>;
                      color:<?= $cli['activo'] ? '#166534' : '#93000a' ?>;">
              <?= $cli['activo'] ? 'Activo' : 'Inactivo' ?>
            </a>
          </td>
          <td style="padding:12px 16px;text-align:center;">
            <div style="display:flex;align-items:center;justify-content:center;gap:6px;">
              <?php if ($cli['telefono']): ?>
              <a href="https://wa.me/57<?= preg_replace('/\D/','',$cli['telefono']) ?>?text=Hola+<?= urlencode($cli['nombre']) ?>%2C+te+contactamos+desde+Verde+Natural+🌿"
                 target="_blank" title="WhatsApp"
                 style="width:30px;height:30px;border-radius:50%;background:#dcfce7;display:flex;align-items:center;justify-content:center;text-decoration:none;">
                <span class="material-symbols-outlined" style="font-size:15px;color:#166534;">chat</span>
              </a>
              <?php endif; ?>
              <a href="admin.php?page=clientes&toggle_cliente=<?= $cli['id'] ?>" title="<?= $cli['activo'] ? 'Desactivar' : 'Activar' ?>"
                 style="width:30px;height:30px;border-radius:50%;background:#f1f5f0;display:flex;align-items:center;justify-content:center;text-decoration:none;">
                <span class="material-symbols-outlined" style="font-size:15px;color:#414845;"><?= $cli['activo'] ? 'block' : 'check_circle' ?></span>
              </a>
              <a href="admin.php?page=clientes&del_cliente=<?= $cli['id'] ?>&_confirm=1"
                 onclick="return confirm('¿Eliminar a <?= addslashes(h($cli['nombre'])) ?>? Esta acción no se puede deshacer.')"
                 title="Eliminar"
                 style="width:30px;height:30px;border-radius:50%;background:#ffdad6;display:flex;align-items:center;justify-content:center;text-decoration:none;">
                <span class="material-symbols-outlined" style="font-size:15px;color:#93000a;">delete</span>
              </a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php elseif ($page === 'nosotros'): ?>
<!-- ═══════════════════════════════════════════════════════════
     SOBRE NOSOTROS
     ═══════════════════════════════════════════════════════════ -->
<?php
$nosotrosTitulo = getConfigAdmin($db, 'nosotros_titulo', 'Nuestra Historia');
$nosotrosTexto  = getConfigAdmin($db, 'nosotros_texto',  '');
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
  <div>
    <h2 style="font-size:18px;font-weight:700;color:#00291e;">Sobre Nosotros</h2>
    <p style="font-size:13px;color:#717975;margin-top:2px;">Texto que aparece en la pestaña "Sobre Nosotros" de la tienda.</p>
  </div>
  <a href="index.php?page=nosotros" target="_blank" class="btn-ghost" style="font-size:13px;padding:6px 14px;">
    <span class="material-symbols-outlined" style="font-size:16px;">open_in_new</span>
    Ver en tienda
  </a>
</div>

<div style="background:#fff;border-radius:16px;padding:28px;box-shadow:0 4px 16px -2px rgba(23,63,51,.05);">
  <form method="POST" style="display:flex;flex-direction:column;gap:18px;">
    <input type="hidden" name="save_nosotros" value="1">

    <div>
      <label class="form-label">Título de la sección</label>
      <input name="nosotros_titulo" class="form-input"
             value="<?= h($nosotrosTitulo) ?>"
             placeholder="Nuestra Historia"
             style="max-width:500px;">
    </div>

    <div>
      <label class="form-label">Texto / Historia de la tienda</label>
      <p style="font-size:12px;color:#717975;margin-bottom:6px;">Puedes usar saltos de línea. Se mostrará tal como lo escribas.</p>
      <textarea name="nosotros_texto"
                rows="12"
                class="form-input"
                placeholder="Escribe aquí la historia de Verde Natural, misión, visión, valores, o cualquier información que quieras compartir con tus clientes..."
                style="resize:vertical;line-height:1.6;"><?= h($nosotrosTexto) ?></textarea>
    </div>

    <div>
      <button type="submit" class="btn-primary">
        <span class="material-symbols-outlined" style="font-size:18px;">save</span>
        Guardar Cambios
      </button>
    </div>
  </form>
</div>

<!-- Vista previa en tiempo real -->
<?php if (!empty($nosotrosTexto)): ?>
<div style="margin-top:24px;background:#f6faf5;border-radius:16px;padding:24px;border:1px solid #c1c8c3;">
  <h3 style="font-size:14px;font-weight:700;color:#414845;margin-bottom:12px;text-transform:uppercase;letter-spacing:.05em;">
    <span class="material-symbols-outlined" style="font-size:16px;vertical-align:middle;">visibility</span>
    Vista previa
  </h3>
  <h4 style="font-size:20px;font-weight:700;color:#00291e;margin-bottom:12px;"><?= h($nosotrosTitulo) ?></h4>
  <div style="font-size:14px;color:#414845;line-height:1.7;white-space:pre-line;"><?= h($nosotrosTexto) ?></div>
</div>
<?php endif; ?>

<?php endif; // fin router admin ?>

</main>
</div><!-- fin contenido -->

<!-- ═══════════════════════════════════════════════════════════
     JS: modales
     ═══════════════════════════════════════════════════════════ -->
<script>
function showModal(id) {
  document.getElementById(id).style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function hideModal(id) {
  document.getElementById(id).style.display = 'none';
  document.body.style.overflow = '';
}
// Cerrar modal con ESC
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    ['modalProducto','modalCategoria','modalBanner'].forEach(id => {
      const el = document.getElementById(id);
      if (el && el.style.display === 'flex') hideModal(id);
    });
  }
});
// Cerrar al click fuera del panel
['modalProducto','modalCategoria','modalBanner'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('click', e => { if (e.target === el) hideModal(id); });
});

// Auto-abrir modal si hay edición pendiente
<?php if ($editProd): ?> showModal('modalProducto'); <?php endif; ?>
<?php if ($editCat):  ?> showModal('modalCategoria'); <?php endif; ?>
<?php if ($editBanner): ?> showModal('modalBanner'); <?php endif; ?>

// Auto-slug
document.querySelectorAll('input[name="nombre"]').forEach(input => {
  input.addEventListener('input', function() {
    const slugInput = this.closest('form')?.querySelector('input[name="slug"]');
    if (slugInput && !slugInput.value) {
      slugInput.value = this.value.toLowerCase()
        .normalize('NFD').replace(/[̀-ͯ]/g,'')
        .replace(/[^a-z0-9\s-]/g,'')
        .trim().replace(/\s+/g,'-');
    }
  });
});
</script>
<style>
@keyframes pulse {
  0%, 100% { opacity:1; transform:scale(1); }
  50% { opacity:.5; transform:scale(.85); }
}
</style>
<script>
// ── Preview imagen banner ──────────────────────────────
function previewBannerFile(input) {
  if (!input.files || !input.files[0]) return;
  var file = input.files[0];
  var reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('bannerPreviewImg').src = e.target.result;
    document.getElementById('bannerPreviewWrap').style.display = 'block';
    document.getElementById('bannerPlaceholder').style.display = 'none';
  };
  reader.readAsDataURL(file);
}
function handleBannerDrop(event) {
  var files = event.dataTransfer.files;
  if (!files || !files[0]) return;
  var input = document.getElementById('bannerFileInput');
  // Asignar archivos al input mediante DataTransfer
  try {
    var dt = new DataTransfer();
    dt.items.add(files[0]);
    input.files = dt.files;
    previewBannerFile(input);
  } catch(e) {
    // Fallback: solo mostrar preview
    var reader = new FileReader();
    reader.onload = function(ev) {
      document.getElementById('bannerPreviewImg').src = ev.target.result;
      document.getElementById('bannerPreviewWrap').style.display = 'block';
      document.getElementById('bannerPlaceholder').style.display = 'none';
    };
    reader.readAsDataURL(files[0]);
  }
}
// ── Preview imagen banner de CATEGORÍA ───────────────
function previewCatBannerFile(input) {
  if (!input.files || !input.files[0]) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('catBannerPreviewImg').src = e.target.result;
    document.getElementById('catBannerPreviewWrap').style.display = 'block';
    document.getElementById('catBannerPlaceholder').style.display = 'none';
  };
  reader.readAsDataURL(input.files[0]);
}
function handleCatBannerDrop(event) {
  var files = event.dataTransfer.files;
  if (!files || !files[0]) return;
  var input = document.getElementById('catBannerFileInput');
  try {
    var dt = new DataTransfer();
    dt.items.add(files[0]);
    input.files = dt.files;
    previewCatBannerFile(input);
  } catch(e) {
    var reader = new FileReader();
    reader.onload = function(ev) {
      document.getElementById('catBannerPreviewImg').src = ev.target.result;
      document.getElementById('catBannerPreviewWrap').style.display = 'block';
      document.getElementById('catBannerPlaceholder').style.display = 'none';
    };
    reader.readAsDataURL(files[0]);
  }
}
</script>
</body>
</html>
