<?php
// ============================================================
// Verde Natural — Tienda Online
// index.php — Tienda cliente
// ============================================================
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'verde_natural');
define('WA_NUMBER', '573206708805');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
            );
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:40px;text-align:center;background:#f6faf5">
                <h2 style="color:#00291e">⚠️ Error de conexión</h2>
                <p style="color:#414845">Revisa los datos de conexión en la parte superior de <code>index.php</code></p>
                <code style="background:#ebefea;padding:8px 16px;border-radius:8px">'.$e->getMessage().'</code></div>');
        }
    }
    return $pdo;
}
function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function formatPrice($p) { return '$ '.number_format($p,0,',','.').' COP'; }
function getConfig($key, $default='') {
    try {
        $db=getDB(); $st=$db->prepare("SELECT valor FROM configuracion WHERE clave=?");
        $st->execute([$key]); $r=$st->fetchColumn(); return $r!==false?$r:$default;
    } catch(Exception $e) { return $default; }
}

// ── Autenticación de clientes ─────────────────────────────────
$clienteLogueado = !empty($_SESSION['cliente_id']);
$clienteNombre   = $_SESSION['cliente_nombre'] ?? '';

// Logout cliente
if (isset($_GET['logout_cliente'])) {
    unset($_SESSION['cliente_id'], $_SESSION['cliente_nombre'], $_SESSION['cliente_email']);
    header('Location: index.php'); exit;
}

// Login cliente (también detecta administradores)
$loginError = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['login_cliente'])) {
    $db = getDB();
    $email = trim($_POST['email_c']??'');
    $pass  = $_POST['pass_c']??'';
    if ($email && $pass) {
        // 1. ¿Es administrador?
        $st = $db->prepare("SELECT * FROM administradores WHERE email=? AND activo=1");
        $st->execute([$email]); $admin = $st->fetch();
        if ($admin && password_verify($pass, $admin['password'])) {
            $_SESSION['admin_id']     = $admin['id'];
            $_SESSION['admin_nombre'] = $admin['nombre'];
            $_SESSION['admin_email']  = $admin['email'];
            $db->prepare("UPDATE administradores SET ultimo_acceso=NOW() WHERE id=?")->execute([$admin['id']]);
            header('Location: admin.php'); exit;
        }
        // 2. ¿Es cliente normal?
        $st = $db->prepare("SELECT * FROM clientes WHERE email=? AND activo=1");
        $st->execute([$email]); $cli = $st->fetch();
        if ($cli && password_verify($pass, $cli['password'])) {
            $_SESSION['cliente_id']     = $cli['id'];
            $_SESSION['cliente_nombre'] = $cli['nombre'];
            $_SESSION['cliente_email']  = $cli['email'];
            $db->prepare("UPDATE clientes SET ultimo_acceso=NOW() WHERE id=?")->execute([$cli['id']]);
            header('Location: index.php'); exit;
        }
        $loginError = 'Correo o contraseña incorrectos.';
    } else { $loginError = 'Completa todos los campos.'; }
}

// Registro cliente
$regError = $regOk = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['registrar_cliente'])) {
    $db = getDB();
    $nombre   = trim($_POST['reg_nombre']??'');
    $email    = trim($_POST['reg_email']??'');
    $telefono = trim($_POST['reg_telefono']??'');
    $pass     = $_POST['reg_pass']??'';
    $pass2    = $_POST['reg_pass2']??'';
    if (!$nombre||!$email||!$pass) { $regError='Completa todos los campos obligatorios.'; }
    elseif ($pass !== $pass2)      { $regError='Las contraseñas no coinciden.'; }
    elseif (strlen($pass)<6)       { $regError='La contraseña debe tener al menos 6 caracteres.'; }
    else {
        $st=$db->prepare("SELECT id FROM clientes WHERE email=?"); $st->execute([$email]);
        if ($st->fetch()) { $regError='Ya existe una cuenta con ese correo.'; }
        else {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $db->prepare("INSERT INTO clientes (nombre,email,telefono,password) VALUES (?,?,?,?)")
               ->execute([$nombre,$email,$telefono,$hash]);
            $regOk = '¡Cuenta creada! Ya puedes iniciar sesión.';
        }
    }
}

// Procesar pedido
$pedidoOk = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['hacer_pedido'])) {
    $db2 = getDB();
    $items = json_decode($_POST['pedido_items'] ?? '[]', true);
    if (!empty($items)) {
        $numero = 'VN-' . strtoupper(substr(md5(uniqid()),0,8));
        $subtotal = array_sum(array_map(fn($i) => $i['price'] * $i['qty'], $items));
        $db2->prepare("INSERT INTO pedidos (numero_pedido,nombre_cliente,telefono,ciudad,direccion,items,subtotal,total,notas) VALUES (?,?,?,?,?,?,?,?,?)")
            ->execute([
                $numero,
                trim($_POST['ped_nombre'] ?? ''),
                trim($_POST['ped_telefono'] ?? ''),
                trim($_POST['ped_ciudad'] ?? ''),
                trim($_POST['ped_direccion'] ?? ''),
                json_encode($items, JSON_UNESCAPED_UNICODE),
                $subtotal, $subtotal,
                trim($_POST['ped_notas'] ?? ''),
            ]);
        $pedidoOk = $numero;
    }
}

// ── Router ────────────────────────────────────────────────────
$page     = $_GET['page'] ?? 'inicio';
$catSlug  = $_GET['cat'] ?? null;
$prodSlug = $_GET['prod'] ?? null;

if ($page==='admin-login'||$page==='admin') { header('Location: admin.php'); exit; }

$db = getDB();
$siteName = getConfig('nombre_tienda','Verde Natural');
$waNumber = getConfig('telefono_whatsapp', WA_NUMBER);
$envioMin = getConfig('envio_gratis_minimo','90000');

$categorias = $db->query("SELECT * FROM categorias WHERE activa=1 ORDER BY orden ASC")->fetchAll();

$producto = null;
if ($page==='producto' && $prodSlug) {
    $st=$db->prepare("SELECT p.*,c.nombre as cat_nombre,c.slug as cat_slug FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id WHERE p.slug=? AND p.activo=1");
    $st->execute([$prodSlug]); $producto=$st->fetch();
    if (!$producto) $page='inicio';
}

$categoriaActual=[]; $productosCat=[];
if ($page==='categoria' && $catSlug) {
    $st=$db->prepare("SELECT * FROM categorias WHERE slug=? AND activa=1");
    $st->execute([$catSlug]); $categoriaActual=$st->fetch();
    if ($categoriaActual) {
        $st2=$db->prepare("SELECT p.*,c.nombre as cat_nombre,c.slug as cat_slug FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id WHERE p.categoria_id=? AND p.activo=1 ORDER BY p.destacado DESC,p.nombre ASC");
        $st2->execute([$categoriaActual['id']]); $productosCat=$st2->fetchAll();
    } else $page='inicio';
}

$busqueda=''; $resultadosBusqueda=[];
if ($page==='buscar' && isset($_GET['q'])) {
    $busqueda=trim($_GET['q']);
    if ($busqueda) {
        $st=$db->prepare("SELECT p.*,c.nombre as cat_nombre,c.slug as cat_slug FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id WHERE p.activo=1 AND (p.nombre LIKE ? OR p.descripcion_corta LIKE ? OR p.descripcion LIKE ?) ORDER BY p.destacado DESC");
        $q="%{$busqueda}%"; $st->execute([$q,$q,$q]); $resultadosBusqueda=$st->fetchAll();
    }
}

$banners   = $db->query("SELECT * FROM banners WHERE activo=1 ORDER BY orden ASC")->fetchAll();
$destacados= $db->query("SELECT p.*,c.nombre as cat_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id WHERE p.activo=1 ORDER BY p.destacado DESC,p.id DESC LIMIT 8")->fetchAll();
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verde Natural</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='32' fill='%23176b4b'/%3E%3Cpath d='M32 12 C20 20 16 30 20 44 C24 36 28 32 32 30 C36 32 40 36 44 44 C48 30 44 20 32 12Z' fill='%23a4f3ca'/%3E%3Cline x1='32' y1='30' x2='32' y2='50' stroke='%23a4f3ca' stroke-width='2.5' stroke-linecap='round'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{colors:{
  'primary':'#00291e','primary-container':'#173f33','secondary':'#176b4b',
  'secondary-container':'#a1f0c7','secondary-fixed':'#a4f3ca','secondary-fixed-dim':'#88d6af',
  'on-secondary-fixed-variant':'#005236','on-secondary-container':'#1d704f',
  'tertiary-fixed-dim':'#fdba4b','tertiary-fixed':'#ffddaf','tertiary':'#321f00','tertiary-container':'#4e3300',
  'on-tertiary-fixed':'#281800','on-tertiary-fixed-variant':'#614000',
  'surface':'#f6faf5','surface-container-lowest':'#ffffff','surface-container-low':'#f1f5f0',
  'surface-container':'#ebefea','surface-container-high':'#e5e9e4','surface-container-highest':'#dfe4df',
  'surface-dim':'#d7dbd6','surface-tint':'#3f6658','background':'#f6faf5',
  'on-primary':'#ffffff','on-primary-container':'#81aa9b','on-primary-fixed':'#002118',
  'on-secondary':'#ffffff','on-surface':'#181d1a','on-surface-variant':'#414845',
  'outline':'#717975','outline-variant':'#c1c8c3','inverse-surface':'#2d312e',
  'inverse-on-surface':'#eef2ed','inverse-primary':'#a5d0bf',
  'error':'#ba1a1a','error-container':'#ffdad6','on-error-container':'#93000a',
},fontFamily:{sans:['Plus Jakarta Sans','sans-serif']}}}}
</script>
<style>
*{font-family:'Plus Jakarta Sans',sans-serif;}
.material-symbols-outlined{font-family:'Material Symbols Outlined';font-style:normal;font-weight:normal;display:inline-block;line-height:1;text-transform:none;white-space:nowrap;direction:ltr;-webkit-font-feature-settings:'liga';font-feature-settings:'liga';-webkit-font-smoothing:antialiased;}
::-webkit-scrollbar{display:none;} html{scroll-behavior:smooth;}
.line-clamp-1{overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;}
.line-clamp-2{overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;}
#cartDrawer{transition:transform .35s cubic-bezier(.4,0,.2,1);}
#cartOverlay{transition:opacity .35s;}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:200;align-items:center;justify-content:center;}
.modal-overlay.open{display:flex;}
/* Logo SVG inline */
.vn-logo-leaf{fill:#176b4b;}
/* ── Tarjeta de producto ───────────────────────────────── */
.vn-pcard {
  display:flex; flex-direction:column;
  border-radius:20px; overflow:hidden;
  background:#fff;
  box-shadow:0 2px 12px -2px rgba(0,41,30,.08), 0 1px 3px rgba(0,0,0,.04);
  transition:transform .3s cubic-bezier(.34,1.56,.64,1), box-shadow .3s;
  position:relative;
}
.vn-pcard:hover {
  transform:translateY(-6px);
  box-shadow:0 16px 40px -8px rgba(0,41,30,.18), 0 4px 12px rgba(0,0,0,.06);
}
.vn-pcard-img-wrap {
  position:relative; display:block;
  width:100%; height:220px;
  overflow:hidden;
  background:linear-gradient(160deg, var(--pc-bg-top,#f7faf8) 0%, var(--pc-bg-bot,#f2f7f4) 100%);
  text-decoration:none;
}
@media(min-width:640px){
  .vn-pcard-img-wrap { height:240px; }
}
.vn-pcard-img {
  position:absolute; inset:0;
  width:100%; height:100%;
  object-fit:contain; object-position:center;
  background:transparent;
  transition:transform .5s cubic-bezier(.25,.46,.45,.94);
  display:block;
  padding:8px;
}
.vn-pcard:hover .vn-pcard-img { transform:scale(1.07); }
.vn-pcard-placeholder {
  position:absolute; inset:0;
  display:flex; align-items:center; justify-content:center;
  background:linear-gradient(135deg, var(--pc-from) 0%, var(--pc-to) 100%);
  overflow:hidden;
}
.vn-pcard-placeholder::before {
  content:'';
  position:absolute; inset:0;
  background-image:radial-gradient(circle, rgba(255,255,255,.07) 1px, transparent 1px);
  background-size:18px 18px;
  animation:vn-ph-drift 20s linear infinite;
}
.vn-pcard-placeholder::after {
  content:'';
  position:absolute;
  width:120px; height:120px;
  border-radius:50%;
  background:radial-gradient(circle, rgba(255,255,255,.12) 0%, transparent 70%);
  animation:vn-ph-pulse 3s ease-in-out infinite;
}
@keyframes vn-ph-drift {
  0%   { background-position:0 0; }
  100% { background-position:18px 18px; }
}
@keyframes vn-ph-pulse {
  0%,100% { transform:scale(.8); opacity:.6; }
  50%      { transform:scale(1.3); opacity:1; }
}
.vn-pcard-ph-leaf {
  position:relative; z-index:2;
  animation:vn-float3 4s ease-in-out infinite;
}
.vn-pcard-ph-ring {
  position:absolute; border-radius:50%;
  border:1px solid rgba(255,255,255,.08);
  animation:vn-ph-spin linear infinite;
}
@keyframes vn-ph-spin {
  from { transform:translate(-50%,-50%) rotate(0deg); }
  to   { transform:translate(-50%,-50%) rotate(360deg); }
}
.vn-pcard-ph-dot {
  position:absolute; border-radius:50%;
  background:var(--pc-dot); opacity:.35;
  animation:vn-ph-float-dot ease-in-out infinite;
}
@keyframes vn-ph-float-dot {
  0%,100% { transform:translateY(0) scale(1); }
  50%     { transform:translateY(-8px) scale(1.2); }
}
.vn-pcard-overlay {
  position:absolute; inset:0;
  background:linear-gradient(to top, rgba(0,0,0,.35) 0%, transparent 55%);
  pointer-events:none;
}
.vn-pcard-badges {
  position:absolute; top:10px; left:10px;
  display:flex; flex-direction:column; gap:5px; z-index:2;
}
.vn-pcard-badge {
  font-size:10px; font-weight:800; padding:3px 9px;
  border-radius:999px; letter-spacing:.04em; display:inline-block;
  backdrop-filter:blur(6px);
}
.vn-pcard-badge-sale { background:rgba(217,0,0,.85); color:#fff; }
.vn-pcard-badge-feat { background:rgba(0,41,30,.75); color:#a4f3ca; border:1px solid rgba(164,243,202,.3); }
.vn-pcard-badge-out  { background:rgba(0,0,0,.55); color:rgba(255,255,255,.8); }
.vn-pcard-rating {
  position:absolute; bottom:10px; left:10px; z-index:2;
  display:inline-flex; align-items:center; gap:4px;
  background:rgba(0,0,0,.45); backdrop-filter:blur(6px);
  padding:3px 8px; border-radius:999px;
  font-size:11px; font-weight:600; color:#fff;
}
.vn-pcard-body {
  padding:14px 16px 14px; display:flex;
  flex-direction:column; gap:6px; flex:1;
}
.vn-pcard-meta {
  display:flex; align-items:center; justify-content:space-between; gap:4px;
}
.vn-pcard-cat {
  font-size:10px; font-weight:800; text-transform:uppercase;
  letter-spacing:.08em; color:var(--pc-dot,#176b4b);
}
.vn-pcard-pres {
  font-size:10px; color:#9eaaa5; font-weight:500;
  background:#f1f5f0; padding:2px 7px; border-radius:999px;
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:100px;
}
.vn-pcard-name {
  font-size:14px; font-weight:700; color:#00291e; line-height:1.3;
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;
  margin:0;
}
.vn-pcard-desc {
  font-size:12px; color:#717975; line-height:1.6;
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;
  margin:0;
}
.vn-pcard-footer {
  display:flex; align-items:center; justify-content:space-between;
  margin-top:10px; padding-top:10px;
  border-top:1px solid #f1f5f0;
}
.vn-pcard-price-block { display:flex; flex-direction:column; gap:1px; }
.vn-pcard-price-before {
  font-size:11px; color:#b0bab5; text-decoration:line-through; font-weight:500;
}
.vn-pcard-price {
  font-size:17px; font-weight:800; color:#00291e; letter-spacing:-.01em; line-height:1;
}
.vn-pcard-btn {
  width:40px; height:40px; border-radius:14px; border:none; cursor:pointer;
  background:linear-gradient(135deg, var(--pc-from), var(--pc-to));
  color:#fff; display:flex; align-items:center; justify-content:center;
  box-shadow:0 4px 14px -2px rgba(0,41,30,.4);
  transition:transform .2s, box-shadow .2s, filter .2s;
  flex-shrink:0;
}
.vn-pcard-btn:hover { transform:scale(1.1); filter:brightness(1.15); box-shadow:0 6px 20px -2px rgba(0,41,30,.5); }
.vn-pcard-btn:active { transform:scale(.95); }
.vn-pcard-btn-disabled { opacity:.4; cursor:not-allowed; }
.vn-pcard-btn-disabled:hover { transform:none; filter:none; }
.vn-pcard-quickview {
  position:absolute; top:10px; right:10px;
  display:flex; gap:6px;
  opacity:0; pointer-events:none;
  transition:opacity .2s ease, transform .2s ease;
  transform:translateY(-4px);
  z-index:10;
}
.vn-pcard-quickview-btn {
  width:34px; height:34px; border-radius:50%;
  background:rgba(255,255,255,.95); backdrop-filter:blur(6px);
  color:#00291e; border:none; cursor:pointer;
  display:flex; align-items:center; justify-content:center;
  box-shadow:0 2px 10px rgba(0,0,0,.25);
  text-decoration:none;
  transition:background .15s, transform .15s;
}
.vn-pcard-quickview-btn:hover { background:#fff; transform:scale(1.12); }
.vn-pcard:hover .vn-pcard-quickview {
  opacity:1; pointer-events:auto; transform:translateY(0);
}
</style>
</head>
<body class="bg-surface text-on-surface antialiased">

<!-- ═══════ MODALES AUTENTICACIÓN ═══════ -->
<!-- Modal Login -->
<div id="modalLogin" class="modal-overlay" onclick="if(event.target===this)this.classList.remove('open')">
  <div style="background:#fff;border-radius:16px;width:100%;max-width:400px;margin:16px;box-shadow:0 24px 64px rgba(0,0,0,.18);overflow:hidden;">
    <!-- Header con X -->
    <div style="display:flex;justify-content:flex-end;padding:14px 14px 0;">
      <button onclick="document.getElementById('modalLogin').classList.remove('open')" style="background:none;border:none;width:32px;height:32px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#888;font-size:20px;line-height:1;">&times;</button>
    </div>
    <!-- Título centrado -->
    <div style="text-align:center;padding:0 32px 24px;">
      <h2 style="font-size:22px;font-weight:700;color:#176b4b;margin:0 0 24px;">Inicia sesión</h2>
      <?php if ($loginError): ?>
      <div style="background:#ffdad6;color:#93000a;padding:10px 14px;border-radius:10px;font-size:13px;margin-bottom:16px;text-align:left;"><?= h($loginError) ?></div>
      <?php endif; ?>
      <!-- Opción 1: Google -->
      <button type="button" onclick="document.getElementById('modalLogin').classList.remove('open');document.getElementById('modalLoginEmail').classList.add('open')"
        style="width:100%;padding:13px 16px;border-radius:8px;border:1px solid #e0e0e0;background:#fff;color:#3c4043;font-size:14px;font-weight:500;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:10px;transition:background .15s;"
        onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='#fff'">
        <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
        Entrar con Google
      </button>
      <!-- Separador -->
      <div style="display:flex;align-items:center;gap:10px;margin:4px 0 10px;">
        <div style="flex:1;height:1px;background:#e8e8e8;"></div>
        <span style="font-size:13px;color:#999;">o</span>
        <div style="flex:1;height:1px;background:#e8e8e8;"></div>
      </div>
      <!-- Opción 2: Email y contraseña -->
      <button type="button" onclick="document.getElementById('modalLogin').classList.remove('open');document.getElementById('modalLoginEmail').classList.add('open')"
        style="width:100%;padding:13px 16px;border-radius:8px;border:1px solid #e0e0e0;background:#fff;color:#222;font-size:14px;font-weight:500;cursor:pointer;margin-bottom:10px;transition:background .15s;"
        onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='#fff'">
        Ingresar con email y contraseña
      </button>
      <!-- Separador -->
      <div style="height:1px;background:#f0f0f0;margin:4px 0 14px;"></div>
      <!-- Crear cuenta -->
      <p style="font-size:13px;color:#666;margin:0;">
        ¿No tienes cuenta?
        <button onclick="document.getElementById('modalLogin').classList.remove('open');document.getElementById('modalRegistro').classList.add('open')" style="background:none;border:none;color:#176b4b;font-weight:600;cursor:pointer;font-size:13px;">Regístrate gratis</button>
      </p>
    </div>
  </div>
</div>

<!-- Modal Login con Email (segundo paso) -->
<div id="modalLoginEmail" class="modal-overlay" onclick="if(event.target===this)this.classList.remove('open')">
  <div style="background:#fff;border-radius:16px;width:100%;max-width:400px;margin:16px;box-shadow:0 24px 64px rgba(0,0,0,.18);overflow:hidden;">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px 0;">
      <button onclick="document.getElementById('modalLoginEmail').classList.remove('open');document.getElementById('modalLogin').classList.add('open')" style="background:none;border:none;cursor:pointer;color:#555;display:flex;align-items:center;gap:4px;font-size:13px;">
        <span class="material-symbols-outlined" style="font-size:18px;">arrow_back</span> Volver
      </button>
      <button onclick="document.getElementById('modalLoginEmail').classList.remove('open')" style="background:none;border:none;width:32px;height:32px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#888;font-size:20px;">&times;</button>
    </div>
    <div style="padding:16px 32px 28px;">
      <h2 style="font-size:20px;font-weight:700;color:#176b4b;text-align:center;margin:0 0 20px;">Ingresa tus datos</h2>
      <form method="POST" style="display:flex;flex-direction:column;gap:12px;">
        <input type="hidden" name="login_cliente" value="1">
        <div>
          <label style="font-size:12px;font-weight:600;color:#444;display:block;margin-bottom:5px;">Correo electrónico</label>
          <input type="email" name="email_c" required style="width:100%;background:#f7f7f7;border:1.5px solid #e0e0e0;border-radius:8px;padding:11px 14px;font-size:14px;outline:none;box-sizing:border-box;" placeholder="tu@correo.com">
        </div>
        <div>
          <label style="font-size:12px;font-weight:600;color:#444;display:block;margin-bottom:5px;">Contraseña</label>
          <input type="password" name="pass_c" required style="width:100%;background:#f7f7f7;border:1.5px solid #e0e0e0;border-radius:8px;padding:11px 14px;font-size:14px;outline:none;box-sizing:border-box;" placeholder="••••••••">
        </div>
        <button type="submit" style="background:#176b4b;color:#fff;border:none;padding:13px;border-radius:999px;font-size:14px;font-weight:600;cursor:pointer;margin-top:4px;transition:background .2s;" onmouseover="this.style.background='#0d3326'" onmouseout="this.style.background='#176b4b'">Iniciar sesión</button>
      </form>
      <p style="text-align:center;font-size:13px;color:#666;margin-top:16px;">
        ¿No tienes cuenta?
        <button onclick="document.getElementById('modalLoginEmail').classList.remove('open');document.getElementById('modalRegistro').classList.add('open')" style="background:none;border:none;color:#176b4b;font-weight:600;cursor:pointer;font-size:13px;">Regístrate gratis</button>
      </p>
    </div>
  </div>
</div>

<!-- Modal Registro -->
<div id="modalRegistro" class="modal-overlay" onclick="if(event.target===this)this.classList.remove('open')">
  <div style="background:#fff;border-radius:20px;padding:32px;width:100%;max-width:460px;margin:16px;box-shadow:0 24px 48px rgba(0,0,0,.12);max-height:90vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h2 style="font-size:18px;font-weight:700;color:#00291e;">Crear cuenta</h2>
      <button onclick="document.getElementById('modalRegistro').classList.remove('open')" style="background:#f1f5f0;border:none;width:32px;height:32px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:18px;color:#717975;">close</span>
      </button>
    </div>
    <?php if ($regError): ?>
    <div style="background:#ffdad6;color:#93000a;padding:10px 14px;border-radius:10px;font-size:13px;margin-bottom:14px;"><?= h($regError) ?></div>
    <?php endif; ?>
    <?php if ($regOk): ?>
    <div style="background:#a4f3ca;color:#005236;padding:10px 14px;border-radius:10px;font-size:13px;margin-bottom:14px;"><?= h($regOk) ?></div>
    <?php endif; ?>
    <!-- Google -->
    <button type="button" style="
        width:100%;padding:11px;border-radius:10px;margin-bottom:4px;
        border:1.5px solid #dadce0;background:#fff;
        color:#3c4043;font-size:14px;font-weight:500;cursor:pointer;
        display:flex;align-items:center;justify-content:center;gap:10px;
        transition:background .15s,box-shadow .15s;
      "
      onmouseover="this.style.background='#f8f9fa';this.style.boxShadow='0 1px 4px rgba(0,0,0,.1)'"
      onmouseout="this.style.background='#fff';this.style.boxShadow='none'">
      <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
      Registrarse con Google
    </button>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px;">
      <div style="flex:1;height:1px;background:#e8ece8;"></div>
      <span style="font-size:12px;color:#aaa;font-weight:500;">o con tu correo</span>
      <div style="flex:1;height:1px;background:#e8ece8;"></div>
    </div>
    <form method="POST" style="display:flex;flex-direction:column;gap:12px;">
      <input type="hidden" name="registrar_cliente" value="1">
      <div>
        <label style="font-size:12px;font-weight:600;color:#414845;display:block;margin-bottom:4px;">Nombre completo *</label>
        <input name="reg_nombre" required style="width:100%;background:#f1f5f0;border:1.5px solid #c1c8c3;border-radius:10px;padding:10px 14px;font-size:14px;outline:none;" placeholder="Tu nombre">
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;color:#414845;display:block;margin-bottom:4px;">Correo electrónico *</label>
        <input type="email" name="reg_email" required style="width:100%;background:#f1f5f0;border:1.5px solid #c1c8c3;border-radius:10px;padding:10px 14px;font-size:14px;outline:none;" placeholder="tu@correo.com">
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;color:#414845;display:block;margin-bottom:4px;">Teléfono / WhatsApp</label>
        <input name="reg_telefono" style="width:100%;background:#f1f5f0;border:1.5px solid #c1c8c3;border-radius:10px;padding:10px 14px;font-size:14px;outline:none;" placeholder="3XXXXXXXXX">
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;color:#414845;display:block;margin-bottom:4px;">Contraseña *</label>
        <input type="password" name="reg_pass" required style="width:100%;background:#f1f5f0;border:1.5px solid #c1c8c3;border-radius:10px;padding:10px 14px;font-size:14px;outline:none;" placeholder="Mínimo 6 caracteres">
      </div>
      <div>
        <label style="font-size:12px;font-weight:600;color:#414845;display:block;margin-bottom:4px;">Confirmar contraseña *</label>
        <input type="password" name="reg_pass2" required style="width:100%;background:#f1f5f0;border:1.5px solid #c1c8c3;border-radius:10px;padding:10px 14px;font-size:14px;outline:none;" placeholder="Repite la contraseña">
      </div>
      <button type="submit" style="background:#176b4b;color:#fff;border:none;padding:12px;border-radius:999px;font-size:14px;font-weight:600;cursor:pointer;">Crear cuenta gratis</button>
    </form>
    <p style="text-align:center;font-size:13px;color:#717975;margin-top:16px;">
      ¿Ya tienes cuenta?
      <button onclick="document.getElementById('modalRegistro').classList.remove('open');document.getElementById('modalLogin').classList.add('open')" style="background:none;border:none;color:#176b4b;font-weight:600;cursor:pointer;">Inicia sesión</button>
    </p>
  </div>
</div>

<!-- ═══════ CARRITO DRAWER ═══════ -->
<style>
#cartDrawer {
  background:#0d1f19;
  color:#fff;
}
#cartDrawer .vn-cart-header {
  display:flex; align-items:center; justify-content:space-between;
  padding:20px 22px 18px;
  border-bottom:1px solid rgba(255,255,255,.07);
  background:linear-gradient(180deg,#0a1a14 0%,#0d1f19 100%);
}
#cartDrawer .vn-cart-title {
  display:flex; align-items:center; gap:10px;
}
#cartDrawer .vn-cart-title-icon {
  width:38px; height:38px; border-radius:12px;
  background:rgba(164,243,202,.12); border:1px solid rgba(164,243,202,.2);
  display:flex; align-items:center; justify-content:center;
}
#cartDrawer .vn-cart-close {
  width:36px; height:36px; border-radius:10px;
  background:rgba(255,255,255,.07); border:1px solid rgba(255,255,255,.1);
  display:flex; align-items:center; justify-content:center;
  cursor:pointer; transition:background .2s; color:#fff;
}
#cartDrawer .vn-cart-close:hover { background:rgba(255,255,255,.14); }

/* Item del carrito */
.vn-cart-item {
  display:flex; align-items:center; gap:12px;
  background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.07);
  border-radius:16px; padding:12px; transition:background .2s;
}
.vn-cart-item:hover { background:rgba(255,255,255,.07); }
.vn-cart-item-img {
  width:54px; height:54px; border-radius:11px; object-fit:cover;
  background:linear-gradient(135deg,#003320,#005a38); flex-shrink:0;
  display:flex; align-items:center; justify-content:center; overflow:hidden;
}
.vn-cart-item-img img { width:100%; height:100%; object-fit:cover; }
.vn-cart-item-info { flex:1; min-width:0; }
.vn-cart-item-name {
  font-size:13px; font-weight:600; color:#fff; line-height:1.3;
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
  display:block; margin-bottom:3px;
}
.vn-cart-item-price { font-size:13px; font-weight:700; color:#a4f3ca; }
.vn-cart-qty {
  display:flex; align-items:center; gap:8px; flex-shrink:0;
}
.vn-cart-qty-btn {
  width:28px; height:28px; border-radius:8px;
  background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.12);
  color:#fff; font-size:16px; font-weight:700; cursor:pointer;
  display:flex; align-items:center; justify-content:center;
  transition:background .2s; line-height:1;
}
.vn-cart-qty-btn:hover { background:rgba(164,243,202,.2); }
.vn-cart-qty-num { font-size:14px; font-weight:700; color:#fff; min-width:18px; text-align:center; }
.vn-cart-del {
  width:28px; height:28px; border-radius:8px;
  background:rgba(255,100,100,.1); border:1px solid rgba(255,100,100,.15);
  color:rgba(255,150,150,.8); cursor:pointer;
  display:flex; align-items:center; justify-content:center;
  transition:background .2s;
}
.vn-cart-del:hover { background:rgba(255,100,100,.22); color:#ff8080; }

/* Empty state */
#cartEmpty {
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  height:100%; gap:14px; text-align:center; padding:40px 20px;
}

/* Footer */
#cartFooter {
  padding:18px 22px 24px;
  border-top:1px solid rgba(255,255,255,.07);
  background:linear-gradient(0deg,#0a1a14 0%,#0d1f19 100%);
}
.vn-cart-shipping-bar {
  background:rgba(164,243,202,.07); border:1px solid rgba(164,243,202,.12);
  border-radius:12px; padding:10px 14px; margin-bottom:16px;
  display:flex; align-items:center; gap:10px;
}
.vn-cart-total-row {
  display:flex; align-items:flex-end; justify-content:space-between;
  margin-bottom:16px; padding-bottom:14px;
  border-bottom:1px solid rgba(255,255,255,.06);
}
.vn-cart-btn-primary {
  width:100%; padding:14px; border-radius:14px; border:none; cursor:pointer;
  background:linear-gradient(135deg,#176b4b,#1a8560);
  color:#fff; font-size:15px; font-weight:700;
  display:flex; align-items:center; justify-content:center; gap:8px;
  box-shadow:0 6px 24px rgba(23,107,75,.45);
  transition:filter .2s, transform .2s;
}
.vn-cart-btn-primary:hover { filter:brightness(1.1); transform:translateY(-1px); }
.vn-cart-btn-wa {
  width:100%; padding:12px; border-radius:14px; border:none; cursor:pointer;
  background:rgba(37,163,90,.18); border:1px solid rgba(37,163,90,.3);
  color:#6ee89a; font-size:13px; font-weight:600;
  display:flex; align-items:center; justify-content:center; gap:7px;
  margin-top:10px; text-decoration:none;
  transition:background .2s;
}
.vn-cart-btn-wa:hover { background:rgba(37,163,90,.28); }
.vn-cart-btn-clear {
  width:100%; background:none; border:none; cursor:pointer;
  font-size:12px; color:rgba(255,255,255,.3); margin-top:10px; padding:4px;
  transition:color .2s;
}
.vn-cart-btn-clear:hover { color:rgba(255,100,100,.6); }
</style>

<div id="cartOverlay" class="fixed inset-0 z-50 opacity-0 pointer-events-none" style="background:rgba(0,0,0,.6);backdrop-filter:blur(4px);" onclick="closeCartDrawer()"></div>
<div id="cartDrawer" class="fixed top-0 right-0 h-full w-full max-w-sm z-50 shadow-2xl flex flex-col translate-x-full" style="max-width:380px;">

  <!-- Header -->
  <div class="vn-cart-header">
    <div class="vn-cart-title">
      <div class="vn-cart-title-icon">
        <span class="material-symbols-outlined" style="color:#a4f3ca;font-size:20px;">shopping_bag</span>
      </div>
      <div>
        <div style="font-size:16px;font-weight:700;color:#fff;line-height:1.1;">Mi Carrito</div>
        <div style="font-size:11px;color:rgba(255,255,255,.4);font-weight:500;" id="cartHeaderCount">0 productos</div>
      </div>
    </div>
    <button onclick="closeCartDrawer()" class="vn-cart-close">
      <span class="material-symbols-outlined" style="font-size:19px;">close</span>
    </button>
  </div>

  <!-- Items -->
  <div id="cartItems" style="flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;">
    <div id="cartEmpty">
      <div style="width:72px;height:72px;border-radius:20px;background:rgba(164,243,202,.08);border:1px solid rgba(164,243,202,.12);display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:34px;color:rgba(164,243,202,.4);">shopping_bag</span>
      </div>
      <div style="font-size:15px;font-weight:600;color:rgba(255,255,255,.6);">Tu carrito está vacío</div>
      <div style="font-size:12px;color:rgba(255,255,255,.3);line-height:1.6;">Agrega productos desde el catálogo para comenzar tu pedido.</div>
      <button onclick="closeCartDrawer()" style="margin-top:4px;background:rgba(164,243,202,.12);border:1px solid rgba(164,243,202,.2);color:#a4f3ca;padding:8px 20px;border-radius:999px;font-size:13px;font-weight:600;cursor:pointer;">Ver catálogo</button>
    </div>
  </div>

  <!-- Footer -->
  <div id="cartFooter" style="display:none;" class="p-0">
    <div style="padding:0 22px 0;">
      <!-- Barra envío gratis -->
      <div class="vn-cart-shipping-bar">
        <span class="material-symbols-outlined" style="font-size:18px;color:#a4f3ca;flex-shrink:0;">local_shipping</span>
        <p style="font-size:12px;color:rgba(255,255,255,.55);line-height:1.5;">
          Envío gratis en compras superiores a
          <strong style="color:#a4f3ca;">$ <?= number_format((int)$envioMin,0,',','.') ?> COP</strong>
        </p>
      </div>
      <!-- Total -->
      <div class="vn-cart-total-row">
        <div>
          <div style="font-size:11px;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em;margin-bottom:3px;">Total estimado</div>
          <div id="cartTotal" style="font-size:26px;font-weight:800;color:#fff;letter-spacing:-.02em;line-height:1;">$ 0 COP</div>
        </div>
        <div style="font-size:11px;color:rgba(164,243,202,.6);text-align:right;">
          <span id="cartItemCount">0</span> ítem(s)
        </div>
      </div>
      <!-- Botones -->
      <button onclick="openCheckout()" class="vn-cart-btn-primary">
        <span class="material-symbols-outlined" style="font-size:20px;">verified</span>
        Confirmar Pedido
      </button>
      <a id="cartWhatsApp" href="#" target="_blank" class="vn-cart-btn-wa">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.52 3.48A11.93 11.93 0 0 0 12 0C5.37 0 0 5.37 0 12c0 2.11.55 4.16 1.6 5.97L0 24l6.19-1.62A11.94 11.94 0 0 0 12 24c6.63 0 12-5.37 12-12 0-3.2-1.25-6.21-3.48-8.52ZM12 22c-1.85 0-3.66-.5-5.24-1.44l-.37-.22-3.86 1.01 1.03-3.76-.24-.38A9.94 9.94 0 0 1 2 12C2 6.48 6.48 2 12 2c2.67 0 5.18 1.04 7.07 2.93A9.95 9.95 0 0 1 22 12c0 5.52-4.48 10-10 10Z"/></svg>
        Solo WhatsApp (sin registro)
      </a>
      <button onclick="clearCart()" class="vn-cart-btn-clear">Vaciar carrito</button>
    </div>
  </div>
</div>

<!-- ═══════ HEADER ═══════ -->
<header class="fixed top-0 left-0 right-0 w-full z-40 bg-surface/95 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.05)]">
  <!-- Barra superior animada -->
  <div id="topBar" style="background:linear-gradient(90deg,#0d3326 0%,#176b4b 50%,#0d3326 100%);color:#e0f5ec;padding:7px 16px;display:flex;align-items:center;justify-content:center;gap:10px;position:relative;overflow:hidden;">
    <!-- destello animado de fondo -->
    <div style="position:absolute;inset:0;background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.04) 50%,transparent 100%);animation:vn-shine 3s ease-in-out infinite;pointer-events:none;"></div>
    <!-- ícono pulsante -->
    <span style="display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;background:rgba(164,243,202,.2);flex-shrink:0;">
      <span style="width:7px;height:7px;border-radius:50%;background:#a4f3ca;display:block;animation:pulse 2s infinite;"></span>
    </span>
    <!-- texto rotativo -->
    <div style="overflow:hidden;height:18px;position:relative;min-width:0;flex:1;max-width:600px;">
      <div id="topBarTexts" style="display:flex;flex-direction:column;transition:transform .5s ease;">
        <span style="font-size:12px;font-weight:500;white-space:nowrap;text-align:center;display:block;line-height:18px;">🌿 Regístrate y recibe <strong>asesoría natural gratuita</strong> · Pedidos directos por WhatsApp</span>
        <span style="font-size:12px;font-weight:500;white-space:nowrap;text-align:center;display:block;line-height:18px;">🚚 Despachos seguros a <strong>toda Colombia</strong> · Cali, Valle del Cauca</span>
        <span style="font-size:12px;font-weight:500;white-space:nowrap;text-align:center;display:block;line-height:18px;">✅ Productos con <strong>Registro INVIMA</strong> · 100% naturales y certificados</span>
        <span style="font-size:12px;font-weight:500;white-space:nowrap;text-align:center;display:block;line-height:18px;">💬 ¿Tienes dudas? <strong>Escríbenos por WhatsApp</strong> y te asesoramos al instante</span>
      </div>
    </div>
    <button onclick="document.getElementById('topBar').style.display='none'" style="background:none;border:none;color:#88d6af;cursor:pointer;flex-shrink:0;line-height:1;padding:0;">
      <span class="material-symbols-outlined" style="font-size:16px;">close</span>
    </button>
  </div>
  <style>
  @keyframes vn-shine { 0%,100%{opacity:0} 50%{opacity:1} }
  </style>
  <script>
  (function(){
    var el=document.getElementById('topBarTexts');
    if(!el) return;
    var total=el.children.length, cur=0;
    setInterval(function(){
      cur=(cur+1)%total;
      el.style.transform='translateY(-'+(cur*18)+'px)';
    },3500);
  })();
  </script>

  <!-- Logo + búsqueda + acciones -->
  <div class="max-w-7xl mx-auto px-4 lg:px-10 flex items-center justify-between gap-4 py-2">
    <!-- Logo SVG inline -->
    <a href="index.php" class="flex items-center gap-2 shrink-0">
      <svg width="38" height="38" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="60" cy="62" rx="42" ry="52" fill="#176b4b"/>
        <path d="M60 100 C60 100 60 50 60 25" stroke="white" stroke-width="5" stroke-linecap="round"/>
        <path d="M60 60 C45 50 30 42 28 28" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
        <path d="M60 75 C45 65 32 60 30 46" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
        <path d="M60 60 C75 50 90 42 92 28" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
        <path d="M60 75 C75 65 88 60 90 46" stroke="white" stroke-width="3.5" stroke-linecap="round"/>
      </svg>
      <div class="hidden sm:flex flex-col leading-tight">
        <span style="font-size:16px;font-weight:800;color:#00291e;letter-spacing:-.02em;">Verde Natural</span>
        <span style="font-size:10px;color:#717975;text-transform:uppercase;letter-spacing:.06em;">Productos Naturales</span>
      </div>
    </a>

    <!-- Búsqueda -->
    <form method="GET" action="index.php" class="flex-1 max-w-lg hidden md:block">
      <input type="hidden" name="page" value="buscar">
      <div class="relative flex items-center">
        <span class="material-symbols-outlined absolute left-4 text-outline text-[20px]">search</span>
        <input name="q" type="text" value="<?= h($busqueda) ?>"
               class="w-full bg-surface-container-lowest text-on-surface placeholder:text-on-surface-variant/50 pl-11 pr-4 py-2 rounded-full border border-outline-variant text-sm focus:outline-none focus:border-secondary"
               placeholder="Buscar jarabes, suplementos, purgantes...">
      </div>
    </form>

    <!-- Acciones header -->
    <div class="flex items-center gap-2">
      <a href="https://wa.me/<?= $waNumber ?>" target="_blank"
         class="hidden lg:flex items-center gap-1.5 text-on-surface-variant hover:text-primary transition-colors">
        <span class="material-symbols-outlined text-[20px] text-secondary">support_agent</span>
        <div class="flex flex-col text-left">
          <span class="text-[11px] text-on-surface-variant">Asesoría Natural</span>
          <span class="text-[13px] font-semibold text-primary">(+57) 320 670 8805</span>
        </div>
      </a>

      <button onclick="<?= $clienteLogueado ? 'openCartDrawer()' : 'requireLogin()' ?>"
              class="relative flex items-center gap-1.5 bg-surface-container-lowest text-on-surface border border-outline-variant hover:bg-surface-container py-2 px-4 rounded-full shadow-sm">
        <span class="material-symbols-outlined text-[20px] text-primary">shopping_bag</span>
        <span class="text-sm font-medium hidden sm:inline">Carrito</span>
        <?php if ($clienteLogueado): ?>
        <span id="cartBadge" class="bg-tertiary-fixed-dim text-tertiary text-[11px] font-bold px-2 py-0.5 rounded-full ml-1 hidden">0</span>
        <?php endif; ?>
      </button>

      <!-- Botón cuenta cliente -->
      <?php if ($clienteLogueado): ?>
      <div style="position:relative;" id="menuCliente">
        <button onclick="document.getElementById('dropCliente').classList.toggle('hidden')"
                style="display:flex;align-items:center;gap:6px;background:#a4f3ca;color:#005236;border:none;padding:6px 14px;border-radius:999px;font-size:13px;font-weight:600;cursor:pointer;">
          <span class="material-symbols-outlined" style="font-size:18px;">person</span>
          <?= h(explode(' ',$clienteNombre)[0]) ?>
        </button>
        <div id="dropCliente" class="hidden" style="position:absolute;right:0;top:calc(100%+8px);background:#fff;border-radius:14px;box-shadow:0 8px 24px rgba(0,0,0,.1);min-width:180px;overflow:hidden;z-index:60;">
          <div style="padding:12px 16px;border-bottom:1px solid #f1f5f0;">
            <span style="font-size:12px;color:#717975;">Mi cuenta</span>
            <span style="font-size:14px;font-weight:600;color:#00291e;display:block;"><?= h($clienteNombre) ?></span>
          </div>
          <a href="index.php?logout_cliente=1" style="display:flex;align-items:center;gap:8px;padding:12px 16px;font-size:13px;color:#93000a;text-decoration:none;background:transparent;transition:background .15s;" onmouseover="this.style.background='#ffdad6'" onmouseout="this.style.background='transparent'">
            <span class="material-symbols-outlined" style="font-size:16px;">logout</span> Cerrar sesión
          </a>
        </div>
      </div>
      <?php else: ?>
      <!-- Dropdown Mi Cuenta (no logueado) -->
      <div style="position:relative;" id="vn-account-wrap">
        <button onclick="vnToggleAccountDrop()"
                style="display:flex;align-items:center;gap:6px;background:#ebefea;color:#00291e;border:none;padding:6px 14px;border-radius:999px;font-size:13px;font-weight:600;cursor:pointer;transition:background .15s;"
                onmouseover="this.style.background='#d8ede2'" onmouseout="this.style.background='#ebefea'">
          <span class="material-symbols-outlined" style="font-size:18px;">person</span>
          <span class="hidden sm:inline">Mi cuenta</span>
          <span class="material-symbols-outlined hidden sm:inline" style="font-size:16px;opacity:.6;" id="vn-account-chevron">expand_more</span>
        </button>
        <!-- Dropdown panel -->
        <div id="vn-account-drop" style="
          display:none; position:absolute; right:0; top:calc(100%+10px);
          background:#fff; border-radius:16px;
          box-shadow:0 8px 32px rgba(0,0,0,.13),0 2px 8px rgba(0,0,0,.07);
          min-width:260px; overflow:hidden; z-index:200;
          border:1px solid rgba(0,41,30,.07);
        ">
          <!-- Encabezado -->
          <div style="padding:18px 20px 14px;background:linear-gradient(135deg,#003d2b 0%,#006644 100%);color:#fff;">
            <div style="display:flex;align-items:center;gap:12px;">
              <div style="width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;">
                <span class="material-symbols-outlined" style="font-size:22px;color:#fff;">person</span>
              </div>
              <div>
                <div style="font-size:14px;font-weight:700;">¡Bienvenido!</div>
                <div style="font-size:12px;opacity:.75;">Para ver tus pedidos y recibir descuentos</div>
              </div>
            </div>
          </div>
          <!-- Botones de acceso -->
          <div style="padding:16px 16px 8px;display:flex;flex-direction:column;gap:8px;">
            <!-- Google -->
            <button type="button" onclick="vnToggleAccountDrop();document.getElementById('modalLogin').classList.add('open')"
              style="
                width:100%;padding:10px;border-radius:10px;
                border:1.5px solid #dadce0;background:#fff;
                color:#3c4043;font-size:13px;font-weight:500;cursor:pointer;
                display:flex;align-items:center;justify-content:center;gap:8px;
                transition:background .15s,box-shadow .15s;
              "
              onmouseover="this.style.background='#f8f9fa';this.style.boxShadow='0 1px 4px rgba(0,0,0,.1)'"
              onmouseout="this.style.background='#fff';this.style.boxShadow='none'">
              <svg width="17" height="17" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continuar con Google
            </button>
            <!-- Divisor -->
            <div style="display:flex;align-items:center;gap:8px;">
              <div style="flex:1;height:1px;background:#eee;"></div>
              <span style="font-size:11px;color:#bbb;">o</span>
              <div style="flex:1;height:1px;background:#eee;"></div>
            </div>
            <button onclick="vnToggleAccountDrop();document.getElementById('modalLogin').classList.add('open')"
              style="width:100%;padding:11px;border-radius:10px;border:none;background:#00291e;color:#fff;font-size:14px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:background .15s;"
              onmouseover="this.style.background='#004d38'" onmouseout="this.style.background='#00291e'">
              <span class="material-symbols-outlined" style="font-size:17px;">login</span>
              Iniciar sesión
            </button>
            <button onclick="vnToggleAccountDrop();document.getElementById('modalRegistro').classList.add('open')"
              style="width:100%;padding:11px;border-radius:10px;border:1.5px solid #00291e;background:#fff;color:#00291e;font-size:14px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:background .15s;"
              onmouseover="this.style.background='#f0f7f4'" onmouseout="this.style.background='#fff'">
              <span class="material-symbols-outlined" style="font-size:17px;">person_add</span>
              Crear cuenta gratis
            </button>
          </div>
          <!-- Divisor -->
          <div style="height:1px;background:#f1f5f0;margin:8px 0;"></div>
          <!-- Links rápidos -->
          <div style="padding:4px 8px 10px;">
            <a href="https://wa.me/<?= preg_replace('/\D/','',$waNumber) ?>?text=Hola%2C%20tengo%20una%20pregunta%20sobre%20Verde%20Natural%20🌿" target="_blank"
               style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;text-decoration:none;color:#1a3a30;font-size:13px;font-weight:500;transition:background .15s;"
               onmouseover="this.style.background='#f0f7f4'" onmouseout="this.style.background='transparent'">
              <span style="width:30px;height:30px;border-radius:50%;background:#dcfce7;display:flex;align-items:center;justify-content:center;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#16a34a"><path d="M20.52 3.48A11.93 11.93 0 0 0 12 0C5.37 0 0 5.37 0 12c0 2.11.55 4.16 1.6 5.97L0 24l6.19-1.62A11.94 11.94 0 0 0 12 24c6.63 0 12-5.37 12-12 0-3.2-1.25-6.21-3.48-8.52ZM12 22c-1.85 0-3.66-.5-5.24-1.44l-.37-.22-3.86 1.01 1.03-3.76-.24-.38A9.94 9.94 0 0 1 2 12C2 6.48 6.48 2 12 2c2.67 0 5.18 1.04 7.07 2.93A9.95 9.95 0 0 1 22 12c0 5.52-4.48 10-10 10Zm5.44-7.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15s-.77.97-.94 1.17c-.17.2-.34.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.34.45-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.6-.91-2.19-.24-.58-.48-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.03 1.01-1.03 2.46s1.06 2.85 1.2 3.05c.15.2 2.07 3.17 5.02 4.44.7.3 1.25.48 1.68.62.7.22 1.34.19 1.85.12.56-.08 1.76-.72 2.01-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.19-.57-.34Z"/></svg>
              </span>
              Contactar por WhatsApp
            </a>
          </div>
        </div>
      </div>
      <?php endif; ?>
<script>
function vnToggleAccountDrop(){
  var d=document.getElementById('vn-account-drop');
  var c=document.getElementById('vn-account-chevron');
  var open=d.style.display==='block';
  d.style.display=open?'none':'block';
  if(c) c.textContent=open?'expand_more':'expand_less';
}
document.addEventListener('click',function(e){
  var w=document.getElementById('vn-account-wrap');
  if(w&&!w.contains(e.target)){
    var d=document.getElementById('vn-account-drop');
    var c=document.getElementById('vn-account-chevron');
    if(d) d.style.display='none';
    if(c) c.textContent='expand_more';
  }
});
</script>
    </div>
  </div>

  <!-- Nav categorías -->
  <div class="bg-surface-container-low border-t border-outline-variant/30">
    <div class="max-w-7xl mx-auto px-4 lg:px-10 flex items-center overflow-x-auto">
      <nav class="flex items-center gap-1 py-2 whitespace-nowrap">
        <a href="index.php" class="px-3 py-1 text-sm font-medium transition-colors rounded-full <?= $page==='inicio'?'bg-primary text-white font-semibold shadow-sm':'text-on-surface-variant hover:text-primary hover:bg-surface-container' ?>">Inicio</a>
        <?php foreach ($categorias as $cat): ?>
        <a href="index.php?page=categoria&cat=<?= h($cat['slug']) ?>"
           class="px-3 py-1 text-sm font-medium transition-colors rounded-full <?= ($catSlug===$cat['slug'])?'bg-primary text-white font-semibold shadow-sm':'text-on-surface-variant hover:text-primary hover:bg-surface-container' ?>">
          <?= h($cat['nombre']) ?>
        </a>
        <?php endforeach; ?>
        <a href="index.php?page=nosotros"
           class="px-3 py-1 text-sm font-medium transition-colors rounded-full <?= $page==='nosotros'?'bg-primary text-white font-semibold shadow-sm':'text-on-surface-variant hover:text-primary hover:bg-surface-container' ?>">
          Sobre Nosotros
        </a>
      </nav>
    </div>
  </div>
</header>

<div class="h-[116px]"></div>

<!-- ═══════ CONTENIDO ═══════ -->
<main class="w-full bg-surface">

<?php if ($page==='inicio'): ?>
<!-- ───── INICIO: HERO ANIMADO ───── -->
<style>
@keyframes vn-float { 0%,100%{transform:translateY(0) rotate(0deg);opacity:.7} 50%{transform:translateY(-24px) rotate(8deg);opacity:1} }
@keyframes vn-float2 { 0%,100%{transform:translateY(0) rotate(0deg);opacity:.4} 50%{transform:translateY(-18px) rotate(-6deg);opacity:.8} }
@keyframes vn-float3 { 0%,100%{transform:translateY(0) scale(1)} 50%{transform:translateY(-30px) scale(1.1)} }
@keyframes vn-pulse-ring { 0%{transform:scale(1);opacity:.6} 100%{transform:scale(2.2);opacity:0} }
@keyframes vn-slide-up { from{opacity:0;transform:translateY(32px)} to{opacity:1;transform:translateY(0)} }
@keyframes vn-slide-in { from{opacity:0;transform:translateX(-24px)} to{opacity:1;transform:translateX(0)} }
@keyframes vn-glow { 0%,100%{box-shadow:0 0 20px rgba(136,214,175,.3)} 50%{box-shadow:0 0 40px rgba(136,214,175,.6)} }
@keyframes vn-scroll { 0%{transform:translateY(0);opacity:1} 60%{transform:translateY(10px);opacity:0} 100%{transform:translateY(0);opacity:0} }
@keyframes vn-counter { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
@keyframes vn-bg-ken { 0%{transform:scale(1)} 100%{transform:scale(1.08)} }
.vn-hero-slide { position:absolute;inset:0;opacity:0;transition:opacity .9s cubic-bezier(.4,0,.2,1); }
.vn-hero-slide.active { opacity:1; }
.vn-hero-slide .vn-bg-img { animation:none; }
.vn-hero-slide.active .vn-bg-img { animation:vn-bg-ken 8s ease-out forwards; }
.vn-dot { width:8px;height:8px;border-radius:999px;background:rgba(164,243,202,.35);border:none;cursor:pointer;transition:all .3s;padding:0; }
.vn-dot.active { width:28px;background:#88d6af; }
.vn-stat-card { background:rgba(255,255,255,.07);backdrop-filter:blur(12px);border:1px solid rgba(164,243,202,.15);border-radius:16px;padding:14px 18px; }
</style>

<section class="w-full px-4 lg:px-10 py-6">
  <div class="max-w-7xl mx-auto">
    <div id="vnHero" class="relative w-full rounded-2xl overflow-hidden shadow-2xl" style="min-height:520px;">
      <!-- Canvas de partículas flotantes -->
      <canvas id="heroParticles" style="position:absolute;inset:0;width:100%;height:100%;z-index:1;pointer-events:none;opacity:.55;"></canvas>

      <?php
      // Paleta de colores por slide — coincide con las tarjetas de categorías
      $slidePalettes = [
        0 => [ // Verde — Jarabes
          'grad'    => 'linear-gradient(135deg,#001a10 0%,#003320 40%,#005a38 70%,#007a4d 100%)',
          'overlay' => 'linear-gradient(110deg,rgba(0,26,16,.93) 0%,rgba(0,51,32,.78) 45%,rgba(0,90,56,.5) 75%,transparent 100%)',
          'ambient' => 'rgba(0,122,77,.35)',
          'ambient2'=> 'rgba(164,243,202,.12)',
          'accent'  => '#a4f3ca',
          'accentDim'=> '#88d6af',
          'btnBg'   => '#176b4b',
          'btnHover'=> '#1a8560',
          'btnGlow' => 'rgba(23,107,75,.45)',
          'ring'    => 'rgba(164,243,202,.2)',
        ],
        1 => [ // Azul/Morado — Suplementos
          'grad'    => 'linear-gradient(135deg,#0a0a2e 0%,#1a1a4e 40%,#2d2d80 70%,#4040b0 100%)',
          'overlay' => 'linear-gradient(110deg,rgba(10,10,46,.93) 0%,rgba(26,26,78,.78) 45%,rgba(45,45,128,.5) 75%,transparent 100%)',
          'ambient' => 'rgba(64,64,176,.35)',
          'ambient2'=> 'rgba(192,200,255,.12)',
          'accent'  => '#c0c8ff',
          'accentDim'=> '#a0aaff',
          'btnBg'   => '#3535a0',
          'btnHover'=> '#4040b8',
          'btnGlow' => 'rgba(53,53,160,.55)',
          'ring'    => 'rgba(192,200,255,.2)',
        ],
        2 => [ // Café/Naranja — Purgantes
          'grad'    => 'linear-gradient(135deg,#1a0a00 0%,#3d1a00 40%,#6b3200 70%,#9a4800 100%)',
          'overlay' => 'linear-gradient(110deg,rgba(26,10,0,.93) 0%,rgba(61,26,0,.78) 45%,rgba(107,50,0,.5) 75%,transparent 100%)',
          'ambient' => 'rgba(154,72,0,.35)',
          'ambient2'=> 'rgba(255,213,168,.12)',
          'accent'  => '#ffd5a8',
          'accentDim'=> '#ffba70',
          'btnBg'   => '#7a3a00',
          'btnHover'=> '#964800',
          'btnGlow' => 'rgba(122,58,0,.55)',
          'ring'    => 'rgba(255,213,168,.2)',
        ],
      ];
      foreach ($banners as $i => $b):
        $pal = $slidePalettes[$i % 3];
      ?>
      <!-- SLIDE <?= $i+1 ?> -->
      <div class="vn-hero-slide <?= $i===0?'active':'' ?>" data-index="<?= $i ?>">

        <!-- Imagen de fondo desde admin -->
        <?php if (!empty($b['imagen_url'])): ?>
        <div class="vn-bg-img" style="position:absolute;inset:0;background-image:url('<?= h($b['imagen_url']) ?>');background-size:cover;background-position:center;"></div>
        <div style="position:absolute;inset:0;<?= 'background:'.$pal['overlay'] ?>;"></div>
        <?php else: ?>
        <!-- Fondo degradado por paleta del slide -->
        <div class="vn-bg-img" style="position:absolute;inset:0;<?= 'background:'.$pal['grad'] ?>;"></div>
        <!-- Efecto de luz ambiental animada -->
        <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 15% 60%,<?= $pal['ambient'] ?> 0%,transparent 55%),radial-gradient(ellipse at 85% 30%,<?= $pal['ambient2'] ?> 0%,transparent 50%);animation:vn-float3 7s ease-in-out infinite;"></div>
        <?php endif; ?>

        <!-- Partículas flotantes decorativas -->
        <div style="position:absolute;inset:0;pointer-events:none;overflow:hidden;">
          <svg style="position:absolute;right:8%;top:12%;opacity:.18;animation:vn-float 6s ease-in-out infinite;" width="90" height="90" viewBox="0 0 120 120" fill="none">
            <ellipse cx="60" cy="62" rx="42" ry="52" fill="white"/>
            <path d="M60 100 C60 100 60 50 60 25" stroke="rgba(0,0,0,.3)" stroke-width="5" stroke-linecap="round"/>
            <path d="M60 60 C45 50 30 42 28 28" stroke="rgba(0,0,0,.2)" stroke-width="3.5" stroke-linecap="round"/>
            <path d="M60 75 C45 65 32 60 30 46" stroke="rgba(0,0,0,.2)" stroke-width="3.5" stroke-linecap="round"/>
            <path d="M60 60 C75 50 90 42 92 28" stroke="rgba(0,0,0,.2)" stroke-width="3.5" stroke-linecap="round"/>
          </svg>
          <svg style="position:absolute;right:22%;bottom:15%;opacity:.10;animation:vn-float2 8s ease-in-out infinite 1s;" width="55" height="55" viewBox="0 0 120 120" fill="none">
            <ellipse cx="60" cy="62" rx="42" ry="52" fill="white"/>
            <path d="M60 100 C60 100 60 50 60 25" stroke="rgba(0,0,0,.3)" stroke-width="5" stroke-linecap="round"/>
            <path d="M60 60 C45 50 30 42 28 28" stroke="rgba(0,0,0,.2)" stroke-width="4" stroke-linecap="round"/>
            <path d="M60 60 C75 50 90 42 92 28" stroke="rgba(0,0,0,.2)" stroke-width="4" stroke-linecap="round"/>
          </svg>
          <!-- Círculos pulsantes con color de paleta -->
          <div style="position:absolute;right:32%;top:28%;width:120px;height:120px;">
            <div style="position:absolute;inset:0;border-radius:50%;border:1px solid <?= $pal['ring'] ?>;animation:vn-pulse-ring 3s ease-out infinite;"></div>
            <div style="position:absolute;inset:0;border-radius:50%;border:1px solid <?= $pal['ring'] ?>;animation:vn-pulse-ring 3s ease-out infinite .8s;"></div>
          </div>
          <!-- Polígono decorativo top-right con color de paleta -->
          <div style="position:absolute;top:-60px;right:-60px;width:280px;height:280px;border-radius:50%;border:1px solid <?= $pal['ring'] ?>;opacity:.4;"></div>
          <div style="position:absolute;top:-30px;right:-30px;width:200px;height:200px;border-radius:50%;border:1px solid <?= $pal['ring'] ?>;opacity:.6;"></div>
        </div>

        <!-- Contenido del slide -->
        <div class="relative z-10 flex flex-col lg:flex-row items-center w-full" style="min-height:520px;">
          <div class="flex-1 px-8 lg:px-14 py-14 flex flex-col items-start gap-5">

            <!-- Badge Verde Natural -->
            <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full"
                 style="background:rgba(255,255,255,.08);border:1px solid <?= $pal['ring'] ?>;animation:vn-slide-in .6s ease both <?= $i===0?'0s':'.2s' ?>;">
              <span class="material-symbols-outlined" style="color:<?= $pal['accentDim'] ?>;font-size:15px;">eco</span>
              <span style="font-size:10px;color:<?= $pal['accent'] ?>;text-transform:uppercase;letter-spacing:.12em;font-weight:700;">Verde Natural · Productos para tu Salud</span>
            </div>

            <!-- Título grande -->
            <h1 style="font-size:clamp(30px,5vw,58px);font-weight:900;color:#fff;line-height:1.05;letter-spacing:-.025em;animation:vn-slide-up .7s ease both .1s;">
              <?= $b['titulo'] ? h($b['titulo']) : 'Naturaleza que<br>sana de verdad' ?>
            </h1>

            <!-- Subtítulo con color de paleta -->
            <p style="font-size:13px;color:<?= $pal['accentDim'] ?>;font-weight:700;text-transform:uppercase;letter-spacing:.1em;animation:vn-slide-up .7s ease both .2s;">
              <?= h($b['subtitulo'] ?? 'Fórmulas colombianas certificadas') ?>
            </p>

            <!-- Descripción -->
            <p style="font-size:15px;color:rgba(255,255,255,.75);max-width:520px;line-height:1.7;animation:vn-slide-up .7s ease both .3s;">
              <?= h($b['descripcion'] ?? 'Extractos naturales, jarabes y fórmulas colombianas con certificación INVIMA. Pedidos directos por WhatsApp con asesoría experta.') ?>
            </p>

            <!-- Botones CTA con color de paleta -->
            <div class="flex flex-wrap items-center gap-3 pt-1" style="animation:vn-slide-up .7s ease both .4s;">
              <a href="#catalogo"
                 style="display:inline-flex;align-items:center;gap:8px;background:<?= $pal['btnBg'] ?>;color:#fff;font-weight:700;font-size:14px;padding:13px 26px;border-radius:999px;text-decoration:none;transition:all .25s;box-shadow:0 6px 24px <?= $pal['btnGlow'] ?>;"
                 onmouseover="this.style.background='<?= $pal['btnHover'] ?>';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='<?= $pal['btnBg'] ?>';this.style.transform='translateY(0)'">
                <span class="material-symbols-outlined" style="font-size:18px;">eco</span>
                Ver Catálogo
              </a>
              <a href="https://wa.me/<?= $waNumber ?>" target="_blank"
                 style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.12);backdrop-filter:blur(8px);border:1px solid <?= $pal['ring'] ?>;color:#fff;font-weight:700;font-size:14px;padding:13px 26px;border-radius:999px;text-decoration:none;transition:all .25s;"
                 onmouseover="this.style.background='rgba(255,255,255,.2)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(255,255,255,.12)';this.style.transform='translateY(0)'">
                <span class="material-symbols-outlined" style="font-size:18px;">chat</span>
                WhatsApp
              </a>
            </div>

            <!-- Stats rápidas con acento de paleta -->
            <div class="flex flex-wrap gap-3 pt-2" style="animation:vn-slide-up .7s ease both .5s;">
              <?php foreach ([['100%','Productos naturales'],['Cali','Colombia'],['WhatsApp','Asesoría gratis']] as $stat): ?>
              <div class="vn-stat-card">
                <span style="font-size:16px;font-weight:800;color:<?= $pal['accent'] ?>;display:block;line-height:1;"><?= $stat[0] ?></span>
                <span style="font-size:10px;color:rgba(255,255,255,.55);text-transform:uppercase;letter-spacing:.06em;"><?= $stat[1] ?></span>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- Controles del carrusel -->
      <?php if (count($banners) > 1): ?>
      <!-- Flechas -->
      <button onclick="vnHeroPrev()" aria-label="Anterior"
              style="position:absolute;left:16px;top:50%;transform:translateY(-50%);z-index:20;width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.12);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.2);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s;"
              onmouseover="this.style.background='rgba(23,107,75,.7)'" onmouseout="this.style.background='rgba(255,255,255,.12)'">
        <span class="material-symbols-outlined" style="font-size:22px;">chevron_left</span>
      </button>
      <button onclick="vnHeroNext()" aria-label="Siguiente"
              style="position:absolute;right:16px;top:50%;transform:translateY(-50%);z-index:20;width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.12);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.2);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s;"
              onmouseover="this.style.background='rgba(23,107,75,.7)'" onmouseout="this.style.background='rgba(255,255,255,.12)'">
        <span class="material-symbols-outlined" style="font-size:22px;">chevron_right</span>
      </button>
      <?php endif; ?>

      <!-- Dots de paginación -->
      <div style="position:absolute;bottom:20px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:20;">
        <?php foreach ($banners as $i => $b): ?>
        <button class="vn-dot <?= $i===0?'active':'' ?>" onclick="vnHeroGoTo(<?= $i ?>)" aria-label="Slide <?= $i+1 ?>"></button>
        <?php endforeach; ?>
      </div>

      <!-- Indicador scroll -->
      <div style="position:absolute;bottom:20px;right:24px;z-index:20;display:flex;flex-direction:column;align-items:center;gap:4px;opacity:.5;">
        <span style="font-size:9px;color:rgba(255,255,255,.6);text-transform:uppercase;letter-spacing:.1em;">scroll</span>
        <div style="width:1px;height:28px;background:rgba(255,255,255,.3);overflow:hidden;">
          <div style="width:100%;height:50%;background:#88d6af;animation:vn-scroll 1.6s ease-in-out infinite;"></div>
        </div>
      </div>

    </div><!-- fin vnHero -->
  </div>
</section>

<script>
(function(){
  var slides = document.querySelectorAll('#vnHero .vn-hero-slide');
  var dots   = document.querySelectorAll('#vnHero .vn-dot');
  var cur    = 0;
  var timer;

  function goTo(n) {
    slides[cur].classList.remove('active');
    dots[cur] && dots[cur].classList.remove('active');
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add('active');
    dots[cur] && dots[cur].classList.add('active');
    clearInterval(timer);
    timer = setInterval(function(){ goTo(cur+1); }, 6000);
  }

  window.vnHeroNext = function(){ goTo(cur+1); };
  window.vnHeroPrev = function(){ goTo(cur-1); };
  window.vnHeroGoTo = function(n){ goTo(n); };

  if (slides.length > 1) {
    timer = setInterval(function(){ goTo(cur+1); }, 6000);
  }
})();
</script>

<!-- Beneficios -->
<style>
.vn-benefit-strip {
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:0;
  background:#00291e;
  border-radius:20px;
  overflow:hidden;
  box-shadow:0 8px 40px -8px rgba(0,41,30,.5);
  position:relative;
}
@media(max-width:900px){
  .vn-benefit-strip { grid-template-columns:repeat(2,1fr); }
}
@media(max-width:520px){
  .vn-benefit-strip { grid-template-columns:1fr; }
}
.vn-benefit-item {
  position:relative;
  padding:28px 24px 26px;
  display:flex;
  flex-direction:column;
  gap:12px;
  overflow:hidden;
  transition:background .3s;
  cursor:default;
}
.vn-benefit-item::after {
  content:'';
  position:absolute;
  right:0; top:16px; bottom:16px;
  width:1px;
  background:rgba(255,255,255,.07);
}
.vn-benefit-item:last-child::after { display:none; }
@media(max-width:900px){
  .vn-benefit-item:nth-child(2)::after { display:none; }
}
.vn-benefit-item:hover { background:rgba(255,255,255,.04); }
.vn-benefit-item:hover .vn-benefit-glow { opacity:1; }
.vn-benefit-glow {
  position:absolute;
  inset:0;
  opacity:0;
  transition:opacity .4s;
  pointer-events:none;
}
.vn-benefit-icon-wrap {
  width:48px; height:48px;
  border-radius:14px;
  display:flex; align-items:center; justify-content:center;
  position:relative;
  flex-shrink:0;
}
.vn-benefit-num {
  position:absolute;
  top:50%; right:24px;
  transform:translateY(-50%);
  font-size:72px;
  font-weight:900;
  color:rgba(255,255,255,.03);
  line-height:1;
  pointer-events:none;
  user-select:none;
  font-family:'Plus Jakarta Sans',sans-serif;
}
</style>
<section class="w-full px-4 lg:px-10 pb-8">
  <div class="max-w-7xl mx-auto">
    <div class="vn-benefit-strip">

      <!-- 1. WhatsApp -->
      <div class="vn-benefit-item">
        <div class="vn-benefit-glow" style="background:radial-gradient(ellipse at 10% 50%,rgba(37,163,90,.18) 0%,transparent 70%);"></div>
        <span class="vn-benefit-num">01</span>
        <div class="vn-benefit-icon-wrap" style="background:rgba(37,163,90,.15);">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M20.52 3.48A11.93 11.93 0 0 0 12 0C5.37 0 0 5.37 0 12c0 2.11.55 4.16 1.6 5.97L0 24l6.19-1.62A11.94 11.94 0 0 0 12 24c6.63 0 12-5.37 12-12 0-3.2-1.25-6.21-3.48-8.52ZM12 22c-1.85 0-3.66-.5-5.24-1.44l-.37-.22-3.86 1.01 1.03-3.76-.24-.38A9.94 9.94 0 0 1 2 12C2 6.48 6.48 2 12 2c2.67 0 5.18 1.04 7.07 2.93A9.95 9.95 0 0 1 22 12c0 5.52-4.48 10-10 10Zm5.44-7.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15s-.77.97-.94 1.17c-.17.2-.34.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.34.45-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.6-.91-2.19-.24-.58-.48-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.03 1.01-1.03 2.46s1.06 2.85 1.2 3.05c.15.2 2.07 3.17 5.02 4.44.7.3 1.25.48 1.68.62.7.22 1.34.19 1.85.12.56-.08 1.76-.72 2.01-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.19-.57-.34Z" fill="#25D366"/>
          </svg>
        </div>
        <div>
          <div style="font-size:11px;font-weight:700;color:#25D366;text-transform:uppercase;letter-spacing:.1em;margin-bottom:5px;">Pedido directo</div>
          <div style="font-size:15px;font-weight:700;color:#fff;line-height:1.3;margin-bottom:6px;">Pedidos por WhatsApp</div>
          <div style="font-size:12px;color:rgba(255,255,255,.5);line-height:1.6;">Asesoría inmediata, cotización clara y sin trámites engorrosos.</div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
          <span style="width:6px;height:6px;border-radius:50%;background:#25D366;animation:pulse 2s infinite;display:inline-block;"></span>
          <span style="font-size:11px;color:#25D366;font-weight:600;">En línea ahora</span>
        </div>
      </div>

      <!-- 2. INVIMA -->
      <div class="vn-benefit-item">
        <div class="vn-benefit-glow" style="background:radial-gradient(ellipse at 10% 50%,rgba(164,243,202,.12) 0%,transparent 70%);"></div>
        <span class="vn-benefit-num">02</span>
        <div class="vn-benefit-icon-wrap" style="background:rgba(164,243,202,.12);">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M12 1L3 5v6c0 5.25 3.84 10.17 9 11.38C17.16 21.17 21 16.25 21 11V5l-9-4Z" fill="none" stroke="#a4f3ca" stroke-width="1.6" stroke-linejoin="round"/>
            <path d="m8 12 2.5 2.5L16 9" stroke="#a4f3ca" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <div>
          <div style="font-size:11px;font-weight:700;color:#a4f3ca;text-transform:uppercase;letter-spacing:.1em;margin-bottom:5px;">Certificado</div>
          <div style="font-size:15px;font-weight:700;color:#fff;line-height:1.3;margin-bottom:6px;">100% Extractos Puros</div>
          <div style="font-size:12px;color:rgba(255,255,255,.5);line-height:1.6;">Fórmulas registradas y avaladas por normativa sanitaria INVIMA.</div>
        </div>
        <div style="display:inline-flex;align-items:center;gap:5px;background:rgba(164,243,202,.1);border:1px solid rgba(164,243,202,.2);padding:3px 10px;border-radius:999px;width:fit-content;margin-top:4px;">
          <span style="font-size:11px;color:#a4f3ca;font-weight:700;letter-spacing:.04em;">REG. INVIMA VIGENTE</span>
        </div>
      </div>

      <!-- 3. Asesoría -->
      <div class="vn-benefit-item">
        <div class="vn-benefit-glow" style="background:radial-gradient(ellipse at 10% 50%,rgba(136,214,175,.12) 0%,transparent 70%);"></div>
        <span class="vn-benefit-num">03</span>
        <div class="vn-benefit-icon-wrap" style="background:rgba(136,214,175,.12);">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h1v3l3-3h12a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2Z" stroke="#88d6af" stroke-width="1.6" stroke-linejoin="round"/>
            <circle cx="8" cy="12" r="1" fill="#88d6af"/>
            <circle cx="12" cy="12" r="1" fill="#88d6af"/>
            <circle cx="16" cy="12" r="1" fill="#88d6af"/>
          </svg>
        </div>
        <div>
          <div style="font-size:11px;font-weight:700;color:#88d6af;text-transform:uppercase;letter-spacing:.1em;margin-bottom:5px;">Especialistas</div>
          <div style="font-size:15px;font-weight:700;color:#fff;line-height:1.3;margin-bottom:6px;">Asesoría Natural</div>
          <div style="font-size:12px;color:rgba(255,255,255,.5);line-height:1.6;">Terapeutas naturistas te acompañan para cada necesidad de salud.</div>
        </div>
        <a href="https://wa.me/<?= $waNumber ?>" target="_blank"
           style="display:inline-flex;align-items:center;gap:5px;color:#88d6af;font-size:11px;font-weight:700;text-decoration:none;margin-top:4px;letter-spacing:.04em;transition:opacity .2s;"
           onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'">
          Consultar gratis
          <span class="material-symbols-outlined" style="font-size:14px;">arrow_forward</span>
        </a>
      </div>

      <!-- 4. Cobertura -->
      <div class="vn-benefit-item">
        <div class="vn-benefit-glow" style="background:radial-gradient(ellipse at 10% 50%,rgba(255,221,175,.1) 0%,transparent 70%);"></div>
        <span class="vn-benefit-num">04</span>
        <div class="vn-benefit-icon-wrap" style="background:rgba(255,221,175,.1);">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <rect x="1" y="8" width="22" height="13" rx="2" stroke="#ffddaf" stroke-width="1.6"/>
            <path d="M16 8V6a4 4 0 0 0-8 0v2" stroke="#ffddaf" stroke-width="1.6" stroke-linecap="round"/>
            <path d="M8 14h8M8 17h5" stroke="#ffddaf" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </div>
        <div>
          <div style="font-size:11px;font-weight:700;color:#ffddaf;text-transform:uppercase;letter-spacing:.1em;margin-bottom:5px;">Todo Colombia</div>
          <div style="font-size:15px;font-weight:700;color:#fff;line-height:1.3;margin-bottom:6px;">Cobertura Nacional</div>
          <div style="font-size:12px;color:rgba(255,255,255,.5);line-height:1.6;">Envíos a todo el país. Pago contra entrega o transferencia bancaria.</div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px;">
          <span style="font-size:10px;font-weight:600;color:rgba(255,221,175,.7);background:rgba(255,221,175,.08);padding:2px 8px;border-radius:999px;">Cali</span>
          <span style="font-size:10px;font-weight:600;color:rgba(255,221,175,.7);background:rgba(255,221,175,.08);padding:2px 8px;border-radius:999px;">Bogotá</span>
          <span style="font-size:10px;font-weight:600;color:rgba(255,221,175,.7);background:rgba(255,221,175,.08);padding:2px 8px;border-radius:999px;">Medellín</span>
          <span style="font-size:10px;font-weight:600;color:rgba(255,221,175,.7);background:rgba(255,221,175,.08);padding:2px 8px;border-radius:999px;">+más</span>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- Categorías -->
<style>
/* Paleta única por categoría */
.vn-cat-jarabes    { --cc1:#003320; --cc2:#005a38; --cc3:#007a4d; --ca:#a4f3ca; }
.vn-cat-suplementos{ --cc1:#1a1a4e; --cc2:#2d2d80; --cc3:#4040b0; --ca:#c0c8ff; }
.vn-cat-purgantes  { --cc1:#3d1a00; --cc2:#6b3200; --cc3:#9a4800; --ca:#ffd5a8; }
.vn-cat-default    { --cc1:#001a12; --cc2:#003020; --cc3:#004d32; --ca:#a4f3ca; }

.vn-cat-card {
  position:relative; border-radius:24px; overflow:hidden;
  background:linear-gradient(145deg, var(--cc1) 0%, var(--cc2) 50%, var(--cc3) 100%);
  min-height:280px; display:flex; flex-direction:column; justify-content:flex-end;
  text-decoration:none; transition:transform .35s cubic-bezier(.34,1.56,.64,1), box-shadow .35s;
  box-shadow:0 8px 32px -4px rgba(0,0,0,.35);
}
.vn-cat-card:hover { transform:translateY(-6px) scale(1.015); box-shadow:0 20px 48px -8px rgba(0,0,0,.45); }
.vn-cat-card:hover .vn-cat-shine { opacity:1; }
.vn-cat-card:hover .vn-cat-arrow { transform:translateX(4px); }
.vn-cat-card:hover .vn-cat-orb1 { transform:scale(1.15) translate(-4px,4px); }
.vn-cat-card:hover .vn-cat-orb2 { transform:scale(1.1) translate(4px,-4px); }

.vn-cat-shine {
  position:absolute;inset:0;opacity:0;transition:opacity .4s;
  background:linear-gradient(135deg,rgba(255,255,255,.08) 0%,transparent 50%);
  pointer-events:none;
}
.vn-cat-orb1,.vn-cat-orb2 {
  position:absolute; border-radius:50%; transition:transform .5s cubic-bezier(.34,1.56,.64,1);
  pointer-events:none;
}
.vn-cat-orb1 { width:220px;height:220px;top:-60px;right:-60px; background:radial-gradient(circle, rgba(255,255,255,.12) 0%,transparent 70%); }
.vn-cat-orb2 { width:160px;height:160px;bottom:-40px;left:20px; background:radial-gradient(circle, rgba(255,255,255,.07) 0%,transparent 70%); }

.vn-cat-content { position:relative;z-index:10; padding:24px; }
.vn-cat-pill {
  display:inline-flex;align-items:center;gap:6px;
  background:rgba(255,255,255,.12);backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.18); border-radius:999px;
  padding:5px 12px; margin-bottom:12px;
}
.vn-cat-pill span { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.08em; color:var(--ca); }
.vn-cat-title { font-size:22px; font-weight:900; color:#fff; line-height:1.1; margin-bottom:8px; }
.vn-cat-desc  { font-size:12px; color:rgba(255,255,255,.65); line-height:1.5; margin-bottom:16px; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
.vn-cat-footer { display:flex; align-items:center; justify-content:space-between; }
.vn-cat-count { font-size:12px; font-weight:700; color:var(--ca); background:rgba(255,255,255,.1); padding:4px 12px; border-radius:999px; }
.vn-cat-arrow-btn { display:flex;align-items:center;gap:6px;background:var(--ca);color:var(--cc1);font-size:12px;font-weight:800;padding:8px 16px;border-radius:999px;transition:all .2s; }
.vn-cat-arrow { transition:transform .2s; font-size:16px; }

/* SVG ilustraciones por categoría */
.vn-cat-illustration { position:absolute; top:0; right:0; width:180px; height:180px; opacity:.18; pointer-events:none; }
</style>

<section class="w-full px-4 lg:px-10 pb-10" id="categorias">
  <div class="max-w-7xl mx-auto flex flex-col gap-6">
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-2">
      <div>
        <span class="text-xs text-secondary uppercase tracking-widest font-semibold">Nuestra Tienda Especializada</span>
        <h2 class="text-2xl font-bold text-primary mt-1">Categorías Principales</h2>
        <p class="text-sm text-on-surface-variant mt-1">Fórmulas colombianas certificadas para cada necesidad de salud.</p>
      </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
      <?php
      // Ilustraciones SVG únicas por slug de categoría
      $catSVGs = [
        'jarabes' => '<svg viewBox="0 0 200 200" fill="none"><path d="M60 170 C60 170 40 140 40 110 C40 70 55 50 70 40 L80 150z" fill="white"/><path d="M100 170 C100 170 80 130 85 100 C90 70 110 50 125 45 L118 160z" fill="white" opacity=".6"/><circle cx="150" cy="60" r="30" fill="white" opacity=".3"/><path d="M30 100 Q60 80 90 95 Q120 110 150 90" stroke="white" stroke-width="3" fill="none" opacity=".4"/><circle cx="55" cy="120" r="8" fill="white" opacity=".5"/><circle cx="130" cy="140" r="5" fill="white" opacity=".4"/><path d="M155 100 Q160 85 170 90 Q180 95 175 108" stroke="white" stroke-width="2" fill="none" opacity=".5"/></svg>',
        'suplementos' => '<svg viewBox="0 0 200 200" fill="none"><circle cx="100" cy="80" r="45" fill="white" opacity=".15"/><ellipse cx="100" cy="80" rx="22" ry="38" fill="white" opacity=".25"/><path d="M80 60 L120 60 L115 100 L85 100z" fill="white" opacity=".3"/><circle cx="68" cy="130" r="18" fill="white" opacity=".2"/><circle cx="135" cy="120" r="12" fill="white" opacity=".15"/><path d="M45 150 Q75 135 100 145 Q125 155 155 140" stroke="white" stroke-width="2.5" fill="none" opacity=".3"/><rect x="85" y="55" width="30" height="8" rx="4" fill="white" opacity=".4"/></svg>',
        'purgantes' => '<svg viewBox="0 0 200 200" fill="none"><path d="M100 20 C100 20 60 60 55 100 C50 140 70 170 100 175 C130 170 150 140 145 100 C140 60 100 20 100 20z" fill="white" opacity=".2"/><path d="M100 40 C100 40 72 72 68 105 C65 130 78 155 100 160" stroke="white" stroke-width="2" fill="none" opacity=".4"/><circle cx="130" cy="80" r="20" fill="white" opacity=".12"/><circle cx="65" cy="140" r="12" fill="white" opacity=".15"/><path d="M120 130 Q140 120 150 135 Q155 148 142 155" stroke="white" stroke-width="2.5" fill="none" opacity=".35"/><circle cx="100" cy="100" r="8" fill="white" opacity=".3"/></svg>',
      ];
      $catColors = [
        'jarabes'     => 'vn-cat-jarabes',
        'suplementos' => 'vn-cat-suplementos',
        'purgantes'   => 'vn-cat-purgantes',
      ];
      $catEmojis = ['jarabes'=>'🌿','suplementos'=>'💊','purgantes'=>'🍃'];

      foreach ($categorias as $cat):
        $stC=$db->prepare("SELECT COUNT(*) FROM productos WHERE categoria_id=? AND activo=1");
        $stC->execute([$cat['id']]); $cnt=$stC->fetchColumn();
        $slug = $cat['slug'];
        $colorClass = $catColors[$slug] ?? 'vn-cat-default';
        $svgIlust   = $catSVGs[$slug] ?? $catSVGs['jarabes'];
      ?>
      <a href="index.php?page=categoria&cat=<?= h($slug) ?>"
         class="vn-cat-card <?= $colorClass ?>">

        <!-- Orbes decorativos de fondo -->
        <div class="vn-cat-orb1"></div>
        <div class="vn-cat-orb2"></div>

        <!-- Brillo hover -->
        <div class="vn-cat-shine"></div>

        <!-- Ilustración SVG de fondo -->
        <div class="vn-cat-illustration"><?= $svgIlust ?></div>

        <!-- Imagen de fondo si tiene (desde admin) -->
        <?php if (!empty($cat['imagen_url'])): ?>
        <div style="position:absolute;inset:0;background-image:url('<?= h($cat['imagen_url']) ?>');background-size:cover;background-position:center;opacity:.35;"></div>
        <div style="position:absolute;inset:0;background:linear-gradient(to top, var(--cc1) 30%, transparent 100%);"></div>
        <?php endif; ?>

        <!-- Contenido -->
        <div class="vn-cat-content">
          <h3 class="vn-cat-title"><?= h($cat['nombre']) ?></h3>
          <p class="vn-cat-desc"><?= h($cat['descripcion']) ?></p>
          <div class="vn-cat-footer">
            <span class="vn-cat-count"><?= $cnt ?> productos</span>
            <div class="vn-cat-arrow-btn">
              Ver todo
              <span class="material-symbols-outlined vn-cat-arrow">arrow_forward</span>
            </div>
          </div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Productos destacados -->
<section id="catalogo" class="w-full px-4 lg:px-10 pb-12">
  <div class="max-w-7xl mx-auto flex flex-col gap-6">
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-4">
      <div>
        <span class="text-xs text-secondary uppercase tracking-widest font-semibold">Selección de la Tienda</span>
        <h2 class="text-2xl font-bold text-primary mt-1">Fórmulas Más Recomendadas</h2>
      </div>
      <div class="flex items-center gap-2 overflow-x-auto pb-1">
        <a href="index.php" class="px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors <?= $page==='inicio'?'bg-primary text-white shadow-sm':'bg-surface-container-lowest text-primary hover:bg-surface-container border border-outline-variant' ?>">Todos</a>
        <?php foreach ($categorias as $cat): ?>
        <a href="index.php?page=categoria&cat=<?= h($cat['slug']) ?>"
           class="px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap bg-surface-container-lowest text-primary hover:bg-surface-container border border-outline-variant transition-colors">
          <?= h(explode(' ',$cat['nombre'])[0]) ?>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
      <?php foreach ($destacados as $prod): echo renderProductCard($prod,$waNumber,true); endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA WhatsApp -->
<section class="w-full px-4 lg:px-10 pb-12">
  <div class="max-w-7xl mx-auto">
    <div class="bg-primary rounded-2xl p-8 lg:p-12 flex flex-col lg:flex-row items-center justify-between gap-6">
      <div class="text-center lg:text-left">
        <h3 class="text-2xl font-bold text-on-primary">¿No sabes qué producto necesitas?</h3>
        <p style="color:rgba(255,255,255,.75);margin-top:8px;max-width:460px;">Nuestros terapeutas naturistas te orientan gratis por WhatsApp. Descríbenos tu necesidad y te recomendamos lo mejor.</p>
      </div>
      <a href="https://wa.me/<?= $waNumber ?>" target="_blank"
         class="shrink-0 inline-flex items-center gap-3 bg-[#25A35A] hover:bg-[#1f8c4c] text-white font-bold text-base px-8 py-4 rounded-full transition-all shadow-lg">
        <span class="material-symbols-outlined text-[22px]">chat</span>
        Consultar por WhatsApp
      </a>
    </div>
  </div>
</section>

<?php elseif ($page==='categoria' && $categoriaActual): ?>
<!-- ───── CATEGORÍA ───── -->
<?php
// Paleta por slug de categoría
$catPaletas = [
  'jarabes'     => ['from'=>'#001a10','to'=>'#005a38','accent'=>'#a4f3ca','ring'=>'rgba(164,243,202,.2)','ambient'=>'rgba(0,122,77,.35)'],
  'suplementos' => ['from'=>'#0a0a2e','to'=>'#2d2d80','accent'=>'#c0c8ff','ring'=>'rgba(192,200,255,.2)','ambient'=>'rgba(64,64,176,.35)'],
  'purgantes'   => ['from'=>'#1a0a00','to'=>'#6b3200','accent'=>'#ffd5a8','ring'=>'rgba(255,213,168,.2)','ambient'=>'rgba(154,72,0,.35)'],
];
$cSlug = $categoriaActual['slug'] ?? '';
$cPal  = $catPaletas['jarabes'];
foreach(array_keys($catPaletas) as $k){ if(str_contains(strtolower($cSlug),$k)){ $cPal=$catPaletas[$k]; break; } }
?>

<!-- Hero banner de categoría -->
<section class="w-full px-4 lg:px-10 py-6">
<div class="max-w-7xl mx-auto">
<div style="
  position:relative; border-radius:16px; overflow:hidden;
  padding:44px 40px 40px;
  background:linear-gradient(135deg,<?= $cPal['from'] ?> 0%,<?= $cPal['to'] ?> 100%);
  box-sizing:border-box; display:flex; align-items:center; justify-content:space-between;
  min-height:220px;
  box-shadow:0 8px 40px -8px rgba(0,0,0,.35);
">
  <?php if (!empty($categoriaActual['imagen_banner'])): ?>
  <!-- Imagen de fondo del banner -->
  <div style="position:absolute;inset:0;z-index:0;">
    <img src="<?= h($categoriaActual['imagen_banner']) ?>" alt=""
      style="width:100%;height:100%;object-fit:cover;display:block;">
    <div style="position:absolute;inset:0;background:linear-gradient(135deg,<?= $cPal['from'] ?>e6 0%,<?= $cPal['to'] ?>b3 100%);"></div>
  </div>
  <?php else: ?>
  <!-- Glow ambiental -->
  <div style="position:absolute;inset:0;z-index:0;pointer-events:none;background:radial-gradient(ellipse at 75% 40%,<?= $cPal['ambient'] ?> 0%,transparent 65%);"></div>
  <!-- Patrón de puntos sutil -->
  <div style="position:absolute;inset:0;z-index:0;background-image:radial-gradient(circle,rgba(255,255,255,.055) 1px,transparent 1px);background-size:22px 22px;"></div>
  <?php endif; ?>
  <!-- Líneas diagonales decorativas -->
  <div style="position:absolute;inset:0;z-index:0;opacity:.04;background:repeating-linear-gradient(45deg,#fff 0,#fff 1px,transparent 0,transparent 50%);background-size:24px 24px;"></div>
  <!-- Anillos decorativos grandes -->
  <div style="position:absolute;border-radius:50%;z-index:0;border:1.5px solid <?= $cPal['ring'] ?>;width:380px;height:380px;top:-120px;right:-100px;opacity:.35;"></div>
  <div style="position:absolute;border-radius:50%;z-index:0;border:1px solid <?= $cPal['ring'] ?>;width:220px;height:220px;top:-40px;right:-40px;opacity:.5;"></div>
  <div style="position:absolute;border-radius:50%;z-index:0;border:1px solid <?= $cPal['ring'] ?>;width:120px;height:120px;bottom:-30px;right:160px;opacity:.3;"></div>

  <!-- Contenido texto izquierda -->
  <div style="position:relative;z-index:2;display:flex;flex-direction:column;gap:0;max-width:580px;">
    <!-- Breadcrumb -->
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:14px;">
      <a href="index.php" style="font-size:12px;color:rgba(255,255,255,.4);text-decoration:none;font-weight:500;transition:color .2s;" onmouseover="this.style.color='rgba(255,255,255,.75)'" onmouseout="this.style.color='rgba(255,255,255,.4)'">Inicio</a>
      <span style="color:rgba(255,255,255,.2);font-size:11px;">›</span>
      <span style="font-size:12px;color:<?= $cPal['accent'] ?>;font-weight:700;letter-spacing:.02em;"><?= h($categoriaActual['nombre']) ?></span>
    </div>
    <!-- Badge icono + etiqueta -->
    <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:5px 14px 5px 8px;width:fit-content;margin-bottom:16px;">
      <div style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:16px;color:<?= $cPal['accent'] ?>;"><?= h($categoriaActual['icono']??'eco') ?></span>
      </div>
      <span style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:<?= $cPal['accent'] ?>;">Categoría</span>
    </div>
    <!-- Título grande -->
    <h1 style="font-size:clamp(28px,5vw,52px);font-weight:900;color:#fff;line-height:1;letter-spacing:-.03em;margin:0 0 12px;">
      <?= h($categoriaActual['nombre']) ?>
    </h1>
    <!-- Descripción -->
    <p style="font-size:14px;color:rgba(255,255,255,.58);line-height:1.65;max-width:460px;margin:0 0 20px;">
      <?= h($categoriaActual['descripcion']) ?>
    </p>
    <!-- Pills info -->
    <div style="display:flex;align-items:center;flex-wrap:wrap;gap:8px;">
      <div style="display:inline-flex;align-items:center;gap:5px;background:rgba(255,255,255,.1);border:1px solid <?= $cPal['ring'] ?>;border-radius:999px;padding:5px 13px;">
        <span class="material-symbols-outlined" style="font-size:13px;color:<?= $cPal['accent'] ?>;">inventory_2</span>
        <span style="font-size:12px;font-weight:700;color:#fff;"><?= count($productosCat) ?> productos</span>
      </div>
    </div>
  </div>

  <!-- Ilustración decorativa derecha -->
  <div style="position:relative;z-index:2;flex-shrink:0;display:none;" class="lg:block">
    <div style="width:180px;height:180px;position:relative;">
      <!-- Círculo de fondo -->
      <div style="position:absolute;inset:0;border-radius:50%;background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.12);"></div>
      <!-- Icono grande central -->
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:80px;color:<?= $cPal['accent'] ?>;opacity:.7;"><?= h($categoriaActual['icono']??'eco') ?></span>
      </div>
      <!-- Orbe satélite 1 -->
      <div style="position:absolute;top:-10px;right:-10px;width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:22px;color:rgba(255,255,255,.7);">spa</span>
      </div>
      <!-- Orbe satélite 2 -->
      <div style="position:absolute;bottom:-10px;left:-10px;width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:18px;color:rgba(255,255,255,.6);">science</span>
      </div>
    </div>
  </div>
</div>
</div>
</section>

<!-- Grid de productos -->
<section class="w-full px-4 lg:px-10 pt-8 pb-12">
  <div class="max-w-7xl mx-auto">
    <?php if (empty($productosCat)): ?>
    <div style="text-align:center;padding:80px 20px;">
      <div style="width:80px;height:80px;border-radius:24px;background:rgba(0,41,30,.08);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
        <span class="material-symbols-outlined" style="font-size:40px;color:#b0bdb8;">inventory_2</span>
      </div>
      <p style="font-size:16px;font-weight:600;color:#414845;">No hay productos en esta categoría aún</p>
      <a href="index.php" style="display:inline-block;margin-top:16px;background:#176b4b;color:#fff;padding:10px 24px;border-radius:999px;font-size:14px;font-weight:600;text-decoration:none;">Ver todos los productos</a>
    </div>
    <?php else: ?>
    <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
      <?php foreach ($productosCat as $prod): echo renderProductCard($prod,$waNumber); endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page==='producto' && $producto): ?>
<!-- ───── DETALLE DE PRODUCTO ───── -->
<section class="w-full px-4 lg:px-10 py-6">
  <div class="max-w-7xl mx-auto">
    <nav class="flex items-center gap-2 text-sm text-on-surface-variant mb-6 flex-wrap">
      <a href="index.php" class="hover:text-secondary">Inicio</a>
      <span class="material-symbols-outlined text-[14px] text-outline-variant">chevron_right</span>
      <?php if ($producto['cat_slug']): ?>
      <a href="index.php?page=categoria&cat=<?= h($producto['cat_slug']) ?>" class="hover:text-secondary"><?= h($producto['cat_nombre']) ?></a>
      <span class="material-symbols-outlined text-[14px] text-outline-variant">chevron_right</span>
      <?php endif; ?>
      <span class="text-primary font-semibold"><?= h($producto['nombre']) ?></span>
    </nav>
    <div class="inline-flex items-center gap-2 px-3 py-1 bg-surface-container rounded-full text-secondary text-xs font-medium mb-6">
      <span class="w-2 h-2 rounded-full <?= $producto['stock']>0?'bg-secondary animate-pulse':'bg-error' ?>"></span>
      <?php if ($producto['stock']>10): ?>Stock disponible: <?= (int)$producto['stock'] ?> unidades
      <?php elseif ($producto['stock']>0): ?>¡Últimas <?= (int)$producto['stock'] ?> unidades!
      <?php else: ?>Producto temporalmente agotado<?php endif; ?>
    </div>
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      <!-- Galería -->
      <div class="lg:col-span-7 flex flex-col md:flex-row gap-4">
        <div class="flex md:flex-col gap-3 order-2 md:order-1 overflow-x-auto md:overflow-visible">
          <?php
          $imgs=array_filter([$producto['imagen_principal'],$producto['imagen2'],$producto['imagen3'],$producto['imagen4']]);
          if(empty($imgs)) $imgs=[''];
          foreach($imgs as $i=>$imgUrl): ?>
          <button onclick="changeProductImage('<?= h($imgUrl) ?>')"
                  class="thumb-btn w-20 h-20 rounded-xl bg-surface-container-lowest p-1.5 shadow-sm border-2 <?= $i===0?'border-secondary':'border-outline-variant hover:border-secondary' ?> flex-shrink-0 overflow-hidden transition-all">
            <?php if($imgUrl): ?>
            <img src="<?= h($imgUrl) ?>" alt="" class="w-full h-full object-cover rounded-lg">
            <?php else: ?>
            <div class="w-full h-full bg-secondary-container rounded-lg flex items-center justify-center">
              <span class="material-symbols-outlined text-secondary text-[24px]">eco</span>
            </div>
            <?php endif; ?>
          </button>
          <?php endforeach; ?>
        </div>
        <!-- Imagen principal — altura fija para consistencia -->
        <div class="relative order-1 md:order-2 flex-1 bg-surface-container-lowest rounded-2xl shadow-sm overflow-hidden flex flex-col items-center justify-center" style="min-height:420px;max-height:480px;">
          <div class="absolute top-4 left-4 flex flex-col gap-2 z-10">
            <?php if($producto['destacado']): ?>
            <span class="inline-flex items-center gap-1 px-3 py-1 bg-tertiary-fixed text-tertiary-container text-xs font-bold rounded-full shadow-sm">
              <span class="material-symbols-outlined text-[14px]" style="font-variation-settings:'FILL' 1">star</span> Destacado
            </span>
            <?php endif; ?>
            <?php if($producto['precio_antes']): ?>
            <span class="inline-flex items-center gap-1 px-3 py-1 bg-secondary-fixed text-on-secondary-fixed-variant text-xs font-bold rounded-full">
              -<?= round((1-$producto['precio']/$producto['precio_antes'])*100) ?>% descuento
            </span>
            <?php endif; ?>
          </div>
          <?php if($producto['imagen_principal']): ?>
          <img id="mainProductImg" src="<?= h($producto['imagen_principal']) ?>" alt="<?= h($producto['nombre']) ?>"
               style="width:100%;height:420px;object-fit:contain;padding:16px;transition:transform .3s;" onmouseover="this.style.transform='scale(1.03)'" onmouseout="this.style.transform='scale(1)'">
          <?php else: ?>
          <div class="w-40 h-40 bg-secondary-container rounded-full flex items-center justify-center">
            <span class="material-symbols-outlined text-secondary text-[80px]">eco</span>
          </div>
          <?php endif; ?>
          <div class="absolute bottom-4 left-4 right-4 bg-surface-container-low/80 backdrop-blur-sm rounded-xl p-3 flex items-center justify-around text-xs text-on-surface-variant">
            <span class="flex items-center gap-1"><span class="material-symbols-outlined text-secondary text-[15px]">science</span>Sin colorantes</span>
            <span class="flex items-center gap-1"><span class="material-symbols-outlined text-secondary text-[15px]">local_florist</span>Extracto puro</span>
            <span class="flex items-center gap-1"><span class="material-symbols-outlined text-secondary text-[15px]">health_and_safety</span>Grado Farmacéutico</span>
          </div>
        </div>
      </div>
      <!-- Info producto -->
      <div class="lg:col-span-5 flex flex-col gap-5">
        <div class="flex items-center justify-between">
          <?php if($producto['cat_nombre']): ?>
          <span class="px-3 py-1 rounded-full bg-secondary-container text-on-secondary-container text-xs font-semibold uppercase tracking-wider"><?= h($producto['cat_nombre']) ?></span>
          <?php endif; ?>
          <div class="flex items-center gap-1 text-sm">
            <div class="flex text-tertiary-fixed-dim">
              <?php for($s=1;$s<=5;$s++): ?><span class="material-symbols-outlined text-[17px]" style="font-variation-settings:'FILL' 1">star</span><?php endfor; ?>
            </div>
            <strong class="ml-1"><?= number_format($producto['calificacion'],1) ?></strong>
            <span class="text-on-surface-variant">(<?= (int)$producto['num_resenas'] ?> reseñas)</span>
          </div>
        </div>
        <div>
          <h1 class="text-2xl font-bold text-primary"><?= h($producto['nombre']) ?></h1>
          <p class="text-sm text-on-surface-variant mt-1"><?= h($producto['presentacion']) ?></p>
        </div>
        <?php if($producto['invima']): ?>
        <div class="p-3 rounded-xl bg-surface-container-high/60 flex items-center gap-3">
          <span class="material-symbols-outlined text-secondary text-[22px]">verified</span>
          <div>
            <span class="text-[11px] text-on-surface-variant block uppercase tracking-wider">Registro Sanitario INVIMA</span>
            <span class="text-sm text-primary font-bold"><?= h($producto['invima']) ?> <span class="text-secondary font-normal">(Vigente)</span></span>
          </div>
        </div>
        <?php endif; ?>
        <p class="text-sm text-on-surface-variant leading-relaxed"><?= h($producto['descripcion']) ?></p>
        <div class="p-5 rounded-2xl bg-surface-container-lowest shadow-sm flex flex-col gap-4">
          <div>
            <span class="text-xs text-on-surface-variant block">Precio oficial</span>
            <div class="flex items-center gap-3">
              <span class="text-3xl font-bold text-primary"><?= formatPrice($producto['precio']) ?></span>
              <?php if($producto['precio_antes']): ?>
              <span class="text-sm text-on-surface-variant line-through"><?= formatPrice($producto['precio_antes']) ?></span>
              <?php endif; ?>
            </div>
          </div>
          <div class="flex items-center gap-4">
            <div class="flex items-center justify-between bg-surface-container-low rounded-full px-3 py-1.5 w-36">
              <button onclick="adjustQty(-1)" class="w-8 h-8 rounded-full bg-surface-container-lowest hover:bg-surface-container text-primary flex items-center justify-center font-bold text-lg shadow-sm">-</button>
              <span id="qtyDisplay" class="text-lg font-bold text-primary">1</span>
              <button onclick="adjustQty(1)" class="w-8 h-8 rounded-full bg-surface-container-lowest hover:bg-surface-container text-primary flex items-center justify-center font-bold text-lg shadow-sm">+</button>
            </div>
          </div>
          <div class="flex flex-col gap-3">
            <?php if($producto['stock']>0): ?>
            <button onclick="addToCart(<?= (int)$producto['id'] ?>,'<?= addslashes(h($producto['nombre'])) ?>',<?= (float)$producto['precio'] ?>,'<?= h($producto['imagen_principal']??'') ?>')"
                    class="flex items-center justify-center gap-2 w-full bg-secondary hover:bg-secondary/90 text-white font-semibold py-3.5 rounded-full transition-all shadow-md">
              <span class="material-symbols-outlined text-[20px]">add_shopping_cart</span>Añadir al Carrito
            </button>
            <a href="https://wa.me/<?= $waNumber ?>?text=<?= urlencode("Hola Verde Natural, quiero pedir 1 ".$producto['nombre']." (".formatPrice($producto['precio'])."). ¿Está disponible?") ?>" target="_blank"
               class="flex items-center justify-center gap-2 w-full bg-[#25A35A] hover:bg-[#1f8c4c] text-white font-semibold py-3.5 rounded-full transition-all shadow-md">
              <span class="material-symbols-outlined text-[20px]">chat</span>Pedir por WhatsApp
            </a>
            <?php else: ?>
            <button disabled class="w-full bg-surface-container text-on-surface-variant font-semibold py-3.5 rounded-full cursor-not-allowed">Producto agotado</button>
            <a href="https://wa.me/<?= $waNumber ?>?text=<?= urlencode("Hola, ¿cuándo tendrán disponible ".$producto['nombre']."?") ?>" target="_blank"
               class="flex items-center justify-center gap-2 w-full bg-[#25A35A] text-white font-semibold py-3 rounded-full">
              <span class="material-symbols-outlined text-[18px]">notifications</span>Avisar cuando esté disponible
            </a>
            <?php endif; ?>
          </div>
        </div>
        <?php if($producto['ingredientes']||$producto['modo_uso']): ?>
        <div class="flex flex-col gap-3">
          <?php if($producto['ingredientes']): ?>
          <details class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm">
            <summary class="flex items-center justify-between p-4 cursor-pointer text-primary font-semibold text-sm select-none hover:bg-surface-container-low">
              <span class="flex items-center gap-2"><span class="material-symbols-outlined text-[18px] text-secondary">science</span>Ingredientes</span>
              <span class="material-symbols-outlined text-[20px] text-outline">expand_more</span>
            </summary>
            <div class="px-4 pb-4 text-sm text-on-surface-variant leading-relaxed"><?= h($producto['ingredientes']) ?></div>
          </details>
          <?php endif; ?>
          <?php if($producto['modo_uso']): ?>
          <details class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm">
            <summary class="flex items-center justify-between p-4 cursor-pointer text-primary font-semibold text-sm select-none hover:bg-surface-container-low">
              <span class="flex items-center gap-2"><span class="material-symbols-outlined text-[18px] text-secondary">info</span>Modo de uso</span>
              <span class="material-symbols-outlined text-[20px] text-outline">expand_more</span>
            </summary>
            <div class="px-4 pb-4 text-sm text-on-surface-variant leading-relaxed"><?= h($producto['modo_uso']) ?></div>
          </details>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php
    $stRel=$db->prepare("SELECT p.*,c.nombre as cat_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id=c.id WHERE p.categoria_id=? AND p.id!=? AND p.activo=1 ORDER BY RAND() LIMIT 4");
    $stRel->execute([$producto['categoria_id'],$producto['id']]); $relacionados=$stRel->fetchAll();
    if(!empty($relacionados)): ?>
    <div class="mt-12">
      <h2 class="text-xl font-bold text-primary mb-6">También te puede interesar</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <?php foreach($relacionados as $prod): echo renderProductCard($prod,$waNumber); endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page==='buscar'): ?>
<!-- ───── BÚSQUEDA ───── -->
<!-- Hero búsqueda -->
<div style="margin:0 16px 28px;padding:36px 40px;border-radius:20px;background:linear-gradient(135deg,#001a10 0%,#003320 50%,#005a38 100%);position:relative;overflow:hidden;">
  <div style="position:absolute;inset:0;background-image:radial-gradient(circle,rgba(255,255,255,.05) 1px,transparent 1px);background-size:20px 20px;"></div>
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 90% 50%,rgba(0,122,77,.3) 0%,transparent 60%);"></div>
  <div class="relative">
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
      <a href="index.php" style="font-size:12px;color:rgba(255,255,255,.4);text-decoration:none;">Inicio</a>
      <span style="color:rgba(255,255,255,.25);">›</span>
      <span style="font-size:12px;color:#a4f3ca;font-weight:600;">Búsqueda</span>
    </div>
    <h1 style="font-size:clamp(20px,3.5vw,32px);font-weight:900;color:#fff;margin-bottom:6px;">
      <?= $busqueda ? 'Resultados para <span style="color:#a4f3ca;">"'.h($busqueda).'"</span>' : 'Búsqueda' ?>
    </h1>
    <p style="font-size:13px;color:rgba(255,255,255,.5);"><?= count($resultadosBusqueda) ?> producto(s) encontrado(s)</p>
    <!-- Barra de búsqueda -->
    <form method="GET" action="index.php" style="margin-top:18px;max-width:460px;">
      <input type="hidden" name="page" value="buscar">
      <div style="display:flex;align-items:center;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:4px 6px 4px 16px;gap:8px;">
        <span class="material-symbols-outlined" style="color:rgba(255,255,255,.5);font-size:20px;">search</span>
        <input name="q" type="text" value="<?= h($busqueda) ?>" style="flex:1;background:none;border:none;outline:none;color:#fff;font-size:14px;font-family:inherit;" placeholder="Buscar productos naturales...">
        <button type="submit" style="background:#176b4b;color:#fff;border:none;border-radius:999px;padding:8px 18px;font-size:13px;font-weight:600;cursor:pointer;">Buscar</button>
      </div>
    </form>
  </div>
</div>

<section class="w-full px-4 lg:px-10 pb-12">
  <div class="max-w-7xl mx-auto">
    <?php if(empty($resultadosBusqueda)): ?>
    <div style="text-align:center;padding:80px 20px;">
      <div style="width:80px;height:80px;border-radius:24px;background:rgba(0,41,30,.08);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
        <span class="material-symbols-outlined" style="font-size:40px;color:#b0bdb8;">search_off</span>
      </div>
      <p style="font-size:16px;font-weight:600;color:#414845;margin-bottom:6px;">Sin resultados</p>
      <p style="font-size:14px;color:#717975;margin-bottom:20px;">No encontramos productos con ese término. Intenta con otra palabra.</p>
      <a href="index.php" style="display:inline-block;background:#176b4b;color:#fff;padding:10px 24px;border-radius:999px;font-size:14px;font-weight:600;text-decoration:none;">Ver todos los productos</a>
    </div>
    <?php else: ?>
    <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-5">
      <?php foreach($resultadosBusqueda as $prod): echo renderProductCard($prod,$waNumber); endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page==='nosotros'): ?>
<!-- ───── SOBRE NOSOTROS ───── -->
<?php
  $nosotrosTexto = getConfig('nosotros_texto', 'Somos Verde Natural, una tienda de productos naturales y medicinales ubicada en Cali, Valle del Cauca, Colombia. Fundada por Diana Morales, nos dedicamos a ofrecer fórmulas botánicas certificadas con Registro INVIMA, elaboradas con plantas medicinales colombianas de alta calidad. Nuestro compromiso es brindar bienestar natural a cada familia colombiana, con asesoría personalizada y productos que respetan la tradición herbolaria de nuestra región.');
  $nosotrosTitulo = getConfig('nosotros_titulo', 'Nuestra Historia');
?>

<!-- Hero Nosotros -->
<section class="w-full px-4 lg:px-10 pt-6 pb-0">
<div class="max-w-7xl mx-auto">
<div style="border-radius:16px;overflow:hidden;position:relative;background:linear-gradient(135deg,#001a10 0%,#003320 45%,#005a38 100%);min-height:280px;display:flex;align-items:center;box-shadow:0 8px 40px -8px rgba(0,0,0,.35);">
  <div style="position:absolute;inset:0;background-image:radial-gradient(circle,rgba(255,255,255,.06) 1px,transparent 1px);background-size:22px 22px;"></div>
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 90% 50%,rgba(0,122,77,.4) 0%,transparent 55%),radial-gradient(ellipse at 10% 80%,rgba(164,243,202,.08) 0%,transparent 50%);"></div>
  <div style="position:absolute;inset:0;opacity:.04;background:repeating-linear-gradient(45deg,#fff 0,#fff 1px,transparent 0,transparent 50%);background-size:24px 24px;"></div>
  <div style="position:absolute;width:360px;height:360px;border-radius:50%;border:1px solid rgba(164,243,202,.1);top:-80px;right:-80px;"></div>
  <div style="position:absolute;width:220px;height:220px;border-radius:50%;border:1px solid rgba(164,243,202,.15);top:-20px;right:-20px;"></div>
  <div style="position:absolute;right:60px;top:50%;transform:translateY(-50%);opacity:.1;">
    <svg width="180" height="220" viewBox="0 0 80 96" fill="none">
      <path d="M40 88 C40 88 40 52 40 24" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
      <path d="M40 48 C30 42 16 36 14 22 C22 24 34 32 40 48Z" fill="white"/>
      <path d="M40 40 C50 34 64 28 66 14 C58 16 46 24 40 40Z" fill="white"/>
      <path d="M40 62 C33 58 24 54 22 44 C28 46 36 52 40 62Z" fill="white"/>
      <path d="M40 68 C47 64 56 58 58 48 C52 50 44 56 40 68Z" fill="white"/>
      <ellipse cx="40" cy="22" rx="6" ry="10" fill="white"/>
    </svg>
  </div>
  <div style="position:relative;z-index:2;padding:44px 40px;max-width:620px;">
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:14px;">
      <a href="index.php" style="font-size:12px;color:rgba(255,255,255,.4);text-decoration:none;font-weight:500;" onmouseover="this.style.color='rgba(255,255,255,.75)'" onmouseout="this.style.color='rgba(255,255,255,.4)'">Inicio</a>
      <span style="color:rgba(255,255,255,.2);font-size:11px;">›</span>
      <span style="font-size:12px;color:#a4f3ca;font-weight:700;">Sobre Nosotros</span>
    </div>
    <h1 style="font-size:clamp(28px,5vw,48px);font-weight:900;color:#fff;line-height:1.05;letter-spacing:-.025em;margin-bottom:14px;"><?= h($nosotrosTitulo) ?></h1>
    <p style="font-size:15px;color:rgba(255,255,255,.58);line-height:1.75;max-width:500px;margin-bottom:24px;"><?= strip_tags($nosotrosTexto) ?></p>
    <div style="display:flex;gap:12px;flex-wrap:wrap;">
      <a href="https://wa.me/<?= $waNumber ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;background:#176b4b;color:#fff;font-weight:700;font-size:14px;padding:12px 24px;border-radius:999px;text-decoration:none;box-shadow:0 6px 20px rgba(23,107,75,.45);">
        <span class="material-symbols-outlined" style="font-size:18px;">chat</span>Escríbenos por WhatsApp
      </a>
      <a href="index.php" style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);color:#fff;font-weight:600;font-size:14px;padding:12px 24px;border-radius:999px;text-decoration:none;">
        Ver productos
      </a>
    </div>
  </div>
</div>

<!-- Stats pegados abajo del hero -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);background:#00291e;border-radius:0 0 16px 16px;overflow:hidden;margin-top:-2px;">
  <?php foreach([
    ['100+','Clientes satisfechos'],
    ['3','Líneas de productos'],
    ['INVIMA','Registro sanitario'],
    ['Cali','Valle del Cauca'],
  ] as $s): ?>
  <div style="padding:22px 16px;text-align:center;border-right:1px solid rgba(255,255,255,.07);">
    <div style="font-size:22px;font-weight:900;color:#a4f3ca;line-height:1;"><?= $s[0] ?></div>
    <div style="font-size:11px;color:rgba(255,255,255,.45);margin-top:4px;line-height:1.3;"><?= $s[1] ?></div>
  </div>
  <?php endforeach; ?>
</div>
</div><!-- /max-w-7xl -->
</section><!-- /hero nosotros wrapper -->

<!-- Sección valores -->
<section style="padding:48px 24px 16px;max-width:960px;margin:0 auto;">
  <div style="text-align:center;margin-bottom:32px;">
    <span style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#176b4b;">Por qué elegirnos</span>
    <h2 style="font-size:clamp(22px,3.5vw,32px);font-weight:900;color:#00291e;margin-top:6px;letter-spacing:-.02em;">Nuestra promesa natural</h2>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:40px;">
    <?php foreach([
      ['verified','#176b4b','rgba(23,107,75,.08)','Certificación INVIMA','Todos nuestros productos cuentan con registro sanitario oficial del INVIMA Colombia.'],
      ['local_shipping','#1a5a9a','rgba(26,90,154,.08)','Envíos a todo Colombia','Despachamos desde Cali a cualquier ciudad del país de forma rápida y segura.'],
      ['support_agent','#7a3a00','rgba(122,58,0,.08)','Asesoría gratuita','Diana te asesora personalmente para encontrar el producto ideal para tu necesidad.'],
      ['science','#176b4b','rgba(23,107,75,.08)','Fórmulas artesanales','Elaboradas con plantas medicinales colombianas cultivadas y procesadas naturalmente.'],
    ] as $v): ?>
    <div style="background:#fff;border-radius:18px;padding:24px;box-shadow:0 2px 12px -2px rgba(0,41,30,.08);border:1px solid rgba(0,41,30,.05);">
      <div style="width:48px;height:48px;border-radius:14px;background:<?= $v[2] ?>;display:flex;align-items:center;justify-content:center;margin-bottom:14px;">
        <span class="material-symbols-outlined" style="color:<?= $v[1] ?>;font-size:24px;"><?= $v[0] ?></span>
      </div>
      <h3 style="font-size:15px;font-weight:700;color:#00291e;margin-bottom:6px;"><?= $v[3] ?></h3>
      <p style="font-size:13px;color:#717975;line-height:1.6;"><?= $v[4] ?></p>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- CTA final -->
  <div style="background:linear-gradient(135deg,#001a10,#005a38);border-radius:20px;padding:40px 32px;text-align:center;position:relative;overflow:hidden;margin-bottom:16px;">
    <div style="position:absolute;inset:0;background-image:radial-gradient(circle,rgba(255,255,255,.05) 1px,transparent 1px);background-size:18px 18px;"></div>
    <div style="position:relative;z-index:1;">
      <h3 style="font-size:clamp(20px,3vw,28px);font-weight:900;color:#fff;margin-bottom:8px;">¿Tienes dudas sobre algún producto?</h3>
      <p style="font-size:14px;color:rgba(255,255,255,.6);margin-bottom:24px;">Nuestro equipo te asesora sin costo. Respuesta inmediata por WhatsApp.</p>
      <a href="https://wa.me/<?= $waNumber ?>?text=<?= urlencode('Hola Verde Natural, quiero asesoría sobre sus productos.') ?>" target="_blank"
         style="display:inline-flex;align-items:center;gap:10px;background:#25A35A;color:#fff;font-weight:700;font-size:15px;padding:14px 32px;border-radius:999px;text-decoration:none;box-shadow:0 8px 24px rgba(37,163,90,.4);">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.52 3.48A11.93 11.93 0 0 0 12 0C5.37 0 0 5.37 0 12c0 2.11.55 4.16 1.6 5.97L0 24l6.19-1.62A11.94 11.94 0 0 0 12 24c6.63 0 12-5.37 12-12 0-3.2-1.25-6.21-3.48-8.52ZM12 22c-1.85 0-3.66-.5-5.24-1.44l-.37-.22-3.86 1.01 1.03-3.76-.24-.38A9.94 9.94 0 0 1 2 12C2 6.48 6.48 2 12 2c2.67 0 5.18 1.04 7.07 2.93A9.95 9.95 0 0 1 22 12c0 5.52-4.48 10-10 10Z"/></svg>
        Consultar por WhatsApp
      </a>
    </div>
  </div>
</section>
<?php endif; ?>

</main>

<!-- ═══════ FOOTER ═══════ -->
<footer class="bg-primary text-on-primary mt-12">
  <div class="max-w-7xl mx-auto px-4 lg:px-10 py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
    <div class="flex flex-col gap-4">
      <div class="flex items-center gap-3">
        <svg width="36" height="36" viewBox="0 0 120 120" fill="none">
          <ellipse cx="60" cy="62" rx="42" ry="52" fill="#a4f3ca" fill-opacity=".25"/>
          <path d="M60 100 C60 100 60 50 60 25" stroke="#a4f3ca" stroke-width="5" stroke-linecap="round"/>
          <path d="M60 60 C45 50 30 42 28 28" stroke="#a4f3ca" stroke-width="3.5" stroke-linecap="round"/>
          <path d="M60 75 C45 65 32 60 30 46" stroke="#a4f3ca" stroke-width="3.5" stroke-linecap="round"/>
          <path d="M60 60 C75 50 90 42 92 28" stroke="#a4f3ca" stroke-width="3.5" stroke-linecap="round"/>
          <path d="M60 75 C75 65 88 60 90 46" stroke="#a4f3ca" stroke-width="3.5" stroke-linecap="round"/>
        </svg>
        <div>
          <span class="text-xl font-bold tracking-tight text-white block">Verde Natural</span>
          <span style="font-size:11px;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.06em;">Productos Naturales</span>
        </div>
      </div>
      <p style="font-size:13px;color:rgba(255,255,255,.65);line-height:1.6;">Tienda de productos naturales y medicinales colombianos con certificación INVIMA. Cali, Valle del Cauca.</p>
      <a href="https://wa.me/<?= $waNumber ?>" target="_blank"
         style="display:inline-flex;align-items:center;gap:8px;background:#25A35A;color:#fff;font-weight:600;font-size:13px;padding:10px 20px;border-radius:999px;text-decoration:none;align-self:flex-start;">
        <span class="material-symbols-outlined text-[17px]">chat</span>WhatsApp
      </a>
    </div>
    <div>
      <h4 class="font-semibold mb-4">Categorías</h4>
      <ul class="flex flex-col gap-2">
        <?php foreach($categorias as $cat): ?>
        <li><a href="index.php?page=categoria&cat=<?= h($cat['slug']) ?>" style="font-size:13px;color:rgba(255,255,255,.65);text-decoration:none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='rgba(255,255,255,.65)'"><?= h($cat['nombre']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div>
      <h4 class="font-semibold mb-4">Información</h4>
      <ul class="flex flex-col gap-2">
        <?php foreach([
          ['verified','Productos con Registro INVIMA'],
          ['local_shipping','Despacho a toda Colombia'],
          ['payments','Pago contra entrega'],
          ['support_agent','Asesoría botánica gratuita'],
        ] as $item): ?>
        <li style="display:flex;align-items:center;gap:8px;font-size:13px;color:rgba(255,255,255,.65);">
          <span class="material-symbols-outlined text-[15px]"><?= $item[0] ?></span><?= $item[1] ?>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div>
      <h4 class="font-semibold mb-4">Contacto</h4>
      <ul class="flex flex-col gap-2">
        <li style="display:flex;align-items:center;gap:8px;font-size:13px;color:rgba(255,255,255,.65);"><span class="material-symbols-outlined text-[15px]">location_on</span>Cali, Valle del Cauca, Colombia</li>
        <li style="display:flex;align-items:center;gap:8px;font-size:13px;color:rgba(255,255,255,.65);"><span class="material-symbols-outlined text-[15px]">phone</span>(+57) 320 670 8805</li>
        <li style="display:flex;align-items:center;gap:8px;font-size:13px;color:rgba(255,255,255,.65);"><span class="material-symbols-outlined text-[15px]">schedule</span>Lun–Sáb: 8am–6pm · Dom: 9am–1pm</li>
      </ul>
    </div>
  </div>
  <div style="border-top:1px solid rgba(255,255,255,.08);">
    <div class="max-w-7xl mx-auto px-4 lg:px-10 py-5 flex flex-col md:flex-row items-center justify-between gap-3">
      <p style="font-size:12px;color:rgba(255,255,255,.4);">© <?= date('Y') ?> Verde Natural — Todos los derechos reservados.</p>
      <span style="font-size:12px;color:rgba(255,255,255,.4);display:flex;align-items:center;gap:6px;">
        <span class="material-symbols-outlined text-[13px]" style="color:#88d6af;">verified_user</span>Productos con Registro Sanitario INVIMA vigente
      </span>
    </div>
  </div>
</footer>

<!-- ═══════ MODAL CHECKOUT ═══════ -->
<div id="modalCheckout" class="modal-overlay" onclick="if(event.target===this)this.classList.remove('open')">
  <div style="background:#fff;border-radius:24px;padding:32px;width:100%;max-width:520px;margin:16px;box-shadow:0 24px 56px rgba(0,0,0,.18);max-height:90vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
      <div>
        <h2 style="font-size:20px;font-weight:800;color:#00291e;">Confirmar Pedido</h2>
        <p style="font-size:12px;color:#717975;margin-top:2px;">Lo procesamos por WhatsApp de inmediato</p>
      </div>
      <button onclick="document.getElementById('modalCheckout').classList.remove('open')" style="background:#f1f5f0;border:none;width:36px;height:36px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <span class="material-symbols-outlined" style="font-size:20px;color:#717975;">close</span>
      </button>
    </div>

    <!-- Resumen de items -->
    <div id="checkoutItems" style="background:#f6faf5;border-radius:14px;padding:16px;margin-bottom:20px;display:flex;flex-direction:column;gap:10px;"></div>

    <!-- Total -->
    <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 16px;background:#ebefea;border-radius:12px;margin-bottom:20px;">
      <span style="font-size:14px;font-weight:600;color:#414845;">Total estimado</span>
      <span id="checkoutTotal" style="font-size:20px;font-weight:900;color:#00291e;"></span>
    </div>

    <form method="POST" id="formPedido" style="display:flex;flex-direction:column;gap:14px;">
      <input type="hidden" name="hacer_pedido" value="1">
      <input type="hidden" name="pedido_items" id="pedidoItemsInput">

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div style="grid-column:1/-1;">
          <label style="font-size:12px;font-weight:700;color:#414845;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Nombre completo *</label>
          <input name="ped_nombre" required style="width:100%;background:#f6faf5;border:1.5px solid #c1c8c3;border-radius:12px;padding:11px 14px;font-size:14px;outline:none;transition:border-color .2s;" onfocus="this.style.borderColor='#176b4b'" onblur="this.style.borderColor='#c1c8c3'" placeholder="Diana Morales">
        </div>
        <div>
          <label style="font-size:12px;font-weight:700;color:#414845;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">WhatsApp *</label>
          <input name="ped_telefono" required style="width:100%;background:#f6faf5;border:1.5px solid #c1c8c3;border-radius:12px;padding:11px 14px;font-size:14px;outline:none;transition:border-color .2s;" onfocus="this.style.borderColor='#176b4b'" onblur="this.style.borderColor='#c1c8c3'" placeholder="3001234567">
        </div>
        <div>
          <label style="font-size:12px;font-weight:700;color:#414845;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Ciudad *</label>
          <input name="ped_ciudad" required style="width:100%;background:#f6faf5;border:1.5px solid #c1c8c3;border-radius:12px;padding:11px 14px;font-size:14px;outline:none;transition:border-color .2s;" onfocus="this.style.borderColor='#176b4b'" onblur="this.style.borderColor='#c1c8c3'" placeholder="Cali">
        </div>
        <div style="grid-column:1/-1;">
          <label style="font-size:12px;font-weight:700;color:#414845;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Dirección de entrega</label>
          <input name="ped_direccion" style="width:100%;background:#f6faf5;border:1.5px solid #c1c8c3;border-radius:12px;padding:11px 14px;font-size:14px;outline:none;transition:border-color .2s;" onfocus="this.style.borderColor='#176b4b'" onblur="this.style.borderColor='#c1c8c3'" placeholder="Cra. 5 #10-23, apto 201">
        </div>
        <div style="grid-column:1/-1;">
          <label style="font-size:12px;font-weight:700;color:#414845;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em;">Notas adicionales</label>
          <textarea name="ped_notas" rows="2" style="width:100%;background:#f6faf5;border:1.5px solid #c1c8c3;border-radius:12px;padding:11px 14px;font-size:14px;outline:none;resize:none;transition:border-color .2s;" onfocus="this.style.borderColor='#176b4b'" onblur="this.style.borderColor='#c1c8c3'" placeholder="Horario de entrega preferido, instrucciones..."></textarea>
        </div>
      </div>

      <button type="submit" style="width:100%;background:#176b4b;color:#fff;font-weight:800;font-size:15px;padding:14px;border-radius:14px;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:background .2s;box-shadow:0 6px 24px rgba(23,107,75,.35);"
              onmouseover="this.style.background='#0f5238'" onmouseout="this.style.background='#176b4b'">
        <span class="material-symbols-outlined" style="font-size:20px;">check_circle</span>
        Confirmar y pedir por WhatsApp
      </button>
    </form>
  </div>
</div>

<?php if ($pedidoOk): ?>
<script>
// Pedido confirmado — abrir WhatsApp con el resumen
window.addEventListener('DOMContentLoaded', function(){
  var num = '<?= WA_NUMBER ?>';
  var msg = 'Hola Verde Natural, acabo de hacer un pedido en su tienda web.\n*N° <?= h($pedidoOk) ?>*\nPor favor confirmarlo. ¡Gracias!';
  setTimeout(function(){ window.open('https://wa.me/'+num+'?text='+encodeURIComponent(msg),'_blank'); }, 500);
  localStorage.removeItem('vn_cart');
});
</script>
<div style="position:fixed;top:0;left:0;right:0;z-index:9999;background:#176b4b;color:#fff;text-align:center;padding:14px 20px;font-size:14px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:8px;">
  <span class="material-symbols-outlined" style="font-size:20px;">check_circle</span>
  ¡Pedido <?= h($pedidoOk) ?> registrado! Abriendo WhatsApp para confirmar…
</div>
<?php endif; ?>

<div id="toastContainer" class="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 pointer-events-none"></div>

<script>
// Si no hay sesión, el carrito siempre está vacío
let cart = clienteLogueado ? JSON.parse(localStorage.getItem('vn_cart')||'[]') : [];
if(!clienteLogueado) localStorage.removeItem('vn_cart');
const WA='<?= $waNumber ?>';

function saveCart(){localStorage.setItem('vn_cart',JSON.stringify(cart));updateCartUI();}
var clienteLogueado = <?= $clienteLogueado ? 'true' : 'false' ?>;
function requireLogin(){
  document.getElementById('modalLogin').classList.add('open');
  showToast('⚠️ Inicia sesión para agregar al carrito');
}
function addToCart(id,name,price,img){
  if(!clienteLogueado){ requireLogin(); return; }
  const qty=parseInt(document.getElementById('qtyDisplay')?.textContent||'1');
  const ex=cart.find(i=>i.id===id);
  if(ex)ex.qty+=qty; else cart.push({id,name,price,img,qty});
  saveCart(); showToast('✓ '+name+' añadido al carrito'); openCartDrawer();
}
function addToCartFromCard(id,name,price,img){
  if(!clienteLogueado){ requireLogin(); return; }
  const ex=cart.find(i=>i.id===id);
  if(ex)ex.qty+=1; else cart.push({id,name,price,img,qty:1});
  saveCart(); showToast('✓ '+name+' añadido al carrito');
}
function removeFromCart(id){cart=cart.filter(i=>i.id!==id);saveCart();}
function updateCartQty(id,delta){const it=cart.find(i=>i.id===id);if(!it)return;it.qty=Math.max(1,it.qty+delta);saveCart();}
function clearCart(){cart=[];saveCart();}
function formatPriceCOP(n){return'$ '+Math.round(n).toLocaleString('es-CO')+' COP';}

function updateCartUI(){
  const total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  const count=cart.reduce((s,i)=>s+i.qty,0);
  const badge=document.getElementById('cartBadge');
  if(badge){badge.textContent=count;badge.classList.toggle('hidden',count===0);}
  const container=document.getElementById('cartItems');
  const empty=document.getElementById('cartEmpty');
  const footer=document.getElementById('cartFooter');
  if(!container)return;
  if(cart.length===0){
    empty.style.display='flex';footer.style.display='none';
    const hc=document.getElementById('cartHeaderCount');
    if(hc) hc.textContent='0 productos';
    [...container.children].forEach(c=>{if(c.id!=='cartEmpty')c.remove();});return;
  }
  empty.style.display='none';footer.style.display='block';
  [...container.querySelectorAll('.cart-item')].forEach(e=>e.remove());
  // Update header count
  const hc=document.getElementById('cartHeaderCount');
  if(hc) hc.textContent=count+' producto'+(count!==1?'s':'');
  const ic=document.getElementById('cartItemCount');
  if(ic) ic.textContent=count;
  cart.forEach(item=>{
    const div=document.createElement('div');
    div.className='cart-item vn-cart-item';
    const imgHtml=item.img
      ?`<img src="${item.img}" alt="${item.name}">`
      :`<span class="material-symbols-outlined" style="font-size:24px;color:rgba(164,243,202,.5);">eco</span>`;
    const unitPrice=`<span style="font-size:11px;color:rgba(164,243,202,.5);font-weight:400;"> x${item.qty}</span>`;
    div.innerHTML=`
      <div class="vn-cart-item-img">${imgHtml}</div>
      <div class="vn-cart-item-info">
        <span class="vn-cart-item-name">${item.name}</span>
        <span class="vn-cart-item-price">${formatPriceCOP(item.price*item.qty)}${unitPrice}</span>
      </div>
      <div class="vn-cart-qty">
        <button class="vn-cart-qty-btn" onclick="updateCartQty(${item.id},-1)">−</button>
        <span class="vn-cart-qty-num">${item.qty}</span>
        <button class="vn-cart-qty-btn" onclick="updateCartQty(${item.id},1)">+</button>
        <button class="vn-cart-del" onclick="removeFromCart(${item.id})">
          <span class="material-symbols-outlined" style="font-size:15px;">delete</span>
        </button>
      </div>`;
    container.appendChild(div);
  });
  document.getElementById('cartTotal').textContent=formatPriceCOP(total);
  const msg=cart.map(i=>`${i.qty}x ${i.name} (${formatPriceCOP(i.price)})`).join('\n')+`\n\n*Total estimado: ${formatPriceCOP(total)}*\n\n¿Pueden procesarme este pedido?`;
  document.getElementById('cartWhatsApp').href=`https://wa.me/${WA}?text=${encodeURIComponent('Hola Verde Natural, quiero pedir:\n\n'+msg)}`;
}

function openCartDrawer(){document.getElementById('cartDrawer').classList.remove('translate-x-full');document.getElementById('cartOverlay').classList.remove('opacity-0','pointer-events-none');document.body.style.overflow='hidden';}
function closeCartDrawer(){document.getElementById('cartDrawer').classList.add('translate-x-full');document.getElementById('cartOverlay').classList.add('opacity-0','pointer-events-none');document.body.style.overflow='';}

function openCheckout(){
  if(cart.length===0){showToast('El carrito está vacío');return;}
  closeCartDrawer();
  // Rellenar resumen en modal
  var ci=document.getElementById('checkoutItems');
  ci.innerHTML='';
  var total=0;
  cart.forEach(function(item){
    total+=item.price*item.qty;
    var d=document.createElement('div');
    d.style.cssText='display:flex;align-items:center;gap:10px;';
    d.innerHTML='<div style="width:44px;height:44px;border-radius:10px;overflow:hidden;background:#ebefea;shrink:0;flex-shrink:0;">'+(item.img?'<img src="'+item.img+'" style="width:100%;height:100%;object-fit:cover;">':'<span class="material-symbols-outlined" style="font-size:24px;color:#176b4b;margin:10px;">eco</span>')+'</div><div style="flex:1;min-width:0;"><p style="font-size:13px;font-weight:600;color:#00291e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+item.name+'</p><p style="font-size:12px;color:#717975;">x'+item.qty+' — '+formatPriceCOP(item.price*item.qty)+'</p></div>';
    ci.appendChild(d);
  });
  document.getElementById('checkoutTotal').textContent=formatPriceCOP(total);
  document.getElementById('pedidoItemsInput').value=JSON.stringify(cart);
  document.getElementById('modalCheckout').classList.add('open');
}
function showToast(msg){const c=document.getElementById('toastContainer');const t=document.createElement('div');t.className='pointer-events-auto bg-inverse-surface text-inverse-on-surface px-5 py-3 rounded-full text-sm font-medium shadow-xl flex items-center gap-2';t.textContent=msg;c.appendChild(t);setTimeout(()=>{t.style.opacity='0';t.style.transform='translateY(8px)';t.style.transition='all .3s';setTimeout(()=>t.remove(),300);},2500);}
function changeProductImage(url){const img=document.getElementById('mainProductImg');if(img&&url)img.src=url;}
function adjustQty(delta){const el=document.getElementById('qtyDisplay');if(!el)return;el.textContent=Math.max(1,parseInt(el.textContent)+delta);}

// Cerrar dropdown cliente al hacer click afuera
document.addEventListener('click',e=>{
  const menu=document.getElementById('menuCliente');
  if(menu&&!menu.contains(e.target))document.getElementById('dropCliente')?.classList.add('hidden');
});

updateCartUI();

// ── Partículas hero canvas ──────────────────────────────────────────
(function(){
  const canvas = document.getElementById('heroParticles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, pts = [];
  const COUNT = 55;

  function resize() {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  function rand(min, max) { return min + Math.random() * (max - min); }

  function init() {
    pts = [];
    for (let i = 0; i < COUNT; i++) {
      pts.push({
        x: rand(0, W), y: rand(0, H),
        r: rand(1, 2.8),
        vx: rand(-.18, .18), vy: rand(-.12, .12),
        a: rand(.15, .55), // alpha máx
        pa: rand(0, Math.PI * 2), // phase for pulsing
        ps: rand(.006, .014)  // pulse speed
      });
    }
  }

  function draw(ts) {
    ctx.clearRect(0, 0, W, H);
    pts.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      p.pa += p.ps;
      if (p.x < -5) p.x = W + 5;
      if (p.x > W + 5) p.x = -5;
      if (p.y < -5) p.y = H + 5;
      if (p.y > H + 5) p.y = -5;
      const alpha = p.a * (.6 + .4 * Math.sin(p.pa));
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }

  resize();
  init();
  window.addEventListener('resize', () => { resize(); init(); });
  requestAnimationFrame(draw);
})();

// Auto-abrir modal de registro si hubo error/ok
<?php if($regError||$regOk): ?>document.getElementById('modalRegistro').classList.add('open');<?php endif; ?>
<?php if($loginError): ?>document.getElementById('modalLogin').classList.add('open');<?php endif; ?>
</script>

<?php
// ── Función tarjeta de producto ───────────────────────────────
function renderProductCard($prod,$waNumber){
  // Paleta sutil por categoría para el acento de la tarjeta
  $catAccent = [
    'jarabes'     => ['from'=>'#003320','to'=>'#005a38','dot'=>'#a4f3ca','text'=>'#a4f3ca','bg_top'=>'#edf7f1','bg_bot'=>'#ddf0e7'],
    'suplementos' => ['from'=>'#1a1a4e','to'=>'#2d2d80','dot'=>'#c0c8ff','text'=>'#c0c8ff','bg_top'=>'#eeeef8','bg_bot'=>'#e3e4f4'],
    'purgantes'   => ['from'=>'#3d1a00','to'=>'#6b3200','dot'=>'#ffd5a8','text'=>'#ffd5a8','bg_top'=>'#fdf3ea','bg_bot'=>'#f9e8d4'],
  ];
  $slug = strtolower($prod['cat_slug'] ?? ($prod['cat_nombre'] ?? ''));
  // Intentar detectar por slug o nombre
  $accentKey = 'jarabes';
  foreach(array_keys($catAccent) as $k){
    if(str_contains(strtolower($slug),$k)||str_contains(strtolower($prod['cat_nombre']??''),$k)){
      $accentKey=$k; break;
    }
  }
  $ac = $catAccent[$accentKey];
  $desc = ($prod['precio_antes'] > 0) ? round((1 - $prod['precio'] / $prod['precio_antes']) * 100) : 0;
  ob_start(); ?>
<article class="vn-pcard group" style="--pc-from:<?= $ac['from'] ?>;--pc-to:<?= $ac['to'] ?>;--pc-dot:<?= $ac['dot'] ?>;--pc-text:<?= $ac['text'] ?>;--pc-bg-top:<?= $ac['bg_top'] ?>;--pc-bg-bot:<?= $ac['bg_bot'] ?>;">
  <a href="index.php?page=producto&prod=<?= urlencode($prod['slug']) ?>" class="vn-pcard-img-wrap">

    <!-- Placeholder botánico siempre visible (queda oculto cuando hay imagen) -->
    <div class="vn-pcard-placeholder">
      <!-- Anillos orbitales -->
      <div class="vn-pcard-ph-ring" style="width:160px;height:160px;left:50%;top:50%;animation-duration:18s;"></div>
      <div class="vn-pcard-ph-ring" style="width:110px;height:110px;left:50%;top:50%;animation-duration:12s;animation-direction:reverse;"></div>
      <!-- Partículas flotantes -->
      <div class="vn-pcard-ph-dot" style="width:5px;height:5px;top:22%;left:20%;animation-duration:3.1s;"></div>
      <div class="vn-pcard-ph-dot" style="width:3px;height:3px;top:60%;left:72%;animation-duration:4.4s;animation-delay:-.8s;"></div>
      <div class="vn-pcard-ph-dot" style="width:4px;height:4px;top:35%;left:78%;animation-duration:2.9s;animation-delay:-1.5s;"></div>
      <div class="vn-pcard-ph-dot" style="width:3px;height:3px;top:70%;left:28%;animation-duration:3.7s;animation-delay:-.4s;"></div>
      <!-- Ilustración botánica central -->
      <div class="vn-pcard-ph-leaf">
        <svg width="80" height="96" viewBox="0 0 80 96" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M40 88 C40 88 40 52 40 24" stroke="rgba(255,255,255,.5)" stroke-width="2.5" stroke-linecap="round"/>
          <path d="M40 48 C30 42 16 36 14 22 C22 24 34 32 40 48Z" fill="rgba(255,255,255,.22)" stroke="rgba(255,255,255,.35)" stroke-width="1"/>
          <path d="M40 48 C32 40 20 32 14 22" stroke="rgba(255,255,255,.25)" stroke-width="1" stroke-linecap="round"/>
          <path d="M40 40 C50 34 64 28 66 14 C58 16 46 24 40 40Z" fill="rgba(255,255,255,.22)" stroke="rgba(255,255,255,.35)" stroke-width="1"/>
          <path d="M40 40 C48 32 60 24 66 14" stroke="rgba(255,255,255,.25)" stroke-width="1" stroke-linecap="round"/>
          <path d="M40 62 C33 58 24 54 22 44 C28 46 36 52 40 62Z" fill="rgba(255,255,255,.15)" stroke="rgba(255,255,255,.25)" stroke-width="1"/>
          <path d="M40 68 C47 64 56 58 58 48 C52 50 44 56 40 68Z" fill="rgba(255,255,255,.15)" stroke="rgba(255,255,255,.25)" stroke-width="1"/>
          <ellipse cx="40" cy="22" rx="6" ry="10" fill="rgba(255,255,255,.3)" stroke="rgba(255,255,255,.45)" stroke-width="1.2"/>
          <path d="M40 32 C40 32 40 22 40 14" stroke="rgba(255,255,255,.4)" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M40 88 C34 90 26 92 20 90" stroke="rgba(255,255,255,.2)" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M40 88 C46 90 54 92 60 90" stroke="rgba(255,255,255,.2)" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M40 88 C38 92 36 95 32 96" stroke="rgba(255,255,255,.15)" stroke-width="1.2" stroke-linecap="round"/>
          <path d="M40 88 C42 92 44 95 48 96" stroke="rgba(255,255,255,.15)" stroke-width="1.2" stroke-linecap="round"/>
        </svg>
      </div>
      <div style="position:absolute;bottom:14px;left:50%;transform:translateX(-50%);
        font-size:10px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;
        color:rgba(255,255,255,.35);white-space:nowrap;z-index:3;">
        Verde Natural
      </div>
    </div>
    <!-- Imagen real encima del placeholder (la cubre cuando carga bien) -->
    <?php if($prod['imagen_principal']): ?>
    <img src="<?= h($prod['imagen_principal']) ?>" alt="<?= h($prod['nombre']) ?>" class="vn-pcard-img"
      onerror="this.style.display='none'">
    <?php endif; ?>

    <!-- Overlay gradiente inferior siempre presente -->
    <div class="vn-pcard-overlay"></div>

    <!-- Badges -->
    <div class="vn-pcard-badges">
      <?php if($prod['precio_antes'] && $prod['precio_antes']>$prod['precio']): ?>
      <span class="vn-pcard-badge vn-pcard-badge-sale">-<?= $desc ?>%</span>
      <?php endif; ?>
      <?php if($prod['destacado'] && !($prod['precio_antes']>$prod['precio'])): ?>
      <span class="vn-pcard-badge vn-pcard-badge-feat">★ Destacado</span>
      <?php endif; ?>
      <?php if($prod['stock']<=0): ?>
      <span class="vn-pcard-badge vn-pcard-badge-out">Agotado</span>
      <?php endif; ?>
    </div>

    <!-- Calificación flotante -->
    <?php if($prod['num_resenas']>0): ?>
    <div class="vn-pcard-rating">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="#facc15"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
      <span><?= number_format((float)$prod['calificacion'],1) ?></span>
      <span style="opacity:.6;">(<?= (int)$prod['num_resenas'] ?>)</span>
    </div>
    <?php endif; ?>

  </a>

  <!-- Botones rápidos hover — aparece sobre la imagen al hacer hover -->
  <div class="vn-pcard-quickview">
    <a href="index.php?page=producto&prod=<?= urlencode($prod['slug']) ?>" class="vn-pcard-quickview-btn" title="Vista rápida">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
    </a>
    <button class="vn-pcard-quickview-btn" title="Agregar al carrito"
      onclick="event.stopPropagation();addToCartFromCard(<?= (int)$prod['id'] ?>,'<?= addslashes(h($prod['nombre'])) ?>',<?= (float)$prod['precio'] ?>,'<?= h($prod['imagen_principal']??'') ?>')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
    </button>
  </div>

  <!-- Cuerpo de la tarjeta -->
  <div class="vn-pcard-body">
    <a href="index.php?page=producto&prod=<?= urlencode($prod['slug']) ?>" style="text-decoration:none;">
      <!-- Presentación pequeña -->
      <?php if($prod['presentacion']): ?>
      <div class="vn-pcard-meta">
        <span class="vn-pcard-pres"><?= h($prod['presentacion']) ?></span>
      </div>
      <?php endif; ?>
      <!-- Nombre -->
      <h3 class="vn-pcard-name"><?= h($prod['nombre']) ?></h3>
      <!-- Descripción corta recortada -->
      <?php if($prod['descripcion_corta']): ?>
      <p class="vn-pcard-desc"><?= h(mb_strimwidth($prod['descripcion_corta'], 0, 70, '…')) ?></p>
      <?php endif; ?>
    </a>

    <!-- Precio + Botón -->
    <div class="vn-pcard-footer">
      <div class="vn-pcard-price-block">
        <?php if($prod['precio_antes'] && $prod['precio_antes']>$prod['precio']): ?>
        <span class="vn-pcard-price-before"><?= formatPrice($prod['precio_antes']) ?></span>
        <?php endif; ?>
        <span class="vn-pcard-price"><?= formatPrice($prod['precio']) ?></span>
      </div>
      <button onclick="event.preventDefault();addToCartFromCard(<?= (int)$prod['id'] ?>,'<?= addslashes(h($prod['nombre'])) ?>',<?= (float)$prod['precio'] ?>,'<?= h($prod['imagen_principal']??'') ?>')"
              class="vn-pcard-btn <?= $prod['stock']<=0?'vn-pcard-btn-disabled':'' ?>"
              <?= $prod['stock']<=0?'disabled':'' ?>
              aria-label="Agregar <?= h($prod['nombre']) ?>">
        <span class="material-symbols-outlined" style="font-size:20px;">add_shopping_cart</span>
      </button>
    </div>
  </div>
</article>
<?php return ob_get_clean();
}
?>

<!-- Botón flotante WhatsApp -->
<a href="https://wa.me/<?= preg_replace('/\D/','',$waNumber) ?>?text=Hola%2C%20quiero%20hacer%20un%20pedido%20en%20Verde%20Natural%20🌿"
   target="_blank" rel="noopener"
   id="vn-wa-fab"
   title="Escríbenos por WhatsApp"
   style="
     position:fixed; bottom:24px; right:24px; z-index:9999;
     width:56px; height:56px; border-radius:50%;
     background:#25D366;
     display:flex; align-items:center; justify-content:center;
     box-shadow:0 4px 20px rgba(37,211,102,.45), 0 2px 8px rgba(0,0,0,.2);
     text-decoration:none;
     transition:transform .2s ease, box-shadow .2s ease;
   "
   onmouseenter="this.style.transform='scale(1.12)';this.style.boxShadow='0 6px 28px rgba(37,211,102,.6),0 2px 8px rgba(0,0,0,.25)'"
   onmouseleave="this.style.transform='scale(1)';this.style.boxShadow='0 4px 20px rgba(37,211,102,.45),0 2px 8px rgba(0,0,0,.2)'"
>
  <!-- Pulso animado de fondo -->
  <span style="
    position:absolute; inset:0; border-radius:50%;
    background:#25D366; opacity:.35;
    animation:vn-wa-pulse 2.2s ease-out infinite;
    pointer-events:none;
  "></span>
  <!-- Ícono WhatsApp -->
  <svg width="28" height="28" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg" style="position:relative;z-index:1;">
    <path d="M20.52 3.48A11.93 11.93 0 0 0 12 0C5.37 0 0 5.37 0 12c0 2.11.55 4.16 1.6 5.97L0 24l6.19-1.62A11.94 11.94 0 0 0 12 24c6.63 0 12-5.37 12-12 0-3.2-1.25-6.21-3.48-8.52ZM12 22c-1.85 0-3.66-.5-5.24-1.44l-.37-.22-3.86 1.01 1.03-3.76-.24-.38A9.94 9.94 0 0 1 2 12C2 6.48 6.48 2 12 2c2.67 0 5.18 1.04 7.07 2.93A9.95 9.95 0 0 1 22 12c0 5.52-4.48 10-10 10Zm5.44-7.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15s-.77.97-.94 1.17c-.17.2-.34.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.34.45-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.6-.91-2.19-.24-.58-.48-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.03 1.01-1.03 2.46s1.06 2.85 1.2 3.05c.15.2 2.07 3.17 5.02 4.44.7.3 1.25.48 1.68.62.7.22 1.34.19 1.85.12.56-.08 1.76-.72 2.01-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.19-.57-.34Z"/>
  </svg>
</a>
<style>
@keyframes vn-wa-pulse {
  0%   { transform:scale(1);   opacity:.35; }
  70%  { transform:scale(1.6); opacity:0;   }
  100% { transform:scale(1.6); opacity:0;   }
}
</style>

</body>
</html>
