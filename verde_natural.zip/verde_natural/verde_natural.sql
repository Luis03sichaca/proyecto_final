-- ============================================================
-- BASE DE DATOS: Verde Natural - Tienda de Productos Naturales
-- Cali, Colombia | Dueña: Diana Morales
-- ============================================================

CREATE DATABASE IF NOT EXISTS verde_natural CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE verde_natural;

CREATE TABLE categorias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  descripcion TEXT,
  icono VARCHAR(50) DEFAULT 'eco',
  imagen_url MEDIUMTEXT,
  activa TINYINT(1) DEFAULT 1,
  orden INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  categoria_id INT,
  nombre VARCHAR(200) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  descripcion_corta VARCHAR(300),
  descripcion TEXT,
  ingredientes TEXT,
  modo_uso TEXT,
  precio DECIMAL(10,2) NOT NULL,
  precio_antes DECIMAL(10,2),
  presentacion VARCHAR(100),
  stock INT DEFAULT 0,
  invima VARCHAR(100),
  destacado TINYINT(1) DEFAULT 0,
  activo TINYINT(1) DEFAULT 1,
  imagen_principal MEDIUMTEXT,
  imagen2 MEDIUMTEXT,
  imagen3 MEDIUMTEXT,
  imagen4 MEDIUMTEXT,
  calificacion DECIMAL(3,1) DEFAULT 5.0,
  num_resenas INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE banners (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(200) NOT NULL,
  subtitulo VARCHAR(300),
  descripcion TEXT,
  imagen_url MEDIUMTEXT,
  boton_texto VARCHAR(100) DEFAULT 'Ver Catálogo',
  boton_url VARCHAR(300) DEFAULT '#catalogo',
  boton_whatsapp VARCHAR(300),
  activo TINYINT(1) DEFAULT 1,
  orden INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  numero_pedido VARCHAR(20) NOT NULL UNIQUE,
  nombre_cliente VARCHAR(200),
  telefono VARCHAR(20),
  ciudad VARCHAR(100),
  direccion TEXT,
  items TEXT,
  subtotal DECIMAL(10,2),
  total DECIMAL(10,2),
  estado ENUM('nuevo','confirmado','despachado','entregado','cancelado') DEFAULT 'nuevo',
  notas TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE administradores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol ENUM('admin','editor') DEFAULT 'admin',
  activo TINYINT(1) DEFAULT 1,
  ultimo_acceso TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla de clientes registrados
CREATE TABLE clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  telefono VARCHAR(20),
  ciudad VARCHAR(100),
  direccion TEXT,
  password VARCHAR(255) NOT NULL,
  activo TINYINT(1) DEFAULT 1,
  email_verificado TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ultimo_acceso TIMESTAMP NULL
) ENGINE=InnoDB;

CREATE TABLE configuracion (
  clave VARCHAR(100) PRIMARY KEY,
  valor TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- DATOS INICIALES: 3 categorías principales
-- ============================================================
INSERT INTO categorias (nombre, slug, descripcion, icono, orden) VALUES
('Jarabes y Elixires',    'jarabes',      'Jarabes naturales para vías respiratorias, defensas y bienestar general. Fórmulas colombianas con extractos puros certificados INVIMA.', 'water_drop', 1),
('Suplementos Naturales', 'suplementos',  'Vitaminas, minerales y tinturas madre para energía, descanso y sistema inmune. Extractos de alta biodisponibilidad.', 'medication', 2),
('Purgantes y Depurativos','purgantes',   'Fórmulas depurativas con plantas medicinales colombianas para digestión, hígado y desintoxicación del organismo.', 'nest_eco_leaf', 3);

-- ============================================================
-- DATOS INICIALES: productos
-- ============================================================
INSERT INTO productos (categoria_id, nombre, slug, descripcion_corta, descripcion, ingredientes, modo_uso, precio, precio_antes, presentacion, stock, invima, destacado, activo, calificacion, num_resenas) VALUES

(1, 'Jarabe de Totumo & Propóleo', 'jarabe-totumo-propoleo',
 'Refuerzo natural para vías respiratorias con propóleo puro y miel virgen de abejas colombianas.',
 'Fórmula artesanal elaborada con extracto de totumo (Crescentia cujete), propóleo puro de colmenas del Valle del Cauca y miel virgen. Ideal para tos, bronquitis y fortalecer las defensas respiratorias. Sin colorantes artificiales.',
 'Extracto de totumo (Crescentia cujete), propóleo natural, miel virgen de abejas, eucalipto, jengibre, jugo de limón.',
 'Adultos: 2 cucharadas 3 veces al día. Niños mayores de 6 años: 1 cucharada 3 veces al día. Agitar antes de usar.',
 28000, 34000, 'Frasco 360 ml', 45, 'PFM2021-000214-R1', 1, 1, 4.9, 48),

(1, 'Jarabe de Saúco & Equinácea', 'jarabe-sauco-equinacea',
 'Fortalece el sistema inmune y reduce la duración de resfriados y gripes de forma natural.',
 'Combinación de saúco negro (Sambucus nigra) y equinácea purpúrea, dos de las plantas más reconocidas para la inmunidad. Fórmula sin colorantes ni conservantes artificiales. Producida en Cali, Colombia.',
 'Extracto de saúco negro, tintura de equinácea, miel de abejas, vitamina C natural de acerola.',
 'Tomar 2 cucharadas al día como preventivo o cada 4 horas durante enfermedad. Niños: mitad de dosis.',
 32000, NULL, 'Frasco 240 ml', 30, 'PFM2020-001123-R2', 1, 1, 4.8, 32),

(1, 'Elixir de Llantén & Miel', 'elixir-llanten-miel',
 'Alivia la irritación de garganta y tos seca con plantas medicinales del Valle del Cauca.',
 'El llantén mayor (Plantago major) tiene propiedades expectorantes y antiinflamatorias reconocidas. Combinado con miel pura del Valle y limón, crea un jarabe suave y efectivo para toda la familia.',
 'Infusión concentrada de llantén mayor, miel de abejas, zumo de limón, jengibre fresco.',
 'Tomar 1 cucharada 4 veces al día. Puede mezclarse con agua tibia o té de manzanilla.',
 22000, NULL, 'Frasco 240 ml', 60, 'PFM2019-002341-R1', 0, 1, 4.7, 21),

(2, 'Citrato de Magnesio Puro', 'citrato-magnesio-puro',
 'Mineral biodisponible para descanso profundo, músculos y articulaciones.',
 'El citrato de magnesio es la forma más biodisponible del mineral. Esencial para más de 300 reacciones enzimáticas: sueño profundo, relajación muscular, salud cardiovascular y reducción del estrés. Sin rellenos ni aditivos.',
 'Citrato de magnesio 350mg por cápsula. Sin rellenos ni aditivos artificiales.',
 'Tomar 1-2 cápsulas al día, preferiblemente en la noche con un vaso de agua.',
 48000, NULL, '120 cápsulas', 7, 'PFN2021-003412-R1', 1, 1, 4.9, 67),

(2, 'Vitamina D3 + K2 Natural', 'vitamina-d3-k2',
 'Sinergia perfecta para huesos fuertes, sistema inmune y salud cardiovascular.',
 'La vitamina D3 y K2 trabajan juntas para una absorción óptima del calcio. Formulado con aceite de oliva para máxima absorción. Ideal para personas con poca exposición al sol.',
 'Vitamina D3 (colecalciferol) 2000 UI, Vitamina K2 (menaquinona MK-7) 100mcg, aceite de oliva extra virgen.',
 'Tomar 1 cápsula al día con el desayuno. No exceder la dosis recomendada.',
 42000, 50000, '60 cápsulas blandas', 25, 'PFN2022-000891-R1', 0, 1, 4.8, 44),

(2, 'Gotas de Valeriana & Pasiflora', 'gotas-valeriana-pasiflora',
 'Para el estrés, la ansiedad y mejorar la calidad del sueño naturalmente sin alcohol.',
 'La valeriana (Valeriana officinalis) y la pasiflora (Passiflora incarnata) son las plantas más estudiadas para el sistema nervioso. Esta tintura en base glicerinada es apta para toda la familia, sin alcohol.',
 'Tintura de raíz de valeriana, extracto de pasiflora, glicerina vegetal (base sin alcohol).',
 'Tomar 20-30 gotas en agua 30 minutos antes de dormir. Para ansiedad diurna: 15 gotas 3 veces al día.',
 38000, NULL, 'Frasco gotero 50 ml', 4, 'PFN2021-006234-R1', 1, 1, 4.9, 72),

(3, 'Depurativo Hepático Boldo', 'depurativo-hepatico-boldo',
 'Con alcachofa y ruibarbo para digestión pesada y desintoxicación natural del hígado.',
 'El boldo chileno (Peumus boldus) es el rey de las plantas depurativas del hígado. Combinado con alcachofa (Cynara scolymus) y ruibarbo, esta fórmula apoya la función hepática y biliar. Uso tradicional colombiano.',
 'Extracto fluido de boldo, tintura de alcachofa, extracto de ruibarbo, cardo mariano, diente de león.',
 'Tomar 30 gotas en medio vaso de agua tibia, 2 veces al día antes de las comidas. No usar en embarazo.',
 25000, NULL, 'Frasco 500 ml', 9, 'PFN2021-005123-R1', 1, 1, 4.7, 38),

(3, 'Purgante de Sábila & Cáscara Sagrada', 'purgante-sabila-cascara',
 'Regulador intestinal suave y efectivo con plantas medicinales del trópico colombiano.',
 'Fórmula suave para el estreñimiento ocasional. La sábila (Aloe vera) tiene efecto laxante suave, y la cáscara sagrada (Rhamnus purshiana) actúa como estimulante del tránsito intestinal. Sin efectos secundarios agresivos.',
 'Gel de aloe vera puro, extracto de cáscara sagrada, semillas de psyllium, cúrcuma.',
 'Tomar 2 cucharadas en ayunas con agua tibia. Usar máximo 7 días seguidos. No recomendado en menores de 12 años.',
 18000, NULL, 'Frasco 240 ml', 55, 'PFN2019-003241-R1', 0, 1, 4.5, 15);

-- ============================================================
-- DATOS INICIALES: banners
-- ============================================================
INSERT INTO banners (titulo, subtitulo, descripcion, boton_texto, boton_url, activo, orden) VALUES
('Herbolaria Colombiana con Registro INVIMA', 'Naturaleza que sana desde Cali para todo el país',
 'Extractos botánicos, jarabes y fórmulas naturales certificadas. Pedidos directos por WhatsApp con asesoría experta de terapeutas naturistas.',
 'Ver Catálogo', '#catalogo', 1, 1),

('Envíos Seguros a Todo Colombia', 'Despacho desde Cali, Valle del Cauca',
 'Pago contra entrega disponible en las principales ciudades. Garantizamos la calidad y frescura de cada producto en su llegada.',
 'Pedir por WhatsApp', 'https://wa.me/573206708805', 1, 2),

('Asesoría Botánica Gratuita', 'Nuestros terapeutas naturistas te orientan',
 'Contamos con especialistas en fitoterapia para guiarte hacia el mejor producto según tu necesidad de salud. Escríbenos sin compromiso.',
 'Consultar Ahora', 'https://wa.me/573206708805', 1, 3);

-- ============================================================
-- DATOS INICIALES: administradores
-- (Contraseña por defecto: admin2024 — CAMBIAR EN PRODUCCIÓN)
-- ============================================================
INSERT INTO administradores (nombre, email, password, rol) VALUES
('Diana Morales', 'admin@verdenatural.co',
 '$2y$10$TKh8H1.PfuA2pi3uej/0AOc9bQIsIANDAN95GSGjMvXE5LNk62xDe',
 'admin');
-- La contraseña es: admin2024

-- ============================================================
-- DATOS INICIALES: configuracion
-- ============================================================
INSERT INTO configuracion (clave, valor) VALUES
('nombre_tienda', 'Verde Natural'),
('telefono_whatsapp', '573206708805'),
('descripcion_tienda', 'Tienda de productos naturales y medicinales en Cali, Colombia'),
('email_contacto', 'contacto@verdenatural.co'),
('ciudad', 'Cali, Valle del Cauca, Colombia'),
('envio_gratis_minimo', '90000'),
('moneda', 'COP'),
('invima_texto', 'Productos con Registro INVIMA Vigente'),
('meta_titulo', 'Verde Natural — Herbolaria Colombiana Certificada'),
('meta_descripcion', 'Jarabes, suplementos y purgantes naturales con certificación INVIMA. Pedidos y asesoría botánica por WhatsApp desde Cali.'),
('nosotros_titulo', 'Nuestra Historia'),
('nosotros_texto', 'Verde Natural nació en Cali, Colombia, con el propósito de llevar la sabiduría de la herbolaria colombiana a cada hogar del país.\n\nNuestros productos son elaborados con plantas medicinales seleccionadas y certificados con Registro INVIMA, garantizando calidad, seguridad y efectividad.\n\nCreemos en el poder de la naturaleza como aliada del bienestar. Por eso trabajamos de la mano con terapeutas naturistas y expertos en fitoterapia para ofrecerte la mejor asesoría sin costo adicional.\n\nEscríbenos por WhatsApp y cuéntanos tu necesidad. Estamos aquí para acompañarte en tu camino hacia la salud natural.');
